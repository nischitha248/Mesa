import { createFileRoute } from "@tanstack/react-router";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDateTime } from "@/lib/mesa/selectors";
import { ActionButton, DataTable, DemoNote, PageHeader, Panel, StatusBadge } from "@/components/mesa/ui";
import { roleName } from "@/components/mesa/shell";
import { pageHead } from "@/components/mesa/forms";

export const Route = createFileRoute("/settings")({
  head: () => pageHead("Settings & Audit Log", "Authorized Admin profile and the full audit trail."),
  component: Settings,
});

function Settings() {
  const d = useData();
  const reset = useMesa((s) => s.reset);
  return (
    <div>
      <PageHeader title="Settings & Audit Log" actions={<ActionButton label="Reset demo data" variant="outline" size="default" title="Reset all demo data?" description="Every change you made in this browser is discarded." onConfirm={() => { reset(); }} />} />
      <DemoNote />
      <Panel title="Authorized Admin" className="mb-6">
        <ul className="divide-y divide-border">
          {d.admins.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
              <span><strong>{a.name}</strong> · {a.email} · {a.roles.map(roleName).join(", ")} <StatusBadge status={a.status} className="ml-2" /></span>
            </li>
          ))}
        </ul>
      </Panel>
      <h2 className="mb-3 text-lg font-semibold">Audit log</h2>
      <DataTable
        rows={d.audit}
        rowKey={(a) => a.id}
        columns={[
          { key: "at", label: "When", render: (a) => fmtDateTime(a.at), sort: (a) => a.at },
          { key: "actor", label: "Actor", render: (a) => a.actor, sort: (a) => a.actor },
          { key: "action", label: "Action", render: (a) => a.action },
          { key: "entity", label: "Record", render: (a) => `${a.entity} · ${a.entityId}` },
          { key: "change", label: "Change", render: (a) => `${a.prev || "—"} → ${a.next}` },
          { key: "reason", label: "Reason", render: (a) => a.reason || "—" },
        ]}
      />
    </div>
  );
}
