import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate } from "@/lib/mesa/selectors";
import { createAnnouncement, editAnnouncement, setAnnouncementStatus } from "@/lib/mesa/logic";
import { DataTable, DemoNote, HistoryList, Panel, PageHeader, StatusBadge } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { pageHead } from "@/components/mesa/forms";
import type { Announcement } from "@/lib/mesa/types";

export const Route = createFileRoute("/announcements")({
  head: () => pageHead("Announcements", "Create and manage programme updates for students and mentors."),
  component: Announcements,
});

const AUDIENCES = ["All students", "All mentors", "Students and mentors", "Selected programme/cohort"];

function Announcements() {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [sel, setSel] = useState<string | null>(null);
  const [f, setF] = useState(emptyForm);
  const rows = d.announcements;
  const save = (publish: boolean) => {
    const mode = !publish ? "Draft" : f.publishDate && f.publishDate > new Date().toISOString().slice(0, 10) ? "Scheduled" : "Published";
    if (run((dd, a) => createAnnouncement(dd, a, f, mode), `Announcement ${mode.toLowerCase()}`)) setF(emptyForm);
  };
  const selected = d.announcements.find((a) => a.id === sel);
  return (
    <div>
      <PageHeader
        title="Announcements"
        subtitle="Create and manage programme updates for students and mentors."
      />
      <DemoNote>Delivery to the Student and Mentor Workspaces is simulated until a shared backend is connected.</DemoNote>
      <Panel title="Create Announcement" className="mb-6"><AnnouncementForm f={f} setF={setF} /><div className="mt-4 flex gap-2"><Button variant="outline" onClick={() => save(false)}>Save Draft</Button><Button onClick={() => save(true)}>Publish</Button></div></Panel>
      <h2 className="mb-4 text-lg font-semibold">Announcement History</h2>
      <DataTable
        rows={rows}
        rowKey={(a) => a.id}
        onRowClick={(a) => setSel(a.id)}
        columns={[
          { key: "t", label: "Title", render: (a) => <div><div className="font-semibold text-cream">{a.title}</div><div className="max-w-md truncate text-xs text-muted-foreground">{a.message}</div></div>, sort: (a) => a.title },
          { key: "a", label: "Audience", render: (a) => a.audience },
          { key: "p", label: "Published date", render: (a) => a.status === "Scheduled" ? "Scheduled" : fmtDate(a.publishDate), sort: (a) => a.publishDate },
          { key: "s", label: "Status", render: (a) => <StatusBadge status={a.status} /> },
          { key: "actions", label: "Edit / Archive", render: (a) => <div className="flex gap-2"><Button variant="link" size="sm" onClick={() => setSel(a.id)}>Edit / View</Button>{a.status !== "Archived" && <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); run((dd, actor) => setAnnouncementStatus(dd, actor, a.id, "Archived"), "Archived"); }}>Archive</Button>}</div> },
        ]}
      />
      {selected && <AnnouncementDetail a={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

interface FormState { id: string; title: string; message: string; audience: string; publishDate: string; expiry: string }
const emptyForm: FormState = { id: "", title: "", message: "", audience: "", publishDate: "", expiry: "" };

function AnnouncementForm({ f, setF }: { f: FormState; setF: (f: FormState) => void }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div><Label>Title</Label><Input className="mt-1 bg-ivory text-maroon" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
      <div>
        <Label>Audience</Label>
        <Select value={f.audience} onValueChange={(v) => setF({ ...f, audience: v })}>
          <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue placeholder="Select audience…" /></SelectTrigger>
          <SelectContent>{AUDIENCES.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="sm:col-span-2"><Label>Message</Label><Textarea className="mt-1 min-h-24 bg-ivory text-maroon" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></div>
      <div className="grid gap-3 sm:col-span-2 sm:grid-cols-2">
        <div><Label>Publish date/time (optional)</Label><Input type="date" className="mt-1 bg-ivory text-maroon" value={f.publishDate} onChange={(e) => setF({ ...f, publishDate: e.target.value })} /></div>
        <div><Label>Expiry (optional)</Label><Input type="date" className="mt-1 bg-ivory text-maroon" value={f.expiry} onChange={(e) => setF({ ...f, expiry: e.target.value })} /></div>
      </div>
    </div>
  );
}

function AnnouncementDetail({ a, onClose }: { a: Announcement; onClose: () => void }) {
  const run = useMesa((s) => s.run);
  const [editing, setEditing] = useState(false);
  const [f, setF] = useState<FormState>({ id: a.id, title: a.title, message: a.message, audience: a.audience, publishDate: a.publishDate, expiry: a.expiry });
  const editable = a.status === "Draft" || a.status === "Scheduled";
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
        <DialogHeader><DialogTitle className="font-display text-2xl">{a.title}</DialogTitle></DialogHeader>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={a.status} />
          <span className="text-xs text-muted-foreground">{a.audience} · publish {fmtDate(a.publishDate)} · expiry {fmtDate(a.expiry)}</span>
        </div>
        {editing ? (
          <>
            <div className="mt-3"><AnnouncementForm f={f} setF={setF} /></div>
            <div className="mt-3 flex gap-2">
              <Button size="sm" onClick={() => run((dd, ac) => editAnnouncement(dd, ac, a.id, f), "Announcement updated") && setEditing(false)}>Save changes</Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>
            </div>
          </>
        ) : (
          <p className="mt-3 text-sm">{a.message}</p>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          {editable && !editing && <Button size="sm" variant="outline" onClick={() => setEditing(true)}>Edit</Button>}
          {(a.status === "Draft" || a.status === "Scheduled") && <Button size="sm" onClick={() => run((dd, ac) => setAnnouncementStatus(dd, ac, a.id, "Published"), "Announcement published")}>Publish now</Button>}
          {a.status !== "Archived" && <Button size="sm" variant="outline" onClick={() => run((dd, ac) => setAnnouncementStatus(dd, ac, a.id, "Archived"), "Announcement archived")}>Archive</Button>}
        </div>
        <h3 className="mb-2 mt-5 font-semibold">History</h3>
        <HistoryList items={a.history} />
      </DialogContent>
    </Dialog>
  );
}
