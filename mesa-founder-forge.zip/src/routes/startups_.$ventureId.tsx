import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, fmtDateTime, goalEvidenceStatus, latestSubmission, leaderOf, mslSummary, nameOf } from "@/lib/mesa/selectors";
import {
  addMember, archiveVenture, changeLeader, decideApplication, editVentureInfo,
  removeMember, type VentureInfoField,
} from "@/lib/mesa/logic";
import {
  ActionButton, DataTable, DemoNote, EmptyState, Field, HistoryList, PageHeader, Panel, ReviewActions, StatusBadge,
} from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { pageHead, Pick, Row, TextIn } from "@/components/mesa/forms";
import { cn } from "@/lib/utils";
import { GoalDetail } from "./goals";
import { RequestCard } from "./meeting-requests";
import { ReportDetail } from "./meeting-reports";
import { WorkshopDetail } from "./workshops";
import { ReadinessDetail } from "./msl";
import type { Venture } from "@/lib/mesa/types";

export const Route = createFileRoute("/startups_/$ventureId")({
  head: (ctx) => pageHead("Startup Profile", "Complete venture profile, submissions and programme history."),
  component: VentureDetail,
});

const TABS = ["Overview", "Team", "Mentors", "Goals & Evidence", "Meetings & Reports", "Workshops", "MSL Readiness", "Public Showcase", "Activity History"] as const;

const EDITABLE: { field: VentureInfoField; label: string }[] = [
  { field: "description", label: "Description" },
  { field: "stage", label: "Current stage" },
  { field: "website", label: "Website" },
  { field: "problem", label: "Problem being solved" },
  { field: "solution", label: "Proposed solution" },
  { field: "customers", label: "Target customers" },
  { field: "businessModel", label: "Business model" },
];

function VentureDetail() {
  const { ventureId } = Route.useParams();
  const d = useData();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  const v = d.ventures.find((x) => x.id === ventureId);
  if (!v) {
    return (
      <div>
        <PageHeader title="Startup not found" subtitle="This venture does not exist in the demo data." />
        <Link to="/startups" className="text-sm underline">Back to Startup Directory</Link>
      </div>
    );
  }
  const leader = leaderOf(d, v.id);
  const mentors = d.assignments.filter((a) => a.ventureId === v.id && a.status === "Active");
  return (
    <div>
      <PageHeader
        title={v.name}
        subtitle="Complete venture profile, submissions and programme history."
        actions={<Link to="/startups" className="text-sm underline">← Directory</Link>}
      />
      <DemoNote />
      <div className="mb-6 flex flex-wrap items-center gap-2">
        <StatusBadge status={v.applicationStatus} />
        <StatusBadge status={v.status} />
        <span className="rounded-full border border-border px-3 py-0.5 text-xs">{v.programme} · {v.cohort}</span>
        <span className="rounded-full border border-border px-3 py-0.5 text-xs">{v.sector}</span>
        <span className="rounded-full border border-border px-3 py-0.5 text-xs">Stage: {v.stage}</span>
        <span className="text-xs text-muted-foreground">Leader: {leader?.name ?? "—"} · Mentors: {mentors.length} · Updated {fmtDate(v.lastActivity)}</span>
      </div>
      <div className="mb-6 flex flex-wrap gap-1 rounded-lg border border-border bg-surface p-1">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn("rounded-full px-3 py-1.5 text-sm font-medium transition-colors", tab === t ? "bg-cream text-maroon" : "text-ivory/80 hover:bg-accent hover:text-cream")}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "Overview" && <OverviewTab v={v} />}
      {tab === "Team" && <TeamTab v={v} />}
      {tab === "Mentors" && <MentorsTab v={v} />}
      {tab === "Goals & Evidence" && <GoalsTab v={v} />}
      {tab === "Meetings & Reports" && <MeetingsTab v={v} />}
      {tab === "Workshops" && <WorkshopsTab v={v} />}
      {tab === "MSL Readiness" && <MslTab v={v} />}
      {tab === "Public Showcase" && <ShowcaseTab v={v} />}
      {tab === "Activity History" && <ActivityTab v={v} />}
    </div>
  );
}

function OverviewTab({ v }: { v: Venture }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [edit, setEdit] = useState<{ field: VentureInfoField; label: string } | null>(null);
  const [value, setValue] = useState("");
  return (
    <div className="space-y-6">
      <Panel title="Basic information" actions={<span className="text-xs text-muted-foreground">Admin and the student team leader can edit these</span>}>
        <div className="grid gap-4 sm:grid-cols-2">
          {EDITABLE.map((f) => (
            <div key={f.field} className="rounded-xl border border-border p-3">
              <div className="flex items-start justify-between gap-2">
                <Field label={f.label}>
                  {f.field === "website" && v.website ? (
                    <a href={v.website} target="_blank" rel="noreferrer" className="underline">{v.website}</a>
                  ) : (
                    v[f.field] || "—"
                  )}
                </Field>
                <Button size="sm" variant="ghost" onClick={() => { setEdit(f); setValue(v[f.field]); }}>Edit</Button>
              </div>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title="Application">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Application details">{v.applicationDetails}</Field>
          <Field label="Programme / cohort">{v.programme} · {v.cohort}</Field>
          <Field label="Application status"><StatusBadge status={v.applicationStatus} /></Field>
          <Field label="Archive reason">{v.archiveReason ?? "—"}</Field>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {(v.applicationStatus === "Pending" || v.applicationStatus === "Changes Requested") && (
            <ReviewActions
              approveTitle={`Approve ${v.name}?`}
              onDecision={(decision, reason) => run((dd, a) => decideApplication(dd, a, v.id, decision, reason), `Application ${decision.toLowerCase()}`)}
            />
          )}
          {v.status !== "Archived" && (
            <ActionButton label="Archive venture" variant="outline" title="Archive venture" requireReason onConfirm={(r) => run((dd, a) => archiveVenture(dd, a, v.id, r), "Venture archived")} />
          )}
        </div>
      </Panel>
      <Panel title="Profile change history">
        {v.infoHistory.length ? (
          <ul className="space-y-3 text-sm">
            {[...v.infoHistory].reverse().map((h, i) => (
              <li key={i} className="rounded-xl border border-border p-3">
                <div className="text-ivory"><strong>{h.field}</strong> changed by {h.by}</div>
                <div className="mt-1 text-xs text-muted-foreground">{fmtDateTime(h.at)}</div>
                <div className="mt-1 text-xs"><span className="text-peach">Before:</span> {h.prev || "—"}</div>
                <div className="text-xs"><span className="text-peach">After:</span> {h.next || "—"}</div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No edits yet.</p>
        )}
      </Panel>
      <Dialog open={!!edit} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit {edit?.label}</DialogTitle></DialogHeader>
          <Textarea value={value} onChange={(e) => setValue(e.target.value)} className="bg-ivory text-maroon" aria-label={edit?.label} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setEdit(null)}>Cancel</Button>
            <Button onClick={() => edit && run((dd, a) => editVentureInfo(dd, a, v.id, edit.field, value), "Saved") && setEdit(null)}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TeamTab({ v }: { v: Venture }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [student, setStudent] = useState("");
  const active = d.memberships.filter((m) => m.ventureId === v.id && !m.end);
  const past = d.memberships.filter((m) => m.ventureId === v.id && m.end);
  return (
    <div className="space-y-6">
      <Panel title="Official members" actions={
        <div className="flex items-end gap-2">
          <Pick label="Add student" value={student} onChange={setStudent} options={d.students.filter((s) => !active.some((m) => m.studentId === s.id)).map((s) => ({ value: s.id, label: s.name }))} />
          <Button size="sm" disabled={!student} onClick={() => run((dd, a) => addMember(dd, a, v.id, student), "Member added") && setStudent("")}>Add</Button>
        </div>
      }>
        <ul className="divide-y divide-border">
          {active.map((m) => {
            const s = d.students.find((x) => x.id === m.studentId);
            return (
              <li key={m.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                <span>
                  <strong>{s?.name}</strong> <StatusBadge status={m.role} className="ml-2" />
                  <span className="ml-2 text-xs text-muted-foreground">{s?.email} · since {fmtDate(m.start)}</span>
                </span>
                {m.role === "Member" && (
                  <span className="flex gap-2">
                    <ActionButton label="Make leader" variant="outline" title="Transfer team leadership" description="In production this uses secure account reassignment — never shared passwords." requireReason onConfirm={(r) => run((dd, a) => changeLeader(dd, a, v.id, m.studentId, r), "Leader changed")} />
                    <ActionButton label="Remove" variant="destructive" title="Remove member" requireReason onConfirm={(r) => run((dd, a) => removeMember(dd, a, m.id, r), "Member removed")} />
                  </span>
                )}
              </li>
            );
          })}
        </ul>
      </Panel>
      <Panel title="Membership history">
        {past.length ? (
          <ul className="divide-y divide-border text-sm">
            {past.map((m) => (
              <li key={m.id} className="py-2">{nameOf(d, m.studentId)} · {m.role} · {fmtDate(m.start)} → {fmtDate(m.end)}</li>
            ))}
          </ul>
        ) : <p className="text-sm text-muted-foreground">No past memberships.</p>}
      </Panel>
    </div>
  );
}

function MentorsTab({ v }: { v: Venture }) {
  const d = useData();
  const ids = new Set([...d.assignments.filter((a) => a.ventureId === v.id).map((a) => a.mentorId), ...d.meetings.filter((m) => m.ventureId === v.id).map((m) => m.mentorId), ...d.requests.filter((r) => r.ventureId === v.id && r.status !== "Rejected").map((r) => r.mentorId)]);
  return <Panel title="Mentors Involved"><DataTable rows={d.mentors.filter((m) => ids.has(m.id))} rowKey={(m) => m.id} columns={[
    { key: "name", label: "Mentor", render: (m) => m.name },
    { key: "expertise", label: "Expertise", render: (m) => m.expertise.join(", ") },
    { key: "role", label: "Designation", render: (m) => d.assignments.find((a) => a.ventureId === v.id && a.mentorId === m.id)?.role ?? "—" },
    { key: "view", label: "Profile", render: (m) => <Link to="/mentors/$mentorId" params={{ mentorId: m.id }} className="underline">View Profile →</Link> },
  ]} /></Panel>;
}

function GoalsTab({ v }: { v: Venture }) {
  const d = useData();
  const [sel, setSel] = useState<string | null>(null);
  const goal = d.goals.find((g) => g.id === sel);
  return <><DataTable rows={d.goals.filter((g) => g.ventureId === v.id)} rowKey={(g) => g.id} onRowClick={(g) => setSel(g.id)} columns={[
    { key: "title", label: "Goal title", render: (g) => g.title },
    { key: "by", label: "Assigned by", render: (g) => g.sourceReportId ? nameOf(d, d.reports.find((r) => r.id === g.sourceReportId)?.mentorId) : g.assignedBy },
    { key: "due", label: "Due date", render: (g) => fmtDate(g.due) },
    { key: "status", label: "Evidence status", render: (g) => <StatusBadge status={goalEvidenceStatus(g)} /> },
    { key: "view", label: "Details", render: (g) => <Button size="sm" variant="link" onClick={() => setSel(g.id)}>View Details</Button> },
  ]} />{goal && <GoalDetail goal={goal} onClose={() => setSel(null)} />}</>;
}

function MeetingsTab({ v }: { v: Venture }) {
  const d = useData();
  const open = useMesa((s) => s.openMeeting);
  const [selected, setSelected] = useState<{ type: "request" | "report"; id: string } | null>(null);
  const request = d.requests.find((r) => selected?.type === "request" && r.id === selected.id);
  const report = d.reports.find((r) => selected?.type === "report" && r.id === selected.id);
  return <div className="space-y-6">
    <Panel title="Meeting Requests"><ul className="divide-y divide-border">{d.requests.filter((r) => r.ventureId === v.id).map((r) => <li key={r.id}><Button variant="ghost" className="h-auto w-full flex-wrap justify-between whitespace-normal py-3 text-left" onClick={() => setSelected({ type: "request", id: r.id })}><span>{r.id} · {r.topic} · {nameOf(d, r.mentorId)}</span><StatusBadge status={r.status} /></Button></li>)}</ul></Panel>
    <Panel title="Meetings"><ul className="divide-y divide-border">{d.meetings.filter((m) => m.ventureId === v.id).map((m) => <li key={m.id}><Button variant="ghost" className="h-auto w-full flex-wrap justify-between whitespace-normal py-3 text-left" onClick={() => open(m.id)}><span>{m.id} · {fmtDateTime(m.start)} · {m.durationMin} min · {nameOf(d, m.mentorId)}</span><StatusBadge status={m.status} /></Button></li>)}</ul></Panel>
    <Panel title="Mentor Reports"><ul className="divide-y divide-border">{d.reports.filter((r) => r.ventureId === v.id).map((r) => <li key={r.id}><Button variant="ghost" className="h-auto w-full flex-wrap justify-between whitespace-normal py-3 text-left" onClick={() => setSelected({ type: "report", id: r.id })}><span>{r.id} · {nameOf(d, r.mentorId)} · {r.versions.length} versions</span><StatusBadge status={r.status} /></Button></li>)}</ul></Panel>
    <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}><DialogContent className="max-w-2xl"><DialogHeader><DialogTitle>{request ? "Meeting Request" : "Mentor Report"} {selected?.id}</DialogTitle></DialogHeader>{request && <><p className="text-sm">Submitted {fmtDateTime(request.submittedAt)} · {request.meetingId ? `Linked meeting ${request.meetingId}` : "No meeting scheduled"}</p><RequestCard r={request} /></>}{report && <ReportDetail r={report} />}</DialogContent></Dialog>
  </div>;
}

function WorkshopsTab({ v }: { v: Venture }) {
  const d = useData();
  const [sel, setSel] = useState<string | null>(null);
  const memberIds = d.memberships.filter((m) => m.ventureId === v.id).map((m) => m.studentId);
  const rows = d.workshops.flatMap((w) => w.registrations.filter((r) => memberIds.includes(r.studentId)).map((r) => ({ w, r })));
  const workshop = d.workshops.find((w) => w.id === sel);
  return <><h2 className="mb-4 text-lg font-semibold">Registered Workshops</h2><DataTable rows={rows} rowKey={(x) => `${x.w.id}/${x.r.studentId}`} onRowClick={(x) => setSel(x.w.id)} columns={[
    { key: "title", label: "Workshop", render: (x) => x.w.title },
    { key: "date", label: "Date & time", render: (x) => `${fmtDate(x.w.date)} ${x.w.startTime}` },
    { key: "member", label: "Team member", render: (x) => nameOf(d, x.r.studentId) },
    { key: "status", label: "Registration", render: (x) => <StatusBadge status={x.r.status} /> },
    { key: "attendance", label: "Attendance", render: (x) => x.r.attended === undefined ? "Not recorded" : x.r.attended ? "Attended" : "No-show" },
  ]} />{workshop && <WorkshopDetail w={workshop} memberIds={memberIds} onClose={() => setSel(null)} />}</>;
}

function MslTab({ v }: { v: Venture }) {
  const d = useData();
  const [criterion, setCriterion] = useState<string | null>(null);
  const review = d.mslReviews.find((r) => r.ventureId === v.id);
  if (!review) return <EmptyState text="No readiness review record for this startup yet." />;
  const summary = mslSummary(d, review);
  return <><Panel title="MSL Readiness" actions={<StatusBadge status={review.status} />}><p className="mb-3 text-sm">{summary.verified}/{summary.total} verified</p><ul className="divide-y divide-border">{d.mslCriteria.filter((c) => c.active).map((c) => <li key={c.id}><Button variant="ghost" className="h-auto w-full justify-between whitespace-normal py-3 text-left" onClick={() => setCriterion(c.id)}>{c.label}<StatusBadge status={review.criteria[c.id]?.status ?? "Not Started"} /></Button></li>)}</ul></Panel>{criterion && <ReadinessDetail r={review} initialCriterion={criterion} onClose={() => setCriterion(null)} />}</>;
}

function ShowcaseTab({ v }: { v: Venture }) {
  const d = useData();
  const items = d.gallery.filter((g) => g.ventureId === v.id);
  if (!items.length) return <EmptyState text="No public showcase submissions from this venture." />;
  return (
    <Panel title="Public showcase submissions" actions={<Link to="/gallery" className="text-sm underline">Open Venture Gallery</Link>}>
      <ul className="divide-y divide-border text-sm">
        {items.map((g) => (
          <li key={g.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span>{g.title} <span className="text-xs text-muted-foreground">· {g.type} · submitted {fmtDate(g.submittedAt)}</span></span>
            <StatusBadge status={g.status} />
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function ActivityTab({ v }: { v: Venture }) {
  const d = useData();
  const auditRows = d.audit.filter((a) => a.entityId === v.id || a.entityId.startsWith(`${v.id}/`));
  return (
    <div className="space-y-6">
      <Panel title="Venture history">
        <HistoryList items={v.history} />
      </Panel>
      <Panel title="Audit events for this venture">
        {auditRows.length ? (
          <ul className="divide-y divide-border text-sm">
            {auditRows.map((a) => (
              <li key={a.id} className="py-2">
                <span className="text-ivory">{a.action}</span>
                <span className="ml-2 text-xs text-muted-foreground">{a.actor} · {fmtDateTime(a.at)} · {a.prev || "—"} → {a.next}{a.reason ? ` · ${a.reason}` : ""}</span>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-muted-foreground">No audit events yet.</p>}
      </Panel>
    </div>
  );
}
