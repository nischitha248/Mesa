import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useData } from "@/lib/mesa/store";
import { inr } from "@/lib/mesa/selectors";
import { DataTable, DemoNote, FilterSelect, matches, PageHeader, SearchBox, SectionTabs, StatusBadge, textMatch, Toolbar } from "@/components/mesa/ui";
import { pageHead } from "@/components/mesa/forms";

export const MENTOR_TABS = [
  { label: "Mentors", to: "/mentors" },
  { label: "Meeting Requests", to: "/meeting-requests" },
  { label: "Calendar", to: "/calendar" },
  { label: "Meeting Reports", to: "/meeting-reports" },
];

export const Route = createFileRoute("/mentors")({
  head: () => pageHead("Mentors & Meetings", "Manage mentor profiles, meeting requests, sessions and reports."),
  component: Mentors,
});

function Mentors() {
  const d = useData();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const rows = d.mentors.filter((m) => textMatch(q, m.name, m.organization, m.expertise.join(" ")) && matches(status, m.status));
  return (
    <div>
      <PageHeader title="Mentors & Meetings" subtitle="Manage mentor profiles, meeting requests, sessions and reports." />
      <DemoNote />
      <SectionTabs tabs={MENTOR_TABS} current="/mentors" />
      <Toolbar>
        <SearchBox value={q} onChange={setQ} placeholder="Search mentors…" />
        <FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Active", "Pending Approval", "Changes Requested", "Paused", "Rejected", "Deactivated"]} />
      </Toolbar>
      <DataTable
        rows={rows}
        rowKey={(m) => m.id}
        onRowClick={(m) => navigate({ to: "/mentors/$mentorId", params: { mentorId: m.id } })}
        columns={[
          { key: "n", label: "Mentor Name", render: (m) => <div><div className="font-semibold text-cream">{m.name}</div><div className="text-xs text-muted-foreground">{m.title}, {m.organization}</div></div>, sort: (m) => m.name },
          { key: "x", label: "Expertise", render: (m) => m.expertise.join(", ") },
          { key: "r", label: "Hourly Rate", render: (m) => `${inr(m.hourlyRate)}/hr`, sort: (m) => m.hourlyRate },
          { key: "s", label: "Status", render: (m) => <StatusBadge status={m.status} /> },
          { key: "view", label: "View Profile", render: () => <span className="underline">View Profile →</span> },
        ]}
      />
    </div>
  );
}
