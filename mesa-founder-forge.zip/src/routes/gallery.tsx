import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, nameOf } from "@/lib/mesa/selectors";
import { galleryAction, publicSnapshot, withdrawConsent } from "@/lib/mesa/logic";
import { ActionButton, DataTable, DemoNote, Field, HistoryList, PageHeader, ReviewActions, StatusBadge } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { pageHead } from "@/components/mesa/forms";
import { cn } from "@/lib/utils";
import type { GalleryItem } from "@/lib/mesa/types";

export const Route = createFileRoute("/gallery")({
  head: () => pageHead("Venture Gallery", "Review startup profiles, stories and media before public publication."),
  component: Gallery,
});

function Gallery() {
  const d = useData();
  const [sel, setSel] = useState<string | null>(null);
  const items = d.gallery;
  const selected = d.gallery.find((g) => g.id === sel);
  return (
    <div>
      <PageHeader title="Venture Gallery" subtitle="Review startup profiles, stories and media before public publication." />
      <DemoNote>Admin review area for the separate public Venture Gallery website. Only members with granted individual consent appear publicly — a team leader cannot consent for others.</DemoNote>
      <DataTable
        rows={items}
        rowKey={(g) => g.id}
        onRowClick={(g) => setSel(g.id)}
        columns={[
          { key: "t", label: "Startup", render: (g) => <div><div className="font-semibold text-cream">{g.title}</div><div className="text-xs text-muted-foreground">{nameOf(d, g.ventureId)}</div></div>, sort: (g) => g.title },
          { key: "ty", label: "Content Type", render: (g) => g.type },
          { key: "by", label: "Submitted by", render: (g) => (g.ventureId ? `${nameOf(d, g.ventureId)} team leader` : "Programme") },
          { key: "at", label: "Date", render: (g) => fmtDate(g.submittedAt), sort: (g) => g.submittedAt },
          { key: "s", label: "Status", render: (g) => <StatusBadge status={g.status} /> },
          { key: "review", label: "Review", render: (g) => <Button size="sm" variant="link" onClick={() => setSel(g.id)}>Review →</Button> },
        ]}
      />
      {selected && <GalleryDetail g={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

export function GalleryDetail({ g, onClose }: { g: GalleryItem; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [preview, setPreview] = useState(false);
  const snap = publicSnapshot(d, g);
  const act = (a: Parameters<typeof galleryAction>[3], r = "") => run((dd, ac) => galleryAction(dd, ac, g.id, a, r), `Gallery: ${a}`);
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">{g.title}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={g.status} />
          {g.featured && <StatusBadge status="Featured" />}
          <span className="text-xs text-muted-foreground">{g.type} · submitted {fmtDate(g.submittedAt)}</span>
        </div>
        <h3 className="mt-4 font-semibold">Profile</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Startup">{nameOf(d, g.ventureId)}</Field>
          <Field label="Public tagline">{g.tagline}</Field>
          {g.problem && <Field label="Problem">{g.problem}</Field>}
          {g.solution && <Field label="Solution">{g.solution}</Field>}
        </div>
        <p className="mt-3 text-sm">{g.body}</p>
        {g.links.length > 0 && (
          <ul className="mt-2 space-y-1 text-sm">
            {g.links.map((l) => <li key={l}><a href={l} target="_blank" rel="noreferrer" className="underline">{l}</a></li>)}
          </ul>
        )}
        <h3 className="mb-2 mt-5 font-semibold">Team Members</h3>
        <ul className="flex flex-wrap gap-2 text-sm">
          {g.members.map((m) => (
            <li key={m.studentId} className="flex items-center gap-2 rounded-full border border-border px-3 py-1">
              {nameOf(d, m.studentId)}{m.hasPhoto ? " 📷" : ""} <StatusBadge status={m.consent} />
              {m.consent === "Granted" && <button className="text-xs underline" onClick={() => run((dd, a) => withdrawConsent(dd, a, g.id, m.studentId), "Consent withdrawn")}>Withdraw</button>}
            </li>
          ))}
          {!g.members.length && <li className="text-muted-foreground">No members proposed for display.</li>}
        </ul>
        <p className="mt-2 text-xs text-muted-foreground">Members without granted consent are excluded from the public version automatically. Photos are optional.</p>
        <h3 className="mt-4 font-semibold">Milestones</h3><p className="text-sm">{g.type === "Event" ? g.body : "No milestone content in this demo submission."}</p>
        <h3 className="mt-4 font-semibold">Updates</h3><p className="text-sm">{g.type === "Update" || g.type === "Founder Story" ? g.body : "No updates in this demo submission."}</p>
        <h3 className="mt-4 font-semibold">Media</h3><p className="text-sm">{g.type === "Media" ? g.links.join(", ") || "No media attached." : "No media attachments in this demo submission."}</p>
        <h3 className="mt-4 font-semibold">Public Preview</h3>
        <div className="mt-4 flex flex-wrap gap-2">
          {g.status === "Pending" && (
            <ReviewActions onDecision={(decision, reason) => act(decision, reason)} />
          )}
          {(g.status === "Approved" || g.status === "Unpublished") && <ActionButton label="Publish" title="Publish approved snapshot publicly?" onConfirm={() => act("Published")} />}
          {g.status === "Published" && (
            <>
              <Button size="sm" variant="outline" onClick={() => act(g.featured ? "Unfeature" : "Feature")}>{g.featured ? "Unfeature" : "Feature"}</Button>
              <ActionButton label="Unpublish" variant="outline" title="Unpublish?" optionalNote onConfirm={(r) => act("Unpublished", r)} />
            </>
          )}
          <Button size="sm" variant="ghost" onClick={() => setPreview(!preview)}>{preview ? "Hide" : "Preview"} public version</Button>
        </div>
        {preview && (
          <div className="mt-3 rounded-xl bg-ivory p-4 text-maroon">
            <div className="font-display text-xl">{snap.title}</div>
            <div className="text-sm">{snap.tagline}</div>
            <p className="mt-2 text-sm">{snap.body}</p>
            <div className="mt-2 text-xs">Team shown publicly: {snap.team.map((t) => t.name).join(", ") || "No consenting members"}</div>
            <div className="mt-2 text-xs opacity-70">Public-safe snapshot only — internal reports, evidence, invoices and private contacts are never included.</div>
          </div>
        )}
        <h3 className="mb-2 mt-5 font-semibold">Version & review history</h3>
        <HistoryList items={g.history} />
      </DialogContent>
    </Dialog>
  );
}
