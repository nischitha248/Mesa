import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, nameOf } from "@/lib/mesa/selectors";
import { createAdminRequest, setAdminRequestStatus } from "@/lib/mesa/logic";
import { DataTable, DemoNote, Field, FilterSelect, HistoryList, matches, PageHeader, StatusBadge, Toolbar } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { pageHead } from "@/components/mesa/forms";
import { Plus } from "lucide-react";
import type { AdminRequest } from "@/lib/mesa/types";

export const Route = createFileRoute("/requests")({
  head: () => pageHead("Requests", "Structured requests from Admin to startups and mentors."),
  component: RequestsPage,
});

function RequestsPage() {
  const d = useData();
  const [status, setStatus] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const rows = d.adminRequests.filter((r) => matches(status, r.status));
  const selected = d.adminRequests.find((r) => r.id === sel);
  return (
    <div>
      <PageHeader
        title="Requests"
        subtitle="Structured requests to a startup's Student Workspace account or an individual mentor."
        actions={<Button onClick={() => setCreateOpen(true)}><Plus className="mr-1 h-4 w-4" />New Request</Button>}
      />
      <DemoNote>Delivery and responses are simulated until a shared backend is connected. Requests link to existing records instead of creating duplicate tasks.</DemoNote>
      <Toolbar>
        <FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Sent", "Acknowledged", "Completed", "Overdue", "Cancelled"]} />
      </Toolbar>
      <DataTable
        rows={rows}
        rowKey={(r) => r.id}
        onRowClick={(r) => setSel(r.id)}
        columns={[
          { key: "t", label: "Title", render: (r) => <span className="font-semibold text-cream">{r.title}</span>, sort: (r) => r.title },
          { key: "to", label: "Recipient", render: (r) => `${nameOf(d, r.recipientId)} (${r.recipientType})` },
          { key: "dl", label: "Deadline", render: (r) => fmtDate(r.deadline), sort: (r) => r.deadline },
          { key: "lk", label: "Linked", render: (r) => (r.linkedId ? `${r.linkedType} ${r.linkedId}` : "—") },
          { key: "at", label: "Sent", render: (r) => fmtDate(r.createdAt) },
          { key: "s", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
        ]}
      />
      <CreateRequestDialog open={createOpen} onClose={() => setCreateOpen(false)} />
      {selected && <RequestDetail r={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

function CreateRequestDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const empty = { title: "", message: "", recipientType: "startup" as "startup" | "mentor", recipientId: "", deadline: "", linkedType: "", linkedId: "" };
  const [f, setF] = useState(empty);
  const save = () => run((dd, a) => createAdminRequest(dd, a, f), "Request sent") && (setF(empty), onClose());
  const recipients = f.recipientType === "startup" ? d.ventures.map((v) => ({ id: v.id, name: v.name })) : d.mentors.map((m) => ({ id: m.id, name: m.name }));
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>New Request</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Title</Label><Input className="mt-1 bg-ivory text-maroon" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div><Label>Message</Label><Textarea className="mt-1 bg-ivory text-maroon" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label>Recipient type</Label>
              <Select value={f.recipientType} onValueChange={(v) => setF({ ...f, recipientType: v as "startup", recipientId: "" })}>
                <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="startup">Startup (team leader)</SelectItem>
                  <SelectItem value="mentor">Mentor</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Recipient</Label>
              <Select value={f.recipientId} onValueChange={(v) => setF({ ...f, recipientId: v })}>
                <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue placeholder="Select…" /></SelectTrigger>
                <SelectContent>{recipients.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Deadline (optional)</Label><Input type="date" className="mt-1 bg-ivory text-maroon" value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></div>
            <div>
              <Label>Linked record (optional)</Label>
              <Select value={f.linkedType} onValueChange={(v) => setF({ ...f, linkedType: v, linkedId: "" })}>
                <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="goal">Goal</SelectItem>
                  <SelectItem value="meeting">Meeting</SelectItem>
                  <SelectItem value="report">Report</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {f.linkedType && (
              <div>
                <Label>Record</Label>
                <Select value={f.linkedId} onValueChange={(v) => setF({ ...f, linkedId: v })}>
                  <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue placeholder="Select…" /></SelectTrigger>
                  <SelectContent>
                    {(f.linkedType === "goal" ? d.goals.map((g) => ({ id: g.id, name: g.title })) : f.linkedType === "meeting" ? d.meetings.map((m) => ({ id: m.id, name: m.id })) : d.reports.map((r) => ({ id: r.id, name: r.id }))).map((r) => (
                      <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save}>Send request</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RequestDetail({ r, onClose }: { r: AdminRequest; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle className="font-display text-2xl">{r.title}</DialogTitle></DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Recipient">{nameOf(d, r.recipientId)} ({r.recipientType})</Field>
          <Field label="Status"><StatusBadge status={r.status} /></Field>
          <Field label="Deadline">{fmtDate(r.deadline)}</Field>
          <Field label="Sent">{fmtDate(r.createdAt)}</Field>
        </div>
        <p className="mt-3 text-sm">{r.message}</p>
        {r.linkedId && (
          <p className="mt-2 text-sm">
            Linked: {r.linkedType}{" "}
            {r.linkedType === "goal" ? <Link to="/goals" className="underline">{r.linkedId}</Link> : r.linkedType === "meeting" ? <Link to="/calendar" className="underline">{r.linkedId}</Link> : <Link to="/meeting-reports" className="underline">{r.linkedId}</Link>}
          </p>
        )}
        {(r.status === "Sent" || r.status === "Overdue") && (
          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => run((dd, a) => setAdminRequestStatus(dd, a, r.id, "Acknowledged"), "Simulated: acknowledged")}>Simulate acknowledge</Button>
            <Button size="sm" variant="outline" onClick={() => run((dd, a) => setAdminRequestStatus(dd, a, r.id, "Completed"), "Simulated: completed")}>Simulate complete</Button>
            <Button size="sm" variant="destructive" onClick={() => run((dd, a) => setAdminRequestStatus(dd, a, r.id, "Cancelled"), "Request cancelled")}>Cancel request</Button>
          </div>
        )}
        {r.status === "Acknowledged" && (
          <div className="mt-4 flex gap-2">
            <Button size="sm" variant="outline" onClick={() => run((dd, a) => setAdminRequestStatus(dd, a, r.id, "Completed"), "Simulated: completed")}>Simulate complete</Button>
            <Button size="sm" variant="destructive" onClick={() => run((dd, a) => setAdminRequestStatus(dd, a, r.id, "Cancelled"), "Request cancelled")}>Cancel request</Button>
          </div>
        )}
        <h3 className="mb-2 mt-5 font-semibold">History</h3>
        <HistoryList items={r.history} />
      </DialogContent>
    </Dialog>
  );
}
