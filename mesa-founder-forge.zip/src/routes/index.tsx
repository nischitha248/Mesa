import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { GoalDetail } from "./goals";
import { RequestCard } from "./meeting-requests";
import { ReportDetail } from "./meeting-reports";
import { InvoiceDetail } from "./invoices";
import { GalleryDetail } from "./gallery";
import { useData, useMesa } from "@/lib/mesa/store";
import { counts, fmtDateTime, goalEvidenceStatus, nameOf, overdueReportMeetings } from "@/lib/mesa/selectors";
import { DemoNote, EmptyState, PageHeader, Panel, StatCard, StatusBadge } from "@/components/mesa/ui";
import { pageHead } from "@/components/mesa/forms";

export const Route = createFileRoute("/")({
  head: () => pageHead("Programme Overview", "Manage ventures, mentorship and programme progress in one place."),
  component: Dashboard,
});

interface AttentionItem {
  key: string;
  label: string;
  to: string;
}

function Dashboard() {
  const d = useData();
  const [selected, setSelected] = useState<string | null>(null);
  const goal = d.goals.find((g) => `ev-${g.id}` === selected);
  const request = d.requests.find((r) => `req-${r.id}` === selected);
  const report = d.reports.find((r) => `rpt-${r.id}` === selected);
  const invoice = d.invoices.find((i) => `inv-${i.id}` === selected);
  const gallery = d.gallery.find((g) => `gal-${g.id}` === selected);
  const open = useMesa((s) => s.openMeeting);
  const c = counts(d);
  const upcoming = d.meetings
    .filter((m) => m.status === "Scheduled" && new Date(m.start).getTime() > Date.now())
    .sort((a, b) => a.start.localeCompare(b.start))
    .slice(0, 5);
  const overdue = overdueReportMeetings(d);

  const attention: AttentionItem[] = [
    ...d.ventures.filter((v) => v.applicationStatus === "Pending").map((v) => ({ key: `app-${v.id}`, label: `Startup application: ${v.name}`, to: `/startups/${v.id}` })),
    ...d.mentors.filter((m) => m.status === "Pending Approval").map((m) => ({ key: `men-${m.id}`, label: `Mentor application: ${m.name}`, to: `/mentors/${m.id}` })),
    ...d.requests.filter((r) => r.status === "Pending").map((r) => ({ key: `req-${r.id}`, label: `Meeting request ${r.id}: ${nameOf(d, r.ventureId)} → ${nameOf(d, r.mentorId)}`, to: "/meeting-requests" })),
    ...d.goals.filter((g) => goalEvidenceStatus(g) === "Pending Review").map((g) => ({ key: `ev-${g.id}`, label: `Evidence: ${g.title} (${nameOf(d, g.ventureId)})`, to: "/goals" })),
    ...d.reports.filter((r) => r.status === "Pending Review").map((r) => ({ key: `rpt-${r.id}`, label: `Mentor report ${r.id}: ${nameOf(d, r.ventureId)}`, to: "/meeting-reports" })),
    ...d.invoices.filter((i) => i.status === "Submitted" || i.status === "Under Review").map((i) => ({ key: `inv-${i.id}`, label: `Invoice ${i.id}: ${nameOf(d, i.mentorId)}`, to: "/invoices" })),
    ...d.gallery.filter((g) => g.status === "Pending").map((g) => ({ key: `gal-${g.id}`, label: `Gallery submission: ${g.title}`, to: "/gallery" })),
    ...overdue.map((m) => ({ key: `od-${m.id}`, label: `Overdue report: ${m.id} (${nameOf(d, m.mentorId)})`, to: "/calendar" })),
  ];

  const pendingApprovals = c.pendingApplications + c.pendingMentors;
  const reviewItems = c.evidencePending + c.reportsPending + c.invoicesPending + c.galleryPending;

  return (
    <div>
      <PageHeader title="Programme Overview" subtitle="Manage ventures, mentorship and programme progress in one place." />
      <DemoNote />
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Active Ventures" value={c.activeVentures} to="/startups" />
        <StatCard label="Pending Approvals" value={pendingApprovals} to="/startups" search={{ tab: "applications" }} tone="accent" />
        <StatCard label="Upcoming Meetings" value={c.upcomingMeetings} to="/calendar" />
        <StatCard label="Items Requiring Review" value={reviewItems} to="/meeting-reports" />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Panel title="Requires Your Attention">
          {attention.length ? (
            <ul className="divide-y divide-border">
              {attention.slice(0, 10).map((a) => (
                <li key={a.key}>
                  {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                  <Link to={a.to as any} onClick={(e) => { if (a.key.startsWith("od-")) { e.preventDefault(); open(a.key.slice(3)); } else if (!a.key.startsWith("app-") && !a.key.startsWith("men-")) { e.preventDefault(); setSelected(a.key); } }} className="flex items-center justify-between gap-2 py-2.5 text-sm hover:text-cream">
                    <span>{a.label}</span>
                    <span className="shrink-0 text-xs text-peach">Open →</span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState text="Nothing needs your attention right now." />
          )}
          {attention.length > 10 && <p className="mt-2 text-xs text-muted-foreground">+{attention.length - 10} more across the workspace.</p>}
        </Panel>
        <Panel title="Upcoming Meetings" actions={<Link to="/calendar" className="text-sm underline">Calendar</Link>}>
          {upcoming.length ? (
            <ul className="divide-y divide-border">
              {upcoming.map((m) => (
                <li key={m.id}>
                  <Button variant="ghost" onClick={() => open(m.id)} className="h-auto w-full flex-wrap justify-between gap-2 whitespace-normal py-3 text-left text-sm">
                    <span>{nameOf(d, m.ventureId)} · {nameOf(d, m.mentorId)}</span>
                    <span className="flex items-center gap-2">
                      <span className="text-muted-foreground">{fmtDateTime(m.start)}</span>
                      <StatusBadge status={m.status} />
                    </span>
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState text="No scheduled meetings." />
          )}
        </Panel>
      </div>
      {goal && <GoalDetail goal={goal} onClose={() => setSelected(null)} />}
      {invoice && <InvoiceDetail inv={invoice} onClose={() => setSelected(null)} />}
      {gallery && <GalleryDetail g={gallery} onClose={() => setSelected(null)} />}
      <Dialog open={!!request || !!report} onOpenChange={(o) => !o && setSelected(null)}><DialogContent className="max-w-2xl"><DialogHeader><DialogTitle>{request ? `Meeting Request ${request.id}` : `Mentor Report ${report?.id}`}</DialogTitle></DialogHeader>{request && <RequestCard r={request} />}{report && <ReportDetail r={report} />}</DialogContent></Dialog>
    </div>
  );
}
