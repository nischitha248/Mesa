import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDateTime, nameOf } from "@/lib/mesa/selectors";
import { reviewReport } from "@/lib/mesa/logic";
import { ActionButton, DemoNote, EmptyState, FilterSelect, HistoryList, matches, PageHeader, Panel, SectionTabs, StatusBadge, Toolbar } from "@/components/mesa/ui";
import { pageHead } from "@/components/mesa/forms";
import type { MeetingReport } from "@/lib/mesa/types";
import { MENTOR_TABS } from "./mentors";

export const Route = createFileRoute("/meeting-reports")({
  head: () => pageHead("Meeting Reports", "Review mentor meeting reports and the tasks they create."),
  component: Reports,
});

function Reports() {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [status, setStatus] = useState("all");
  const rows = d.reports.filter((r) => matches(status, r.status));
  return (
    <div>
      <PageHeader title="Meeting Reports" subtitle="Reports are due within 24 hours of a completed meeting." />
      <DemoNote />
      <SectionTabs tabs={MENTOR_TABS} current="/meeting-reports" />
      <Toolbar><FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Pending Review", "Approved", "Changes Requested", "Rejected"]} /></Toolbar>
      <div className="space-y-4">
        {rows.map((r) => {
          return <ReportDetail key={r.id} r={r} />;
        })}
        {!rows.length && <EmptyState />}
      </div>
    </div>
  );
}

export function ReportDetail({ r }: { r: MeetingReport }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const v = r.versions[r.versions.length - 1];
  return (
            <Panel title={`${r.id} · ${nameOf(d, r.ventureId)} with ${nameOf(d, r.mentorId)}`} actions={<StatusBadge status={r.status} />}>
              {v && (
                <div className="space-y-2 text-sm">
                  <p className="text-xs text-muted-foreground">Version {v.version} · submitted {fmtDateTime(v.submittedAt)}</p>
                  <p><strong>Linked meeting:</strong> {r.meetingId}</p>
                  <p><strong>Summary:</strong> {v.summary}</p>
                  <p><strong>Notes:</strong> {v.notes}</p>
                  <p><strong>Recommendations:</strong> {v.recommendations}</p>
                  <p><strong>Attachments:</strong> No attachments in this demo record.</p>
                  <p><strong>Tasks created:</strong> {r.taskGoalIds.map((g) => d.goals.find((x) => x.id === g)?.title ?? g).join(", ") || "None"}</p>
                </div>
              )}
              {r.status === "Pending Review" && (
                <div className="mt-4 flex flex-wrap gap-2">
                  <ActionButton label="Approve" title="Approve report?" onConfirm={() => run((dd, a) => reviewReport(dd, a, r.id, "Approved"), "Report approved")} />
                  <ActionButton label="Request changes" variant="outline" title="Request changes" requireReason onConfirm={(f) => run((dd, a) => reviewReport(dd, a, r.id, "Changes Requested", f), "Changes requested")} />
                  <ActionButton label="Reject" variant="destructive" title="Reject report" description="Linked student tasks stay visible but are flagged." requireReason onConfirm={(f) => run((dd, a) => reviewReport(dd, a, r.id, "Rejected", f), "Report rejected")} />
                </div>
              )}
              <h3 className="mb-2 mt-4 text-sm font-semibold">History</h3>
              <HistoryList items={r.history} />
            </Panel>
  );
}
