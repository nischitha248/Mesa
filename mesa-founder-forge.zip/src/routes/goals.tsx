import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fileKind, fmtDate, fmtDateTime, goalEvidenceStatus, latestSubmission, nameOf } from "@/lib/mesa/selectors";
import { createGoal, reviewEvidence } from "@/lib/mesa/logic";
import { DataTable, DemoNote, Field, FilterSelect, matches, PageHeader, Panel, ReviewActions, SearchBox, StatusBadge, textMatch, Toolbar } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { pageHead } from "@/components/mesa/forms";
import { Plus } from "lucide-react";
import type { Goal } from "@/lib/mesa/types";

export const Route = createFileRoute("/goals")({
  head: () => pageHead("Goals & Evidence", "Assign goals, review submissions and track venture progress."),
  component: Goals,
});

const CATEGORIES = ["Customer", "Product", "Finance", "Partnerships", "Research", "Brand", "Compliance", "Fundraising"];

function Goals() {
  const d = useData();
  const cohortFilter = useMesa((s) => s.cohortFilter);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [venture, setVenture] = useState("all");
  const [assignedBy, setAssignedBy] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const rows = d.goals.filter((g) => {
    const v = d.ventures.find((x) => x.id === g.ventureId);
    return (
      textMatch(q, g.title, v?.name) &&
      matches(status, goalEvidenceStatus(g)) &&
      matches(venture, nameOf(d, g.ventureId)) &&
      matches(assignedBy, g.assignedBy) &&
      (!v || matches(cohortFilter, v.cohort))
    );
  });
  const selected = d.goals.find((g) => g.id === sel);
  return (
    <div>
      <PageHeader
        title="Goals & Evidence"
        subtitle="Assign goals, review submissions and track venture progress."
        actions={<Button onClick={() => setAddOpen(true)}><Plus className="mr-1 h-4 w-4" />Add Goal</Button>}
      />
      <DemoNote>Admin can approve evidence directly — mentor verification is optional and never a prerequisite. Evidence approval does not change MSL readiness.</DemoNote>
      <Toolbar>
        <SearchBox value={q} onChange={setQ} placeholder="Search goals…" />
        <FilterSelect label="Startups" value={venture} onChange={setVenture} options={d.ventures.map((v) => v.name)} />
        <FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Not Submitted", "Pending Review", "Approved", "Changes Requested", "Rejected"]} />
        <FilterSelect label="Assigned by" value={assignedBy} onChange={setAssignedBy} options={["Programme Staff", "Mentor (via report)"]} />
      </Toolbar>
      <DataTable
        rows={rows}
        rowKey={(g) => g.id}
        onRowClick={(g) => setSel(g.id)}
        columns={[
          { key: "t", label: "Task / Goal", render: (g) => <span className="font-semibold text-cream">{g.title}</span>, sort: (g) => g.title },
          { key: "v", label: "Startup", render: (g) => nameOf(d, g.ventureId) },
          { key: "by", label: "Assigned By", render: (g) => g.assignedBy },
          { key: "c", label: "Category", render: (g) => g.category },
          { key: "due", label: "Due Date", render: (g) => fmtDate(g.due), sort: (g) => g.due },
          { key: "ev", label: "Evidence", render: (g) => latestSubmission(g)?.files.length ?? "—" },
          { key: "s", label: "Status", render: (g) => <StatusBadge status={goalEvidenceStatus(g)} /> },
        ]}
      />
      <AddGoalDialog open={addOpen} onClose={() => setAddOpen(false)} />
      {selected && <GoalDetail goal={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

function AddGoalDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const empty = { ventureId: "", title: "", category: "", description: "", due: "", requiredEvidence: "" };
  const [f, setF] = useState(empty);
  const save = () => run((dd, a) => createGoal(dd, a, f), "Goal created") && (setF(empty), onClose());
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Add Goal</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Startup</Label>
            <Select value={f.ventureId} onValueChange={(v) => setF({ ...f, ventureId: v })}>
              <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue placeholder="Select startup…" /></SelectTrigger>
              <SelectContent>
                {d.ventures.filter((v) => v.status === "Active").map((v) => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Goal / task title</Label><Input className="mt-1 bg-ivory text-maroon" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div>
            <Label>Category</Label>
            <Select value={f.category} onValueChange={(v) => setF({ ...f, category: v })}>
              <SelectTrigger className="mt-1 bg-ivory text-maroon"><SelectValue placeholder="Select category…" /></SelectTrigger>
              <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Description</Label><Textarea className="mt-1 bg-ivory text-maroon" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div><Label>Due date</Label><Input type="date" className="mt-1 bg-ivory text-maroon" value={f.due} onChange={(e) => setF({ ...f, due: e.target.value })} /></div>
          <div><Label>Required evidence</Label><Input className="mt-1 bg-ivory text-maroon" value={f.requiredEvidence} onChange={(e) => setF({ ...f, requiredEvidence: e.target.value })} placeholder="What must the team submit?" /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save}>Save & Assign</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function GoalDetail({ goal, onClose }: { goal: Goal; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const latest = latestSubmission(goal);
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">{goal.title}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Startup">{nameOf(d, goal.ventureId)}</Field>
          <Field label="Assigned by">{goal.sourceReportId ? `${nameOf(d, d.reports.find((r) => r.id === goal.sourceReportId)?.mentorId)} · ${goal.sourceReportId}` : goal.assignedBy}</Field>
          {goal.sourceReportId && <Field label="Source meeting">{d.reports.find((r) => r.id === goal.sourceReportId)?.meetingId ?? "—"}</Field>}
          <Field label="Created">{fmtDate(goal.createdAt)}</Field>
          <Field label="Due">{fmtDate(goal.due)}</Field>
          <Field label="Category">{goal.category}</Field>
          <Field label="Mentor verification">{goal.mentorVerification} (optional)</Field>
        </div>
        {goal.description && <p className="mt-3 text-sm text-ivory">{goal.description}</p>}
        <div className="mt-3 rounded-xl border border-border p-3 text-sm">
          <strong>Required evidence:</strong> {goal.requiredEvidence}
        </div>
        {goal.flagged && <p className="mt-3 text-sm text-peach">⚑ {goal.flagged}</p>}
        <h3 className="mb-2 mt-5 font-semibold">Submissions ({goal.submissions.length})</h3>
        {goal.submissions.length ? (
          <div className="space-y-3">
            {[...goal.submissions].reverse().map((s) => (
              <div key={s.number} className="rounded-xl border border-border p-3 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">Version {s.number}</span>
                  <StatusBadge status={s.status} />
                </div>
                <div className="mt-1 text-xs text-muted-foreground">{nameOf(d, s.submittedBy)} · {fmtDateTime(s.submittedAt)}</div>
                <ul className="mt-2 space-y-1">
                  {s.files.map((f) => (
                    <li key={f} className="flex items-center justify-between gap-2 rounded-lg bg-surface-strong px-3 py-1.5 text-xs">
                      <span>{f} <span className="text-muted-foreground">· {fileKind(f)}</span></span>
                      {/^https?:\/\//.test(f) ? (
                        <a href={f} target="_blank" rel="noreferrer" className="underline">Open link</a>
                      ) : (
                        <span className="text-muted-foreground" title="Demo file — no real upload exists">Demo file</span>
                      )}
                    </li>
                  ))}
                </ul>
                {s.notes && <p className="mt-2 text-xs">{s.notes}</p>}
                {s.feedback && <p className="mt-1 text-xs text-peach">Feedback: {s.feedback}{s.reviewedBy ? ` — ${s.reviewedBy}, ${fmtDateTime(s.reviewedAt)}` : ""}</p>}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No submissions yet.</p>
        )}
        {(latest?.status === "Pending Review" || !latest) && (
          <div className="mt-5">
            <ReviewActions
              disabled={!latest}
              approveLabel="Approve Evidence"
              approveTitle="Approve evidence?"
              approveDescription="Direct admin approval. Mentor verification is optional and this does not change MSL readiness."
              onDecision={(decision, reason) => run((dd, a) => reviewEvidence(dd, a, goal.id, decision, reason), `Evidence ${decision.toLowerCase()}`)}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
