import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, fmtDateTime, inr, invoiceAmount, nameOf } from "@/lib/mesa/selectors";
import { assignMentor, changeAssignmentRole, endAssignment, setMentorRate, setMentorStatus } from "@/lib/mesa/logic";
import { ActionButton, DemoNote, EmptyState, Field, HistoryList, PageHeader, Panel, ReviewActions, StatusBadge } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { pageHead, Pick, Row, TextIn } from "@/components/mesa/forms";
import { cn } from "@/lib/utils";
import type { Mentor } from "@/lib/mesa/types";

export const Route = createFileRoute("/mentors_/$mentorId")({
  head: () => pageHead("Mentor Profile", "Complete mentor profile, assignments, meetings, reports and invoices."),
  component: MentorDetail,
});

const TABS = ["Profile", "Assigned Startups", "Meetings", "Meeting Reports", "Invoices", "History"] as const;

function MentorDetail() {
  const { mentorId } = Route.useParams();
  const d = useData();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Profile");
  const m = d.mentors.find((x) => x.id === mentorId);
  if (!m) {
    return (
      <div>
        <PageHeader title="Mentor not found" subtitle="This mentor does not exist in the demo data." />
        <Link to="/mentors" className="text-sm underline">Back to Mentors & Meetings</Link>
      </div>
    );
  }
  return (
    <div>
      <PageHeader title={`${m.name} — Mentor Profile`} subtitle={`${m.title}, ${m.organization}`} actions={<Link to="/mentors" className="text-sm underline">← Mentors</Link>} />
      <DemoNote />
      <div className="mb-6 flex flex-wrap items-center gap-2">
        <StatusBadge status={m.status} />
        <StatusBadge status={m.availability} />
        <span className="rounded-full border border-border px-3 py-0.5 text-xs">{inr(m.hourlyRate)}/hr approved rate</span>
      </div>
      <div className="mb-6 flex flex-wrap gap-1 rounded-full border border-border bg-surface p-1">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn("rounded-full px-3 py-1.5 text-sm font-medium transition-colors", tab === t ? "bg-cream text-maroon" : "text-ivory/80 hover:bg-accent hover:text-cream")}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "Profile" && <ProfileTab m={m} />}
      {tab === "Assigned Startups" && <StartupsTab m={m} />}
      {tab === "Meetings" && <MeetingsTab m={m} />}
      {tab === "Meeting Reports" && <ReportsTab m={m} />}
      {tab === "Invoices" && <InvoicesTab m={m} />}
      {tab === "History" && <Panel title="Mentor history"><HistoryList items={m.history} /></Panel>}
    </div>
  );
}

function ProfileTab({ m }: { m: Mentor }) {
  const run = useMesa((s) => s.run);
  const [rate, setRate] = useState(String(m.hourlyRate));
  return (
    <div className="space-y-6">
      <Panel title="Profile">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Name">{m.name}</Field>
          <Field label="Professional title">{m.title}</Field>
          <Field label="Organization">{m.organization}</Field>
          <Field label="Email">{m.email}</Field>
          <Field label="LinkedIn"><a href={m.linkedin} target="_blank" rel="noreferrer" className="underline">{m.linkedin}</a></Field>
          <Field label="Expertise">{m.expertise.join(", ")}</Field>
          <Field label="Bio">{m.bio}</Field>
          <Field label="Experience">{m.experience}</Field>
          <Field label="Approval status"><StatusBadge status={m.status} /></Field>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {m.status === "Pending Approval" && (
            <ReviewActions
              approveLabel="Approve mentor"
              approveTitle={`Approve ${m.name}?`}
              onDecision={(decision, reason) =>
                run((dd, a) => setMentorStatus(dd, a, m.id, decision === "Approved" ? "Active" : decision, reason), `Mentor ${decision.toLowerCase()}`)
              }
            />
          )}
          {m.status === "Changes Requested" && (
            <ActionButton label="Activate" title={`Activate ${m.name}?`} onConfirm={() => run((dd, a) => setMentorStatus(dd, a, m.id, "Active"), "Mentor active")} />
          )}
          {m.status === "Active" && (
            <ActionButton label="Pause" variant="outline" title="Pause mentor" optionalNote onConfirm={(r) => run((dd, a) => setMentorStatus(dd, a, m.id, "Paused", r), "Mentor paused")} />
          )}
          {m.status === "Paused" && (
            <ActionButton label="Reactivate" title="Reactivate mentor?" onConfirm={() => run((dd, a) => setMentorStatus(dd, a, m.id, "Active"), "Mentor active")} />
          )}
          {m.status !== "Deactivated" && (
            <ActionButton label="Deactivate" variant="destructive" title="Deactivate mentor" optionalNote onConfirm={(r) => run((dd, a) => setMentorStatus(dd, a, m.id, "Deactivated", r), "Mentor deactivated")} />
          )}
        </div>
      </Panel>
      <Panel title="Approved hourly rate">
        <Row>
          <TextIn label="Hourly rate (₹)" type="number" value={rate} onChange={setRate} />
          <Button size="sm" onClick={() => run((dd, a) => setMentorRate(dd, a, m.id, Number(rate)), "Rate updated")}>Save rate</Button>
        </Row>
        <p className="mt-2 text-xs text-muted-foreground">Invoices use this approved rate × the admin-approved scheduled meeting duration.</p>
      </Panel>
      <Panel title="Published availability">
        {m.publishedSlots.length ? (
          <ul className="flex flex-wrap gap-2 text-sm">
            {m.publishedSlots.map((s) => <li key={s} className="rounded-full border border-border px-3 py-1">{fmtDateTime(s)}</li>)}
          </ul>
        ) : <p className="text-sm text-muted-foreground">No published slots.</p>}
      </Panel>
    </div>
  );
}

function StartupsTab({ m }: { m: Mentor }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [f, setF] = useState({ ventureId: "", role: "Principal Mentor", focus: "", note: "" });
  const list = d.assignments.filter((a) => a.mentorId === m.id);
  return (
    <div className="space-y-6">
      <Panel title="Assignments">
        <ul className="divide-y divide-border">
          {list.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
              <span>
                <Link to="/startups/$ventureId" params={{ ventureId: a.ventureId }} className="font-semibold text-cream underline">{nameOf(d, a.ventureId)}</Link>
                <StatusBadge status={a.role} className="ml-2" />
                <span className="ml-2 text-xs text-muted-foreground">{a.focus} · since {fmtDate(a.start)} · {a.status}</span>
              </span>
              {a.status === "Active" && (
                <span className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => run((dd, ac) => changeAssignmentRole(dd, ac, a.id), "Role changed")}>Switch role</Button>
                  <ActionButton label="End" variant="destructive" title="End assignment" optionalNote onConfirm={(r) => run((dd, ac) => endAssignment(dd, ac, a.id, r), "Assignment ended")} />
                </span>
              )}
            </li>
          ))}
          {!list.length && <li className="py-3 text-sm text-muted-foreground">No assignments.</li>}
        </ul>
      </Panel>
      {m.status === "Active" && (
        <Panel title="Assign to a startup">
          <Row>
            <Pick label="Venture" value={f.ventureId} onChange={(x) => setF({ ...f, ventureId: x })} options={d.ventures.filter((v) => v.status === "Active").map((v) => ({ value: v.id, label: v.name }))} />
            <Pick label="Role" value={f.role} onChange={(x) => setF({ ...f, role: x })} options={[{ value: "Principal Mentor", label: "Principal Mentor" }, { value: "Associate Mentor", label: "Associate Mentor" }]} />
            <TextIn label="Focus" value={f.focus} onChange={(x) => setF({ ...f, focus: x })} />
            <TextIn label="Note" value={f.note} onChange={(x) => setF({ ...f, note: x })} />
            <Button size="sm" disabled={!f.ventureId} onClick={() => run((dd, a) => assignMentor(dd, a, { ventureId: f.ventureId, mentorId: m.id, role: f.role as "Principal Mentor", focus: f.focus, note: f.note }), "Mentor assigned") && setF({ ventureId: "", role: "Principal Mentor", focus: "", note: "" })}>Assign</Button>
          </Row>
        </Panel>
      )}
    </div>
  );
}

function MeetingsTab({ m }: { m: Mentor }) {
  const d = useData();
  const open = useMesa((s) => s.openMeeting);
  const meetings = d.meetings.filter((x) => x.mentorId === m.id).sort((a, b) => b.start.localeCompare(a.start));
  if (!meetings.length) return <EmptyState text="No meetings for this mentor." />;
  return (
    <Panel title="Meetings">
      <ul className="divide-y divide-border text-sm">
        {meetings.map((x) => (
          <li key={x.id}>
            <button onClick={() => open(x.id)} className="flex w-full flex-wrap items-center justify-between gap-2 py-2 text-left hover:text-cream">
              <span>{x.id} · {fmtDateTime(x.start)} · {x.durationMin} min · {nameOf(d, x.ventureId)}</span>
              <span className="flex items-center gap-2">
                {x.adminVerifiedAt && <StatusBadge status="Verified" />}
                <StatusBadge status={x.status} />
              </span>
            </button>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function ReportsTab({ m }: { m: Mentor }) {
  const d = useData();
  const reports = d.reports.filter((r) => r.mentorId === m.id);
  if (!reports.length) return <EmptyState text="No reports submitted by this mentor." />;
  return (
    <Panel title="Meeting reports">
      <ul className="divide-y divide-border text-sm">
        {reports.map((r) => {
          const v = r.versions[r.versions.length - 1];
          return (
            <li key={r.id} className="py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-semibold text-cream">{r.id} · {nameOf(d, r.ventureId)}</span>
                <StatusBadge status={r.status} />
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                Meeting {r.meetingId} · v{v?.version} submitted {fmtDateTime(v?.submittedAt)} · follow-up tasks: {r.taskGoalIds.map((g) => d.goals.find((x) => x.id === g)?.title ?? g).join(", ") || "none"}
              </div>
            </li>
          );
        })}
      </ul>
    </Panel>
  );
}

function InvoicesTab({ m }: { m: Mentor }) {
  const d = useData();
  const invoices = d.invoices.filter((i) => i.mentorId === m.id);
  if (!invoices.length) return <EmptyState text="No invoices from this mentor." />;
  return (
    <Panel title="Invoices" actions={<Link to="/invoices" className="text-sm underline">Open Invoices</Link>}>
      <ul className="divide-y divide-border text-sm">
        {invoices.map((i) => (
          <li key={i.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
            <span>{i.id} · meeting {i.meetingId} · {nameOf(d, i.ventureId)} · <strong>{inr(invoiceAmount(i))}</strong></span>
            <StatusBadge status={i.status} />
          </li>
        ))}
      </ul>
    </Panel>
  );
}
