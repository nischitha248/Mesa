import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDateTime, nameOf } from "@/lib/mesa/selectors";
import { DataTable, DemoNote, FilterSelect, matches, PageHeader, SectionTabs, StatusBadge, Toolbar } from "@/components/mesa/ui";
import { pageHead } from "@/components/mesa/forms";
import { MENTOR_TABS } from "./mentors";

export const Route = createFileRoute("/calendar")({
  head: () => pageHead("Mentorship Calendar", "All scheduled, completed and cancelled mentorship meetings."),
  component: Calendar,
});

function Calendar() {
  const d = useData();
  const open = useMesa((s) => s.openMeeting);
  const [status, setStatus] = useState("all");
  return (
    <div>
      <PageHeader title="Mentorship Calendar" subtitle="Click a meeting to see details and verify completion." />
      <DemoNote />
      <SectionTabs tabs={MENTOR_TABS} current="/calendar" />
      <Toolbar><FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Scheduled", "Completed", "Cancelled"]} /></Toolbar>
      <DataTable
        rows={d.meetings.filter((m) => matches(status, m.status))}
        rowKey={(m) => m.id}
        onRowClick={(m) => open(m.id)}
        columns={[
          { key: "t", label: "When", render: (m) => fmtDateTime(m.start), sort: (m) => m.start },
          { key: "v", label: "Venture", render: (m) => nameOf(d, m.ventureId) },
          { key: "m", label: "Mentor", render: (m) => nameOf(d, m.mentorId) },
          { key: "d", label: "Duration", render: (m) => `${m.durationMin} min` },
          { key: "mo", label: "Mode", render: (m) => m.mode },
          { key: "s", label: "Status", render: (m) => <StatusBadge status={m.status} /> },
          { key: "vf", label: "Verified", render: (m) => (m.adminVerifiedAt ? <StatusBadge status="Verified" /> : "—") },
        ]}
      />
    </div>
  );
}
