import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDateTime } from "@/lib/mesa/selectors";
import { DemoNote, EmptyState, PageHeader, Panel } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { pageHead } from "@/components/mesa/forms";

export const Route = createFileRoute("/notifications")({
  head: () => pageHead("Notifications", "Workflow alerts for the Admin Workspace."),
  component: Notifications,
});

function Notifications() {
  const d = useData();
  const setData = useMesa((s) => s.setData);
  const navigate = useNavigate();
  const markAll = () => setData((dd) => dd.notifications.forEach((n) => (n.read = true)));
  return (
    <div>
      <PageHeader title="Notifications" actions={<Button variant="outline" onClick={markAll}>Mark all read</Button>} />
      <DemoNote />
      <Panel>
        {d.notifications.length ? (
          <ul className="divide-y divide-border">
            {d.notifications.map((n) => (
              <li key={n.id}>
                <button
                  className="flex w-full items-start justify-between gap-3 py-3 text-left text-sm hover:text-cream"
                  onClick={() => {
                    setData((dd) => { const x = dd.notifications.find((y) => y.id === n.id); if (x) x.read = true; });
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    navigate({ to: ("/" + (n.link.split("/")[1] ?? "")) as any });
                  }}
                >
                  <span>
                    {!n.read && <span className="mr-2 inline-block h-2 w-2 rounded-full bg-crimson" aria-label="Unread" />}
                    <strong>{n.type}</strong> — {n.text}
                  </span>
                  <span className="shrink-0 text-xs text-muted-foreground">{fmtDateTime(n.at)}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : <EmptyState text="No notifications." />}
      </Panel>
    </div>
  );
}
