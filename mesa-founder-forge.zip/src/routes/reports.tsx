import { createFileRoute } from "@tanstack/react-router";
import { useData } from "@/lib/mesa/store";
import { inr, invoiceAmount } from "@/lib/mesa/selectors";
import { DemoNote, PageHeader, Panel, StatCard } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { pageHead } from "@/components/mesa/forms";

export const Route = createFileRoute("/reports")({
  head: () => pageHead("Reports", "Programme summaries for ventures, mentorship and invoices."),
  component: ReportsPage,
});

function ReportsPage() {
  const d = useData();
  const active = d.ventures.filter((v) => v.status === "Active");
  const completed = d.meetings.filter((m) => m.status === "Completed");
  const hours = completed.reduce((s, m) => s + m.durationMin, 0) / 60;
  const paid = d.invoices.filter((i) => i.status === "Paid").reduce((s, i) => s + invoiceAmount(i), 0);
  const outstanding = d.invoices.filter((i) => i.status === "Approved").reduce((s, i) => s + invoiceAmount(i), 0);
  const exportAudit = () => {
    const rows = [["at", "actor", "action", "entity", "id", "prev", "next", "reason"], ...d.audit.map((a) => [a.at, a.actor, a.action, a.entity, a.entityId, a.prev, a.next, a.reason])];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const el = document.createElement("a");
    el.href = url;
    el.download = "mesa-audit-log.csv";
    el.click();
    URL.revokeObjectURL(url);
  };
  return (
    <div>
      <PageHeader title="Reports" subtitle="Summary figures from the demo data." actions={<Button onClick={exportAudit}>Export audit log (CSV)</Button>} />
      <DemoNote />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
        <StatCard label="Active ventures" value={active.length} />
        <StatCard label="ILS / MSL" value={`${active.filter((v) => v.programme === "ILS").length} / ${active.filter((v) => v.programme === "MSL").length}`} />
        <StatCard label="Mentorship hours" value={hours.toFixed(1)} />
        <StatCard label="Paid to mentors" value={inr(paid)} />
        <StatCard label="Approved, unpaid" value={inr(outstanding)} tone="accent" />
      </div>
      <Panel title="Ventures by sector" className="mt-6">
        <ul className="space-y-2 text-sm">
          {Object.entries(active.reduce<Record<string, number>>((acc, v) => ({ ...acc, [v.sector]: (acc[v.sector] ?? 0) + 1 }), {})).map(([s, n]) => (
            <li key={s} className="flex items-center gap-3">
              <span className="w-40">{s}</span>
              <span className="h-3 rounded-full bg-peach" style={{ width: `${n * 40}px` }} />
              <span>{n}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
