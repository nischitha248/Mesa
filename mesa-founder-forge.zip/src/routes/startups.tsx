import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, leaderOf } from "@/lib/mesa/selectors";
import { decideApplication } from "@/lib/mesa/logic";
import { DataTable, DemoNote, FilterSelect, matches, PageHeader, ReviewActions, SearchBox, SectionTabs, StatusBadge, textMatch, Toolbar } from "@/components/mesa/ui";
import { pageHead } from "@/components/mesa/forms";

export const STARTUP_TABS = [
  { label: "All Startups", to: "/startups" },
  { label: "Startup Applications", to: "/startups?tab=applications" },
  { label: "Students & Teams", to: "/students" },
];

export const Route = createFileRoute("/startups")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined; tab?: string | undefined } => ({
    q: typeof s["q"] === "string" ? (s["q"] as string) : undefined,
    tab: typeof s["tab"] === "string" ? (s["tab"] as string) : undefined,
  }),
  head: () => pageHead("Startup Directory", "Explore startup profiles, team information, submissions and programme history."),
  component: Startups,
});

function Startups() {
  const d = useData();
  const run = useMesa((s) => s.run);
  const cohortFilter = useMesa((s) => s.cohortFilter);
  const navigate = useNavigate();
  const { q: initial, tab } = Route.useSearch();
  const [q, setQ] = useState(initial ?? "");
  const [prog, setProg] = useState("all");
  const [status, setStatus] = useState("all");
  const isApps = tab === "applications";

  const base = d.ventures.filter((v) => matches(cohortFilter, v.cohort));
  const rows = base.filter((v) => {
    if (!textMatch(q, v.name, v.sector, v.cohort)) return false;
    if (!matches(prog, v.programme)) return false;
    if (isApps) return v.applicationStatus !== "Approved" && matches(status, v.applicationStatus);
    return matches(status, v.status);
  });

  return (
    <div>
      <PageHeader title="Startup Directory" subtitle="Explore startup profiles, team information, submissions and programme history." />
      <DemoNote />
      <SectionTabs tabs={STARTUP_TABS} current={isApps ? "/startups?tab=applications" : "/startups"} />
      <Toolbar>
        <SearchBox value={q} onChange={setQ} placeholder="Search ventures…" />
        <FilterSelect label="Programmes" value={prog} onChange={setProg} options={["ILS", "MSL"]} />
        <FilterSelect
          label={isApps ? "Applications" : "Statuses"}
          value={status}
          onChange={setStatus}
          options={isApps ? ["Pending", "Changes Requested", "Rejected"] : ["Active", "Applicant", "Stalled", "Archived", "Not Admitted"]}
        />
      </Toolbar>
      <DataTable
        rows={rows}
        rowKey={(r) => r.id}
        onRowClick={(r) => navigate({ to: "/startups/$ventureId", params: { ventureId: r.id } })}
        columns={[
          { key: "name", label: "Startup", render: (r) => <span className="font-semibold text-cream">{r.name}</span>, sort: (r) => r.name },
          { key: "prog", label: "Programme", render: (r) => r.programme },
          { key: "cohort", label: "Cohort", render: (r) => r.cohort },
          { key: "sector", label: "Sector", render: (r) => r.sector },
          { key: "lead", label: "Team Leader", render: (r) => leaderOf(d, r.id)?.name ?? "—" },
          { key: "mentors", label: "Mentors", render: (r) => d.assignments.filter((a) => a.ventureId === r.id && a.status === "Active").length || "—" },
          { key: "status", label: "Status", render: (r) => <StatusBadge status={isApps ? r.applicationStatus : r.status} /> },
          { key: "last", label: "Last Activity", render: (r) => fmtDate(r.lastActivity), sort: (r) => r.lastActivity },
          ...(isApps
            ? [{
                key: "act",
                label: "Action",
                render: (r: (typeof rows)[number]) =>
                  r.applicationStatus === "Pending" || r.applicationStatus === "Changes Requested" ? (
                    <ReviewActions
                      approveTitle={`Approve ${r.name}?`}
                      onDecision={(decision, reason) => run((dd, a) => decideApplication(dd, a, r.id, decision, reason), `Application ${decision.toLowerCase()}`)}
                    />
                  ) : null,
              }]
            : []),
        ]}
        empty={isApps ? "No applications match these filters." : "No ventures match these filters."}
      />
    </div>
  );
}
