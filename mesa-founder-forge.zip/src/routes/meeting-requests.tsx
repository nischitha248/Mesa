import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDateTime, nameOf } from "@/lib/mesa/selectors";
import { confirmSlot, proposeAlternative, rejectRequest, requestClarification, studentRespond } from "@/lib/mesa/logic";
import { ActionButton, DemoNote, EmptyState, FilterSelect, HistoryList, matches, PageHeader, Panel, SectionTabs, StatusBadge, Toolbar } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { pageHead, Pick, Row, TextIn } from "@/components/mesa/forms";
import { MENTOR_TABS } from "./mentors";
import type { MeetingRequest } from "@/lib/mesa/types";

export const Route = createFileRoute("/meeting-requests")({
  head: () => pageHead("Meeting Requests", "Confirm student-proposed mentorship slots or propose alternatives."),
  component: Requests,
});

function Requests() {
  const d = useData();
  const [status, setStatus] = useState("all");
  const rows = d.requests.filter((r) => matches(status, r.status)).sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
  return (
    <div>
      <PageHeader title="Meeting Requests" subtitle="Admins only confirm slots the students proposed, or propose an alternative for the student to accept." />
      <DemoNote />
      <SectionTabs tabs={MENTOR_TABS} current="/meeting-requests" />
      <Toolbar>
        <FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Pending", "Awaiting Student Confirmation", "Clarification Requested", "Confirmed", "Rejected"]} />
      </Toolbar>
      <div className="space-y-4">
        {rows.map((r) => <RequestCard key={r.id} r={r} />)}
        {!rows.length && <EmptyState text="No requests match." />}
      </div>
    </div>
  );
}

export function RequestCard({ r }: { r: MeetingRequest }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [mode, setMode] = useState<"Online" | "In person">("Online");
  const [loc, setLoc] = useState("");
  const [link, setLink] = useState("");
  const [alt, setAlt] = useState({ start: "", mentorId: r.mentorId, note: "" });
  const [showHist, setShowHist] = useState(false);
  const actionable = r.status === "Pending" || r.status === "Clarification Requested";
  return (
    <Panel title={`${r.id} · ${nameOf(d, r.ventureId)} → ${nameOf(d, r.mentorId)}`} actions={<StatusBadge status={r.status} />}>
      <p className="text-sm text-ivory"><strong>{r.topic}</strong> · {r.durationMin} min — {r.agenda}</p>
      <ul className="mt-3 space-y-2">
        {r.slots.map((s, i) => (
          <li key={i} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border px-3 py-2 text-sm">
            <span>Slot {i + 1}: {fmtDateTime(s.start)} {s.preferred && <StatusBadge status="Preferred" className="ml-2" />}</span>
            {actionable && (
              <ActionButton label="Confirm this slot" title={`Confirm slot ${i + 1}?`} description={`Mode: ${mode}${loc ? ` · ${loc}` : ""}`} onConfirm={() => run((dd, a) => confirmSlot(dd, a, r.id, i, { mode, location: loc || mode, link }), "Meeting scheduled")} />
            )}
          </li>
        ))}
      </ul>
      {actionable && (
        <>
          <div className="mt-4"><Row>
            <Pick label="Mode" value={mode} onChange={(v) => setMode((v || "Online") as "Online")} options={[{ value: "Online", label: "Online" }, { value: "In person", label: "In person" }]} />
            <TextIn label="Location" value={loc} onChange={setLoc} />
            <TextIn label="Meeting link" value={link} onChange={setLink} />
          </Row></div>
          <div className="mt-4 rounded-xl border border-dashed border-border p-3"><Row>
            <TextIn label="Alternative time" type="datetime-local" value={alt.start} onChange={(v) => setAlt({ ...alt, start: v })} />
            <Pick label="Mentor" value={alt.mentorId} onChange={(v) => setAlt({ ...alt, mentorId: v })} options={d.mentors.filter((m) => m.status === "Active").map((m) => ({ value: m.id, label: m.name }))} />
            <TextIn label="Note" value={alt.note} onChange={(v) => setAlt({ ...alt, note: v })} />
            <Button size="sm" variant="outline" disabled={!alt.start || !alt.mentorId} onClick={() => run((dd, a) => proposeAlternative(dd, a, r.id, { kind: alt.mentorId === r.mentorId ? "time" : "mentor", start: new Date(alt.start).toISOString(), mentorId: alt.mentorId, note: alt.note }), "Proposal sent to student")}>Propose alternative</Button>
          </Row></div>
          <div className="mt-4 flex flex-wrap gap-2">
            <ActionButton label="Request clarification" variant="outline" title="Request clarification" requireReason reasonLabel="What needs clarifying" onConfirm={(n) => run((dd, a) => requestClarification(dd, a, r.id, n), "Clarification requested")} />
            <ActionButton label="Reject" variant="destructive" title="Reject request" requireReason onConfirm={(n) => run((dd, a) => rejectRequest(dd, a, r.id, n), "Request rejected")} />
          </div>
        </>
      )}
      {r.status === "Awaiting Student Confirmation" && r.proposal && (
        <div className="mt-4 rounded-xl border border-dashed border-border p-3 text-sm">
          Proposed: {fmtDateTime(r.proposal.start)} with {nameOf(d, r.proposal.mentorId)}. {r.proposal.note}
          <div className="mt-2 flex gap-2">
            <Button size="sm" variant="outline" onClick={() => run((dd, a) => studentRespond(dd, a, r.id, true), "Simulated: student accepted")}>Simulate student accepts</Button>
            <Button size="sm" variant="outline" onClick={() => run((dd, a) => studentRespond(dd, a, r.id, false), "Simulated: student declined")}>Simulate student declines</Button>
          </div>
        </div>
      )}
      <button className="mt-4 text-sm underline" onClick={() => setShowHist(!showHist)}>{showHist ? "Hide" : "Show"} history</button>
      {showHist && <div className="mt-3"><HistoryList items={r.history} /></div>}
    </Panel>
  );
}
