import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { addMember, changeLeader, removeMember } from "@/lib/mesa/logic";
import { ActionButton, DataTable, DemoNote, matches, PageHeader, Panel, SearchBox, SectionTabs, StatusBadge, textMatch, Toolbar } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { pageHead, Pick, Row } from "@/components/mesa/forms";
import { STARTUP_TABS } from "./startups";

export const Route = createFileRoute("/students")({
  head: () => pageHead("Students & Teams", "Student accounts and venture team membership."),
  component: Students,
});

function Students() {
  const d = useData();
  const run = useMesa((s) => s.run);
  const cohortFilter = useMesa((s) => s.cohortFilter);
  const [q, setQ] = useState("");
  const [venture, setVenture] = useState("");
  const [student, setStudent] = useState("");
  const team = d.memberships.filter((m) => m.ventureId === venture && !m.end);
  return (
    <div>
      <PageHeader title="Students & Teams" subtitle="One Student Workspace login per startup, operated by its authorized team leader." />
      <DemoNote />
      <SectionTabs tabs={STARTUP_TABS} current="/students" />
      <Panel title="Manage a team" className="mb-6">
        <Row>
          <Pick label="Venture" value={venture} onChange={setVenture} options={d.ventures.map((v) => ({ value: v.id, label: v.name }))} />
          {venture && (
            <>
              <Pick label="Add student" value={student} onChange={setStudent} options={d.students.map((s) => ({ value: s.id, label: s.name }))} />
              <Button size="sm" disabled={!student} onClick={() => run((dd, a) => addMember(dd, a, venture, student), "Member added") && setStudent("")}>Add member</Button>
            </>
          )}
        </Row>
        {venture && (
          <ul className="mt-4 divide-y divide-border">
            {team.map((m) => (
              <li key={m.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                <span>{d.students.find((s) => s.id === m.studentId)?.name} <StatusBadge status={m.role} className="ml-2" /></span>
                {m.role === "Member" && (
                  <span className="flex gap-2">
                    <ActionButton label="Make leader" variant="outline" title="Change team leader" description="In production this uses secure account reassignment — never shared passwords." requireReason onConfirm={(r) => run((dd, a) => changeLeader(dd, a, venture, m.studentId, r), "Leader changed")} />
                    <ActionButton label="Remove" variant="destructive" title="Remove member" requireReason onConfirm={(r) => run((dd, a) => removeMember(dd, a, m.id, r), "Member removed")} />
                  </span>
                )}
              </li>
            ))}
            {!team.length && <li className="py-3 text-sm text-muted-foreground">No active members.</li>}
          </ul>
        )}
      </Panel>
      <Toolbar><SearchBox value={q} onChange={setQ} placeholder="Search students…" /></Toolbar>
      <DataTable
        rows={d.students.filter((s) => textMatch(q, s.name, s.email) && matches(cohortFilter, s.cohort))}
        rowKey={(s) => s.id}
        columns={[
          { key: "n", label: "Name", render: (s) => s.name, sort: (s) => s.name },
          { key: "e", label: "Email", render: (s) => s.email },
          { key: "p", label: "Programme", render: (s) => `${s.programme} · ${s.cohort}` },
          { key: "v", label: "Ventures", render: (s) => d.memberships.filter((m) => m.studentId === s.id && !m.end).map((m) => d.ventures.find((v) => v.id === m.ventureId)?.name).join(", ") || "—" },
          { key: "s", label: "Account", render: (s) => <StatusBadge status={s.accountStatus} /> },
        ]}
      />
    </div>
  );
}
