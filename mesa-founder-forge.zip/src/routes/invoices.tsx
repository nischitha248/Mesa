import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect, useMemo } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, fmtDateTime, inr, invoiceAmount, invoiceStage, nameOf } from "@/lib/mesa/selectors";
import { markSentToFinance, recordPayment, reviewInvoice } from "@/lib/mesa/logic";
import { downloadBlob, makeSimplePdf } from "@/lib/mesa/pdf";
import { ActionButton, DataTable, DemoNote, Field, FilterSelect, HistoryList, matches, PageHeader, ReviewActions, SearchBox, StatusBadge, textMatch, Toolbar } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { pageHead, Row, TextIn } from "@/components/mesa/forms";
import { Download, Eye, Mail } from "lucide-react";
import { toast } from "sonner";
import type { Invoice } from "@/lib/mesa/types";

export const Route = createFileRoute("/invoices")({
  head: () => pageHead("Mentor Invoices", "Review mentor invoices and track external Finance processing."),
  component: Invoices,
});

const FINANCE_EMAIL = "finance@demo.mesa";

function invoicePdf(inv: Invoice, d: ReturnType<typeof useData>) {
  const m = d.meetings.find((x) => x.id === inv.meetingId);
  return makeSimplePdf(`Mesa Startup Hub — Invoice ${inv.id} (DEMO)`, [
    `Mentor: ${nameOf(d, inv.mentorId)}`,
    `Startup: ${nameOf(d, inv.ventureId)}`,
    `Meeting: ${inv.meetingId}${m ? ` on ${fmtDate(m.start)}` : ""}`,
    `Approved duration: ${inv.durationMin} min`,
    `Approved hourly rate: ${inr(inv.hourlyRate)}`,
    `Amount: ${inr(invoiceAmount(inv))}`,
    "",
    "Demonstration document generated from the invoice record.",
    "Not a real invoice or payment instruction.",
  ]);
}

function Invoices() {
  const d = useData();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [mentor, setMentor] = useState("all");
  const [sel, setSel] = useState<string | null>(null);
  const rows = d.invoices.filter((i) =>
    textMatch(q, i.id, nameOf(d, i.mentorId), nameOf(d, i.ventureId)) && matches(status, i.status) && matches(mentor, nameOf(d, i.mentorId)),
  );
  const selected = d.invoices.find((i) => i.id === sel);
  return (
    <div>
      <PageHeader title="Mentor Invoices" subtitle="Review mentor invoices and track external Finance processing." />
      <DemoNote>Finance works outside this platform by email — there is no finance login or in-app finance approval. Amount = approved scheduled duration × approved hourly rate.</DemoNote>
      <Toolbar>
        <SearchBox value={q} onChange={setQ} placeholder="Search invoices…" />
        <FilterSelect label="Statuses" value={status} onChange={setStatus} options={["Submitted", "Under Review", "Changes Requested", "Approved", "Sent to Finance", "Paid", "Rejected"]} />
        <FilterSelect label="Mentors" value={mentor} onChange={setMentor} options={d.mentors.map((m) => m.name)} />
      </Toolbar>
      <DataTable
        rows={rows.filter((i) => matches(mentor, nameOf(d, i.mentorId)))}
        rowKey={(i) => i.id}
        onRowClick={(i) => setSel(i.id)}
        columns={[
          { key: "id", label: "Invoice", render: (i) => <span className="font-semibold text-cream">{i.id}</span>, sort: (i) => i.id },
          { key: "m", label: "Mentor", render: (i) => nameOf(d, i.mentorId) },
          { key: "v", label: "Startup", render: (i) => nameOf(d, i.ventureId) },
          { key: "mtg", label: "Meeting", render: (i) => { const m = d.meetings.find((x) => x.id === i.meetingId); return m ? `${i.meetingId} · ${fmtDate(m.start)}` : i.meetingId; } },
          { key: "dur", label: "Duration", render: (i) => `${i.durationMin} min` },
          { key: "rate", label: "Rate", render: (i) => `${inr(i.hourlyRate)}/hr` },
          { key: "amt", label: "Amount", render: (i) => <strong>{inr(invoiceAmount(i))}</strong>, sort: (i) => invoiceAmount(i) },
          { key: "s", label: "Status", render: (i) => <StatusBadge status={i.status} /> },
        ]}
      />
      {selected && <InvoiceDetail inv={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

export function InvoiceDetail({ inv, onClose }: { inv: Invoice; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [p, setP] = useState({ date: "", reference: "", receipt: "" });
  const [preview, setPreview] = useState(false);
  const m = d.meetings.find((x) => x.id === inv.meetingId);
  const pdfBlob = useMemo(() => invoicePdf(inv, d), [inv.id, inv.durationMin, inv.hourlyRate]);
  const [pdfUrl, setPdfUrl] = useState("");
  useEffect(() => {
    if (inv.submittedPdfUrl) { setPdfUrl(inv.submittedPdfUrl); return; }
    const url = URL.createObjectURL(pdfBlob); setPdfUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [pdfBlob, inv.submittedPdfUrl]);
  const download = () => {
    if (inv.submittedPdfUrl) { const a = document.createElement("a"); a.href = inv.submittedPdfUrl; a.download = `${inv.id}.pdf`; a.click(); }
    else downloadBlob(pdfBlob, `${inv.id}.pdf`);
  };
  const mailto = `mailto:${FINANCE_EMAIL}?subject=${encodeURIComponent(`Mesa mentor invoice ${inv.id} — ${nameOf(d, inv.mentorId)}`)}&body=${encodeURIComponent(`Hi Finance,\n\nPlease process mentor invoice ${inv.id} (${inr(invoiceAmount(inv))}) for ${nameOf(d, inv.mentorId)}. The approved PDF is attached.\n\n— Mesa Admin (demo)`)}`;
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Invoice {inv.id}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-wrap items-center gap-2"><StatusBadge status={invoiceStage(inv)} /></div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Mentor">{nameOf(d, inv.mentorId)}</Field>
          <Field label="Startup">{nameOf(d, inv.ventureId)}</Field>
          <Field label="Linked meeting">{inv.meetingId}{m ? ` · ${fmtDateTime(m.start)}` : ""}</Field>
          <Field label="Approved duration">{inv.durationMin} min (scheduled)</Field>
          <Field label="Approved hourly rate">{inr(inv.hourlyRate)}</Field>
          <Field label="Calculated amount"><strong>{inr(invoiceAmount(inv))}</strong></Field>
          <Field label="Meeting completion">{m?.adminVerifiedAt ? `Verified by ${m.verifiedBy} · ${fmtDateTime(m.adminVerifiedAt)}` : "Not verified by admin"}</Field>
          <Field label="Approved by">{inv.approvedBy ?? "—"}</Field>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => setPreview(true)}><Eye className="mr-1 h-4 w-4" />View submitted PDF</Button>
          <Button size="sm" variant="outline" onClick={download}><Download className="mr-1 h-4 w-4" />Download PDF</Button>
        </div>
        {!inv.submittedPdfUrl && <p className="mt-2 text-xs text-muted-foreground">Illustrative invoice PDF — no real mentor upload exists in this prototype.</p>}
        <div className="mt-5 space-y-2">
          {inv.status === "Submitted" && (
            <Button size="sm" variant="outline" onClick={() => run((dd, a) => reviewInvoice(dd, a, inv.id, "Under Review"), "Marked under review")}>Mark Under Review</Button>
          )}
          {(inv.status === "Submitted" || inv.status === "Under Review") && (
            <ReviewActions
              approveTitle="Approve invoice?"
              approveDescription="Requires admin-verified meeting completion."
              onDecision={(decision, reason) => run((dd, a) => reviewInvoice(dd, a, inv.id, decision, reason), `Invoice ${decision.toLowerCase()}`)}
            />
          )}
          {inv.status === "Approved" && (
            <div className="rounded-xl border border-border p-4">
              <div className="mb-2 text-sm font-semibold">Send to external Finance</div>
              <ol className="list-decimal space-y-1 pl-5 text-xs text-muted-foreground">
                <li>Download the approved PDF above.</li>
                <li>Open the email draft, attach the PDF manually and send it outside this app.</li>
                <li>Only then mark the invoice as Sent to Finance.</li>
              </ol>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => { window.open(mailto, "_blank"); toast.info("Email draft opened — attach the PDF and send it yourself. This does not mark the invoice as sent."); }}>
                  <Mail className="mr-1 h-4 w-4" />Open email draft
                </Button>
                <ActionButton label="Mark Sent to Finance" title="Confirm you sent the email?" description="Only confirm after actually sending the PDF to Finance outside the app." optionalNote onConfirm={(n) => run((dd, a) => markSentToFinance(dd, a, inv.id, n), "Marked Sent to Finance")} />
              </div>
            </div>
          )}
          {inv.sentToFinance && (
            <p className="text-xs text-muted-foreground">Sent to Finance by {inv.sentToFinance.by} on {fmtDateTime(inv.sentToFinance.at)}{inv.sentToFinance.note ? ` — ${inv.sentToFinance.note}` : ""}</p>
          )}
          {inv.status === "Sent to Finance" && (
            <div className="rounded-xl border border-border p-4">
              <div className="mb-2 text-sm font-semibold">Record external payment confirmation</div>
              <Row>
                <TextIn label="Payment date" type="date" value={p.date} onChange={(v) => setP({ ...p, date: v })} />
                <TextIn label="Transaction ref" value={p.reference} onChange={(v) => setP({ ...p, reference: v })} />
                <TextIn label="Receipt/confirmation (optional)" value={p.receipt} onChange={(v) => setP({ ...p, receipt: v })} />
                <Button size="sm" onClick={() => run((dd, a) => recordPayment(dd, a, inv.id, p), "Payment recorded")}>Record payment</Button>
              </Row>
            </div>
          )}
          {inv.payment && <p className="text-sm text-muted-foreground">Paid {inv.payment.date} · ref {inv.payment.reference}{inv.payment.receipt ? ` · ${inv.payment.receipt}` : ""} · recorded by {inv.payment.recordedBy}</p>}
        </div>
        <h3 className="mb-2 mt-5 font-semibold">Invoice history</h3>
        <HistoryList items={inv.history} />
        <Dialog open={preview} onOpenChange={setPreview}>
          <DialogContent className="flex h-[80vh] max-w-3xl flex-col">
            <DialogHeader><DialogTitle>Invoice {inv.id} — PDF preview (demo)</DialogTitle></DialogHeader>
            <iframe title={`Invoice ${inv.id} PDF preview`} className="min-h-0 w-full flex-1 rounded-lg bg-ivory" src={pdfUrl} />
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}
