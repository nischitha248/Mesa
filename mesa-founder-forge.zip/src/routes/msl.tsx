import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useActor, useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, mslSummary, nameOf } from "@/lib/mesa/selectors";
import { moveCriterion, recordProgression, saveMslCriterion, setCriterionActive, setCriterionStatus } from "@/lib/mesa/logic";
import { ActionButton, DataTable, DemoNote, PageHeader, StatusBadge } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { pageHead, Pick } from "@/components/mesa/forms";
import { ArrowDown, ArrowUp, Pencil } from "lucide-react";
import type { MslCriterion, MslCriterionStatus, MslDecision, MslReview } from "@/lib/mesa/types";

export const Route = createFileRoute("/msl")({
  head: () => pageHead("MSL Readiness", "Review venture eligibility and manage progression from ILS to MSL."),
  component: Msl,
});

const CRITERION_STATUSES: MslCriterionStatus[] = ["Not Started", "Awaiting Verification", "Verified", "Needs More Evidence", "Not Met"];

function Msl() {
  const d = useData();
  const [editOpen, setEditOpen] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const selected = d.mslReviews.find((r) => r.ventureId === sel);
  return (
    <div>
      <PageHeader
        title="MSL Readiness"
        subtitle="Review venture eligibility and manage progression from ILS to MSL."
        actions={<Button variant="outline" onClick={() => setEditOpen(true)}><Pencil className="mr-1 h-4 w-4" />Edit Criteria</Button>}
      />
      <DemoNote>Evidence approval never changes readiness automatically — these are separate decisions. Only the designated programme lead records the final progression decision.</DemoNote>
      <DataTable
        rows={d.mslReviews}
        rowKey={(r) => r.ventureId}
        onRowClick={(r) => setSel(r.ventureId)}
        columns={[
          { key: "v", label: "Startup", render: (r) => <span className="font-semibold text-cream">{nameOf(d, r.ventureId)}</span>, sort: (r) => nameOf(d, r.ventureId) },
          { key: "p", label: "Programme/Cohort", render: (r) => { const v = d.ventures.find((x) => x.id === r.ventureId); return v ? `${v.programme} · ${v.cohort}` : "—"; } },
          { key: "c", label: "Criteria Verified", render: (r) => { const s = mslSummary(d, r); return `${s.verified}/${s.total}`; }, sort: (r) => mslSummary(d, r).verified },
          { key: "a", label: "Awaiting Review", render: (r) => mslSummary(d, r).awaiting || "—" },
          { key: "s", label: "Readiness Status", render: (r) => <StatusBadge status={r.status} /> },
          { key: "x", label: "Action", render: () => <span className="text-sm text-peach">View Readiness →</span> },
        ]}
      />
      <EditCriteriaDialog open={editOpen} onClose={() => setEditOpen(false)} />
      {selected && <ReadinessDetail r={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

function EditCriteriaDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const empty = { id: "", label: "", description: "", requiredEvidence: "" };
  const [f, setF] = useState(empty);
  const list = [...d.mslCriteria].sort((a, b) => a.order - b.order);
  const save = () =>
    run((dd, a) => saveMslCriterion(dd, a, { id: f.id || undefined, label: f.label, description: f.description, requiredEvidence: f.requiredEvidence }), f.id ? "Criterion updated" : "Criterion added") && setF(empty);
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader><DialogTitle>Edit MSL Criteria</DialogTitle></DialogHeader>
        <p className="text-xs text-muted-foreground">Changes are recorded in the audit log. Deactivating a criterion preserves historical decisions.</p>
        <ul className="mt-3 divide-y divide-border">
          {list.map((c, i) => (
            <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
              <span>
                <strong className={c.active ? "" : "line-through opacity-60"}>{c.label}</strong>
                <span className="ml-2 text-xs text-muted-foreground">{c.description}</span>
                {!c.active && <StatusBadge status="Deactivated" className="ml-2" />}
              </span>
              <span className="flex gap-1">
                <Button size="sm" variant="ghost" aria-label="Move up" disabled={i === 0} onClick={() => run((dd, a) => moveCriterion(dd, a, c.id, -1))}><ArrowUp className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" aria-label="Move down" disabled={i === list.length - 1} onClick={() => run((dd, a) => moveCriterion(dd, a, c.id, 1))}><ArrowDown className="h-4 w-4" /></Button>
                <Button size="sm" variant="outline" onClick={() => setF({ id: c.id, label: c.label, description: c.description, requiredEvidence: c.requiredEvidence })}>Edit</Button>
                <Button size="sm" variant="outline" onClick={() => run((dd, a) => setCriterionActive(dd, a, c.id, !c.active), c.active ? "Criterion deactivated" : "Criterion reactivated")}>{c.active ? "Deactivate" : "Reactivate"}</Button>
              </span>
            </li>
          ))}
        </ul>
        <div className="mt-4 space-y-3 rounded-xl border border-border p-4">
          <div className="text-sm font-semibold">{f.id ? "Edit criterion" : "Add a criterion"}</div>
          <div><Label>Title</Label><Input className="mt-1 bg-ivory text-maroon" value={f.label} onChange={(e) => setF({ ...f, label: e.target.value })} /></div>
          <div><Label>Description</Label><Input className="mt-1 bg-ivory text-maroon" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div><Label>Required evidence</Label><Input className="mt-1 bg-ivory text-maroon" value={f.requiredEvidence} onChange={(e) => setF({ ...f, requiredEvidence: e.target.value })} /></div>
          <div className="flex gap-2">
            <Button size="sm" onClick={save}>{f.id ? "Save changes" : "Add criterion"}</Button>
            {f.id && <Button size="sm" variant="ghost" onClick={() => setF(empty)}>Cancel edit</Button>}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function ReadinessDetail({ r, onClose, initialCriterion }: { r: MslReview; onClose: () => void; initialCriterion?: string }) {
  const d = useData();
  const actor = useActor();
  const run = useMesa((s) => s.run);
  const [decision, setDecision] = useState("");
  const isLead = !!actor?.roles.includes("programme_lead");
  const s = mslSummary(d, r);
  const v = d.ventures.find((x) => x.id === r.ventureId);
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">{nameOf(d, r.ventureId)} — MSL Readiness</DialogTitle>
        </DialogHeader>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={r.status} />
          <span className="text-sm text-muted-foreground">{v?.programme} · {v?.cohort} · {s.verified}/{s.total} verified · {s.awaiting} awaiting review</span>
          <Link to="/startups/$ventureId" params={{ ventureId: r.ventureId }} className="text-sm underline">Open startup profile</Link>
        </div>
        <div className="mt-4 space-y-3">
          {d.mslCriteria.filter((c) => c.active).sort((a, b) => a.order - b.order).map((c) => (
            <CriterionRow key={c.id} c={c} r={r} expanded={c.id === initialCriterion} />
          ))}
        </div>
        {r.recommendation && <p className="mt-4 text-sm">Mentor recommendation by {r.recommendation.by}: {r.recommendation.text}</p>}
        <div className="mt-5 rounded-xl border border-border p-4">
          <div className="mb-2 text-sm font-semibold">Final Progression Decision</div>
          <div className="flex flex-wrap items-end gap-2">
            <Pick label="Decision" value={decision} onChange={setDecision} options={["Approved for MSL", "Not Yet Ready", "Deferred"].map((x) => ({ value: x, label: x }))} />
            <ActionButton
              label="Record decision"
              disabled={!decision || !isLead}
              title={`Record "${decision}"?`}
              requireReason
              onConfirm={(reason) => run((dd, a) => recordProgression(dd, a, r.ventureId, decision as MslDecision, reason), "Decision recorded")}
            />
            {!isLead && <span className="text-xs text-muted-foreground">Sign in as the programme lead to decide.</span>}
          </div>
        </div>
        <h3 className="mb-2 mt-5 font-semibold">Decision history</h3>
        {r.decisions.length ? (
          <ul className="space-y-2 text-sm">
            {r.decisions.map((x, i) => (
              <li key={i}>{fmtDate(x.at)} · {x.by}: <strong>{x.decision}</strong> — {x.reason}</li>
            ))}
          </ul>
        ) : <p className="text-sm text-muted-foreground">No decisions recorded.</p>}
      </DialogContent>
    </Dialog>
  );
}

export function CriterionRow({ c, r, expanded }: { c: MslCriterion; r: MslReview; expanded?: boolean }) {
  const run = useMesa((s) => s.run);
  const cur = r.criteria[c.id];
  const [status, setStatus] = useState<MslCriterionStatus>(cur?.status ?? "Not Started");
  const [note, setNote] = useState(cur?.note ?? "");
  const d = useData();
  const goals = d.goals.filter((g) => cur?.goalIds.includes(g.id));
  const history = d.audit.filter((a) => a.entityId === `${r.ventureId}/${c.id}`);
  return (
    <details open={expanded || undefined} className="border-b border-border py-3 text-sm">
      <summary className="flex cursor-pointer items-center justify-between gap-3 font-semibold"><span>{c.label}</span><StatusBadge status={cur?.status ?? "Not Started"} /></summary>
      <div className="space-y-3 pt-3">
        <p>{c.description}</p><p><strong>Required evidence:</strong> {c.requiredEvidence}</p>
        <div><strong>Linked goals & submitted evidence</strong>{goals.length ? goals.map((g) => <div key={g.id} className="mt-2"><div>{g.title}</div>{g.submissions.map((sub) => <div key={sub.number} className="text-xs"><StatusBadge status={sub.status} /> Version {sub.number} · {sub.files.map((f) => /^https?:\/\//.test(f) ? <a key={f} href={f} target="_blank" rel="noreferrer" className="mr-2 underline">{f}</a> : <span key={f}>{f} (demo attachment) </span>)}{sub.feedback && <p>Feedback: {sub.feedback}</p>}</div>)}</div>) : <p className="text-muted-foreground">No linked goals or evidence submitted.</p>}</div>
        {c.order === 5 && <p><strong>Mentor recommendation:</strong> {r.recommendation ? `${r.recommendation.by}: ${r.recommendation.text}` : "Not submitted"}</p>}
        {cur?.note && <p>Previous note: {cur.note}</p>}
        {history.map((h) => <p key={h.id} className="text-xs">{fmtDate(h.at)} · {h.actor} · {h.next} — {h.reason || "No note"}</p>)}
        <div className="flex flex-wrap items-center gap-2">
          <Select value={status} onValueChange={(x) => setStatus(x as MslCriterionStatus)}><SelectTrigger className="h-8 w-52" aria-label={`Status for ${c.label}`}><SelectValue /></SelectTrigger><SelectContent>{CRITERION_STATUSES.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent></Select>
          <Input placeholder="Review note" value={note} onChange={(e) => setNote(e.target.value)} className="h-8 min-w-40 flex-1" aria-label={`Note for ${c.label}`} />
          <Button size="sm" onClick={() => run((dd, a) => setCriterionStatus(dd, a, r.ventureId, c.id, status, note), "Criterion updated")}>Save</Button>
        </div>
      </div>
    </details>
  );
}
