import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDate, nameOf } from "@/lib/mesa/selectors";
import { cancelRegistration, createWorkshop, markAttendance, registerStudent, setWorkshopStatus } from "@/lib/mesa/logic";
import { ActionButton, DataTable, DemoNote, EmptyState, PageHeader, Panel, StatusBadge } from "@/components/mesa/ui";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { pageHead, Pick, Row } from "@/components/mesa/forms";
import { cn } from "@/lib/utils";
import { Plus } from "lucide-react";
import type { Workshop } from "@/lib/mesa/types";

export const Route = createFileRoute("/workshops")({
  head: () => pageHead("Workshops", "Create learning sessions and manage registrations, waitlists and attendance."),
  component: Workshops,
});

const TABS = ["Upcoming", "Registrations", "Waitlist", "Past Workshops"] as const;

function Workshops() {
  const d = useData();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Upcoming");
  const [createOpen, setCreateOpen] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const today = new Date().toISOString().slice(0, 10);
  const upcoming = d.workshops.filter((w) => (w.status === "Published" || w.status === "Draft") && w.date >= today);
  const past = d.workshops.filter((w) => w.status === "Completed" || w.status === "Cancelled" || w.date < today);
  const selected = d.workshops.find((w) => w.id === sel);
  return (
    <div>
      <PageHeader
        title="Workshops"
        subtitle="Create learning sessions and manage registrations, waitlists and attendance."
        actions={<Button onClick={() => setCreateOpen(true)}><Plus className="mr-1 h-4 w-4" />Create a Workshop</Button>}
      />
      <DemoNote>Students register themselves in the Student Workspace — the "simulate registration" control only mimics that. Cancelling a seat promotes the earliest waitlisted student.</DemoNote>
      <div className="mb-6 flex flex-wrap gap-1 rounded-full border border-border bg-surface p-1">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={cn("rounded-full px-4 py-1.5 text-sm font-medium transition-colors", tab === t ? "bg-cream text-maroon" : "text-ivory/80 hover:bg-accent hover:text-cream")}>{t}</button>
        ))}
      </div>
      {(tab === "Upcoming" || tab === "Past Workshops") && (
        <div className="space-y-4">
          {(tab === "Upcoming" ? upcoming : past).map((w) => <WorkshopCard key={w.id} w={w} onOpen={() => setSel(w.id)} />)}
          {!(tab === "Upcoming" ? upcoming : past).length && <EmptyState text={tab === "Upcoming" ? "No upcoming workshops." : "No past workshops."} />}
        </div>
      )}
      {tab === "Registrations" && <RegistrationTable kind="Registered" />}
      {tab === "Waitlist" && <RegistrationTable kind="Waitlisted" />}
      <CreateWorkshopDialog open={createOpen} onClose={() => setCreateOpen(false)} />
      {selected && <WorkshopDetail w={selected} onClose={() => setSel(null)} />}
    </div>
  );
}

function WorkshopCard({ w, onOpen }: { w: Workshop; onOpen: () => void }) {
  const d = useData();
  const registered = w.registrations.filter((r) => r.status === "Registered").length;
  const waitlisted = w.registrations.filter((r) => r.status === "Waitlisted").length;
  return (
    <Panel title={w.title} actions={<StatusBadge status={w.status} />}>
      <p className="text-sm text-muted-foreground">
        {w.topic} · {w.facilitator} · {fmtDate(w.date)} {w.startTime} · {w.durationMin} min · {w.mode} · {w.eligibility}
      </p>
      <p className="mt-1 text-sm">{w.description}</p>
      <p className="mt-2 text-sm">
        <strong>{registered}/{w.capacity}</strong> registered · {waitlisted} waitlisted · deadline {fmtDate(w.deadline)}
      </p>
      <div className="mt-3"><Button size="sm" variant="outline" onClick={onOpen}>View Details</Button></div>
      {d && null}
    </Panel>
  );
}

function RegistrationTable({ kind }: { kind: "Registered" | "Waitlisted" }) {
  const d = useData();
  const rows = d.workshops.flatMap((w) =>
    w.registrations.filter((r) => r.status === kind).map((r) => ({ w, r })),
  );
  return (
    <DataTable
      rows={rows}
      rowKey={(x) => `${x.w.id}-${x.r.studentId}`}
      empty={kind === "Registered" ? "No registrations." : "The waitlist is empty."}
      columns={[
        { key: "s", label: "Student", render: (x) => nameOf(d, x.r.studentId), sort: (x) => nameOf(d, x.r.studentId) },
        { key: "w", label: "Workshop", render: (x) => x.w.title },
        { key: "p", label: "Programme", render: (x) => { const s = d.students.find((y) => y.id === x.r.studentId); return s ? `${s.programme} · ${s.cohort}` : "—"; } },
        { key: "at", label: "Registered", render: (x) => fmtDate(x.r.at), sort: (x) => x.r.at },
        ...(kind === "Registered"
          ? [{ key: "att", label: "Attendance", render: (x: (typeof rows)[number]) => (x.r.attended === undefined ? "—" : <StatusBadge status={x.r.attended ? "Attended" : "No-show"} />) }]
          : []),
      ]}
    />
  );
}

function CreateWorkshopDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const run = useMesa((s) => s.run);
  const empty = { title: "", topic: "", description: "", facilitator: "", date: "", startTime: "", durationMin: "120", mode: "", capacity: "20", deadline: "", eligibility: "All programmes" };
  const [f, setF] = useState(empty);
  const save = (publish: boolean) =>
    run((dd, a) => createWorkshop(dd, a, { ...f, durationMin: Number(f.durationMin) || 60, capacity: Number(f.capacity) || 1 }, publish), publish ? "Workshop published" : "Draft saved") && (setF(empty), onClose());
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
        <DialogHeader><DialogTitle>Create a Workshop</DialogTitle></DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2"><Label>Title</Label><Input className="mt-1 bg-ivory text-maroon" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
          <div><Label>Category</Label><Input className="mt-1 bg-ivory text-maroon" value={f.topic} onChange={(e) => setF({ ...f, topic: e.target.value })} /></div>
          <div><Label>Facilitator</Label><Input className="mt-1 bg-ivory text-maroon" value={f.facilitator} onChange={(e) => setF({ ...f, facilitator: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Description</Label><Textarea className="mt-1 bg-ivory text-maroon" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div><Label>Date</Label><Input type="date" className="mt-1 bg-ivory text-maroon" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></div>
          <div><Label>Start time</Label><Input type="time" className="mt-1 bg-ivory text-maroon" value={f.startTime} onChange={(e) => setF({ ...f, startTime: e.target.value })} /></div>
          <div><Label>Duration (min)</Label><Input type="number" className="mt-1 bg-ivory text-maroon" value={f.durationMin} onChange={(e) => setF({ ...f, durationMin: e.target.value })} /></div>
          <div><Label>Capacity</Label><Input type="number" className="mt-1 bg-ivory text-maroon" value={f.capacity} onChange={(e) => setF({ ...f, capacity: e.target.value })} /></div>
          <div><Label>Location or online link</Label><Input className="mt-1 bg-ivory text-maroon" value={f.mode} onChange={(e) => setF({ ...f, mode: e.target.value })} /></div>
          <div><Label>Registration deadline</Label><Input type="date" className="mt-1 bg-ivory text-maroon" value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Eligible programme/cohort</Label><Input className="mt-1 bg-ivory text-maroon" value={f.eligibility} onChange={(e) => setF({ ...f, eligibility: e.target.value })} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button variant="outline" onClick={() => save(false)}>Save Draft</Button>
          <Button onClick={() => save(true)}>Publish</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function WorkshopDetail({ w, onClose, memberIds }: { w: Workshop; onClose: () => void; memberIds?: string[] }) {
  const d = useData();
  const run = useMesa((s) => s.run);
  const [student, setStudent] = useState("");
  const active = w.registrations.filter((r) => r.status !== "Cancelled" && (!memberIds || memberIds.includes(r.studentId)));
  const registered = active.filter((r) => r.status === "Registered");
  const waitlisted = active.filter((r) => r.status === "Waitlisted").sort((a, b) => a.at.localeCompare(b.at));
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">{w.title}</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">{w.topic} · {w.facilitator} · {fmtDate(w.date)} {w.startTime} · {w.durationMin} min · {w.mode} · {w.eligibility} · deadline {fmtDate(w.deadline)}</p>
        <p className="mt-2 text-sm">{w.description}</p>
        {!memberIds && <div className="mt-4 flex flex-wrap gap-2">
          {w.status === "Draft" && <Button size="sm" onClick={() => run((dd, a) => setWorkshopStatus(dd, a, w.id, "Published"), "Workshop published")}>Publish</Button>}
          {w.status === "Published" && <Button size="sm" variant="outline" onClick={() => run((dd, a) => setWorkshopStatus(dd, a, w.id, "Draft"), "Unpublished to draft")}>Unpublish</Button>}
          {(w.status === "Published" || w.status === "Draft") && (
            <ActionButton label="Cancel Workshop" variant="destructive" title="Cancel this workshop?" description="Registrations remain on record as cancelled." requireReason onConfirm={(r) => run((dd, a) => setWorkshopStatus(dd, a, w.id, "Cancelled", r), "Workshop cancelled")} />
          )}
        </div>}
        <h3 className="mb-2 mt-5 font-semibold">Registered ({registered.length}/{w.capacity})</h3>
        <ul className="divide-y divide-border text-sm">
          {registered.map((r) => (
            <li key={r.studentId} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span>{nameOf(d, r.studentId)} {r.attended !== undefined && <StatusBadge status={r.attended ? "Attended" : "No-show"} className="ml-2" />}</span>
              {!memberIds && <span className="flex gap-2">
                {r.attended === undefined && w.status !== "Cancelled" && (
                  <>
                    <Button size="sm" variant="ghost" onClick={() => run((dd, a) => markAttendance(dd, a, w.id, r.studentId, true), "Marked attended")}>Attended</Button>
                    <Button size="sm" variant="ghost" onClick={() => run((dd, a) => markAttendance(dd, a, w.id, r.studentId, false), "Marked no-show")}>No-show</Button>
                  </>
                )}
                <ActionButton label="Cancel" variant="outline" title="Cancel registration?" description="The earliest waitlisted student is promoted automatically." onConfirm={() => run((dd, a) => {
                  const p = cancelRegistration(dd, a, w.id, r.studentId);
                  if (p) setTimeout(() => import("sonner").then(({ toast }) => toast.info(`${nameOf(dd, p)} promoted from waitlist`)));
                }, "Registration cancelled")} />
              </span>}
            </li>
          ))}
          {!registered.length && <li className="py-2 text-muted-foreground">No registrations.</li>}
        </ul>
        <h3 className="mb-2 mt-5 font-semibold">Waitlist ({waitlisted.length})</h3>
        <ul className="divide-y divide-border text-sm">
          {waitlisted.map((r, i) => (
            <li key={r.studentId} className="flex items-center justify-between gap-2 py-2">
              <span>#{i + 1} · {nameOf(d, r.studentId)}</span>
              {!memberIds && <ActionButton label="Cancel" variant="outline" title="Cancel waitlist entry?" onConfirm={() => run((dd, a) => cancelRegistration(dd, a, w.id, r.studentId), "Waitlist entry cancelled")} />}
            </li>
          ))}
          {!waitlisted.length && <li className="py-2 text-muted-foreground">Waitlist is empty.</li>}
        </ul>
        {!memberIds && w.status === "Published" && (
          <div className="mt-5 rounded-xl border border-dashed border-border p-3">
            <div className="mb-2 text-xs text-muted-foreground">Simulate a student self-registering in the Student Workspace</div>
            <Row>
              <Pick label="Student" value={student} onChange={setStudent} options={d.students.map((s) => ({ value: s.id, label: s.name }))} />
              <Button size="sm" disabled={!student} onClick={() => run((dd, a) => registerStudent(dd, a, w.id, student), "Student added") && setStudent("")}>Simulate registration</Button>
            </Row>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
