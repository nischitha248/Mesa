// Pure workflow transitions over prototype state. Each throws on a rule violation.
// In production these become transactional, role-checked backend operations.
import type {
  Admin,
  AdminRequestStatus,
  ApplicationStatus,
  GalleryItem,
  Invoice,
  MesaData,
  MentorStatus,
  MslCriterionStatus,
  MslDecision,
  ReviewStatus,
  Workshop,
} from "./types";
import { leaderOf } from "./selectors";

export class RuleError extends Error {}
const fail = (msg: string): never => {
  throw new RuleError(msg);
};

let seq = 0;
const uid = (p: string) => `${p}-${Date.now().toString(36).toUpperCase()}${(seq++).toString(36).toUpperCase()}`;
const nowIso = () => new Date().toISOString();

export function audit(
  d: MesaData,
  actor: Admin,
  action: string,
  entity: string,
  entityId: string,
  prev: string,
  next: string,
  reason = "",
) {
  d.audit.unshift({ id: uid("AUD"), actor: actor.name, role: actor.roles.join(", "), action, entity, entityId, prev, next, at: nowIso(), reason });
}

export function notify(d: MesaData, type: string, text: string, link: string) {
  d.notifications.unshift({ id: uid("NTF"), type, text, link, at: nowIso(), read: false });
}

const needReason = (decision: string, reason?: string) => {
  if (["Rejected", "Changes Requested"].includes(decision) && !reason?.trim())
    fail("A reason is required for rejection or changes requested.");
};

// ---------- Admin accounts ----------
export function decideAdmin(d: MesaData, actor: Admin, adminId: string, decision: "Active" | "Rejected" | "Deactivated", reason = "") {
  if (actor.status !== "Active") fail("Only active administrators can do this.");
  const a = d.admins.find((x) => x.id === adminId) ?? fail("Admin not found");
  if (a.id === actor.id && decision === "Active") fail("You cannot approve your own account.");
  if (decision === "Deactivated") {
    const activeCount = d.admins.filter((x) => x.status === "Active").length;
    if (a.status === "Active" && activeCount <= 1) fail("You cannot remove the last active administrator.");
  }
  const prev = a.status;
  a.status = decision;
  a.history.push({ at: nowIso(), by: actor.name, text: `${prev} → ${decision}${reason ? `: ${reason}` : ""}` });
  audit(d, actor, "Admin account decision", "admin_account", a.id, prev, decision, reason);
}

// ---------- Ventures ----------
export function decideApplication(d: MesaData, actor: Admin, ventureId: string, decision: ApplicationStatus, reason = "") {
  needReason(decision, reason);
  const v = d.ventures.find((x) => x.id === ventureId) ?? fail("Venture not found");
  const prev = v.applicationStatus;
  v.applicationStatus = decision;
  if (decision === "Approved") v.status = "Active";
  if (decision === "Rejected") v.status = "Not Admitted";
  v.lastActivity = nowIso();
  v.history.push({ at: nowIso(), by: actor.name, text: `Application ${decision}${reason ? ` — ${reason}` : ""}` });
  audit(d, actor, "Application review", "venture_application", v.id, prev, decision, reason);
}

export function archiveVenture(d: MesaData, actor: Admin, ventureId: string, reason: string) {
  if (!reason.trim()) fail("A reason is required to archive.");
  const v = d.ventures.find((x) => x.id === ventureId) ?? fail("Venture not found");
  const prev = v.status;
  v.status = "Archived";
  v.archiveReason = reason;
  v.history.push({ at: nowIso(), by: actor.name, text: `Archived — ${reason}` });
  audit(d, actor, "Archive venture", "venture", v.id, prev, "Archived", reason);
}

export const EDITABLE_VENTURE_FIELDS = ["description", "stage", "website", "problem", "solution", "customers", "businessModel"] as const;
export type VentureInfoField = (typeof EDITABLE_VENTURE_FIELDS)[number];

/** Admin edit of startup basic information, with prev/next change history. */
export function editVentureInfo(d: MesaData, actor: Admin, ventureId: string, field: VentureInfoField, value: string) {
  const v = d.ventures.find((x) => x.id === ventureId) ?? fail("Venture not found");
  if (!EDITABLE_VENTURE_FIELDS.includes(field)) fail("This field is restricted.");
  const prev = v[field];
  if (prev === value) fail("No change to save.");
  v[field] = value;
  v.lastActivity = nowIso();
  v.infoHistory.push({ at: nowIso(), by: actor.name, field, prev, next: value });
  v.history.push({ at: nowIso(), by: actor.name, text: `Updated ${field}` });
  audit(d, actor, "Edit venture info", "venture", v.id, `${field}: ${prev}`, `${field}: ${value}`);
}

// ---------- Teams ----------
export function addMember(d: MesaData, actor: Admin, ventureId: string, studentId: string) {
  if (d.memberships.some((m) => m.ventureId === ventureId && m.studentId === studentId && !m.end)) fail("Student is already on this team.");
  d.memberships.push({ id: uid("MEM"), ventureId, studentId, role: "Member", start: nowIso() });
  audit(d, actor, "Add team member", "venture_membership", ventureId, "", studentId);
}

export function removeMember(d: MesaData, actor: Admin, membershipId: string, reason: string) {
  const m = d.memberships.find((x) => x.id === membershipId) ?? fail("Membership not found");
  if (m.role === "Team Leader") fail("Assign a new team leader before removing the current leader.");
  m.end = nowIso();
  audit(d, actor, "Remove team member", "venture_membership", m.ventureId, m.studentId, "removed", reason);
}

export function changeLeader(d: MesaData, actor: Admin, ventureId: string, newStudentId: string, reason: string) {
  const current = d.memberships.find((m) => m.ventureId === ventureId && m.role === "Team Leader" && !m.end);
  const next = d.memberships.find((m) => m.ventureId === ventureId && m.studentId === newStudentId && !m.end) ?? fail("New leader must be an active team member.");
  if (current?.id === next.id) fail("This student is already the team leader.");
  const t = nowIso();
  if (current) {
    // close leadership record and keep them as member
    current.end = t;
    d.memberships.push({ id: uid("MEM"), ventureId, studentId: current.studentId, role: "Member", start: t });
  }
  next.end = t;
  d.memberships.push({ id: uid("MEM"), ventureId, studentId: newStudentId, role: "Team Leader", start: t });
  audit(d, actor, "Change team leader", "venture_membership", ventureId, current?.studentId ?? "none", newStudentId, reason);
}

// ---------- Mentors ----------
export function setMentorStatus(d: MesaData, actor: Admin, mentorId: string, status: MentorStatus, reason = "") {
  if (["Rejected", "Changes Requested"].includes(status) && !reason.trim()) fail("A reason is required.");
  const m = d.mentors.find((x) => x.id === mentorId) ?? fail("Mentor not found");
  const prev = m.status;
  m.status = status;
  if (status !== "Active") m.availability = "Unavailable";
  m.history.push({ at: nowIso(), by: actor.name, text: `${prev} → ${status}${reason ? ` — ${reason}` : ""}` });
  audit(d, actor, "Mentor status", "mentor_profile", m.id, prev, status, reason);
}

export function setMentorRate(d: MesaData, actor: Admin, mentorId: string, hourlyRate: number) {
  const m = d.mentors.find((x) => x.id === mentorId) ?? fail("Mentor not found");
  if (!Number.isFinite(hourlyRate) || hourlyRate <= 0) fail("Enter a valid hourly rate.");
  const prev = String(m.hourlyRate);
  m.hourlyRate = Math.round(hourlyRate);
  m.history.push({ at: nowIso(), by: actor.name, text: `Approved hourly rate ${prev} → ${m.hourlyRate}` });
  audit(d, actor, "Set mentor rate", "mentor_profile", m.id, prev, String(m.hourlyRate));
}

export function assignMentor(d: MesaData, actor: Admin, a: { ventureId: string; mentorId: string; role: "Principal Mentor" | "Associate Mentor"; focus: string; note: string }) {
  const mentor = d.mentors.find((x) => x.id === a.mentorId) ?? fail("Mentor not found");
  if (mentor.status !== "Active") fail("Only active mentors can be assigned.");
  if (d.assignments.some((x) => x.ventureId === a.ventureId && x.mentorId === a.mentorId && x.status === "Active")) fail("This mentor already has an active assignment on this venture.");
  const id = uid("ASG");
  d.assignments.push({ id, ...a, start: nowIso(), status: "Active" });
  audit(d, actor, "Assign mentor", "mentor_assignment", id, "", `${mentor.name} as ${a.role}`, a.note);
}

export function changeAssignmentRole(d: MesaData, actor: Admin, id: string) {
  const a = d.assignments.find((x) => x.id === id) ?? fail("Assignment not found");
  const prev = a.role;
  a.role = a.role === "Principal Mentor" ? "Associate Mentor" : "Principal Mentor";
  audit(d, actor, "Change assignment role", "mentor_assignment", id, prev, a.role);
}

export function endAssignment(d: MesaData, actor: Admin, id: string, reason = "") {
  const a = d.assignments.find((x) => x.id === id) ?? fail("Assignment not found");
  a.status = "Ended";
  a.end = nowIso();
  audit(d, actor, "End assignment", "mentor_assignment", id, "Active", "Ended", reason);
}

// ---------- Meeting requests ----------
export function validateSlots(slots: { start: string }[]) {
  if (slots.length < 2 || slots.length > 3) fail("A meeting request needs two or three proposed slots.");
}

export function confirmSlot(d: MesaData, actor: Admin, requestId: string, slotIndex: number, opts: { mode: "In person" | "Online"; location: string; link: string }, now = Date.now()) {
  const r = d.requests.find((x) => x.id === requestId) ?? fail("Request not found");
  if (!["Pending", "Clarification Requested"].includes(r.status)) fail(`Cannot confirm a request that is ${r.status}.`);
  validateSlots(r.slots);
  const slot = r.slots[slotIndex] ?? fail("Slot not found");
  if (new Date(slot.start).getTime() <= now) fail("This slot has expired and cannot be confirmed.");
  const mentor = d.mentors.find((m) => m.id === r.mentorId);
  if (!mentor || mentor.status !== "Active") fail("The requested mentor is not available.");
  const id = uid("MTG");
  d.meetings.push({ id, requestId: r.id, ventureId: r.ventureId, mentorId: r.mentorId, start: slot.start, durationMin: r.durationMin, mode: opts.mode, location: opts.location, link: opts.link.trim(), status: "Scheduled", history: [{ at: nowIso(), by: actor.name, text: `Created from confirmed student-proposed slot ${slotIndex + 1}` }] });
  const prev = r.status;
  r.status = "Confirmed";
  r.meetingId = id;
  r.history.push({ at: nowIso(), by: actor.name, text: `Confirmed student-proposed slot ${slotIndex + 1} — meeting ${id} created` });
  audit(d, actor, "Confirm meeting slot", "meeting_request", r.id, prev, "Confirmed");
  return id;
}

export function proposeAlternative(d: MesaData, actor: Admin, requestId: string, p: { kind: "time" | "mentor"; start: string; mentorId: string; note: string }, now = Date.now()) {
  const r = d.requests.find((x) => x.id === requestId) ?? fail("Request not found");
  if (!["Pending", "Clarification Requested"].includes(r.status)) fail(`Cannot propose on a request that is ${r.status}.`);
  if (!p.start || new Date(p.start).getTime() <= now) fail("Proposed time must be in the future.");
  r.proposal = p;
  const prev = r.status;
  r.status = "Awaiting Student Confirmation";
  r.history.push({ at: nowIso(), by: actor.name, text: `Proposed alternative ${p.kind === "mentor" ? "mentor" : "time"} — awaiting student confirmation` });
  audit(d, actor, "Propose alternative", "meeting_proposal", r.id, prev, r.status, p.note);
}

/** Simulates the student's response in the Student Workspace. */
export function studentRespond(d: MesaData, actor: Admin, requestId: string, accept: boolean) {
  const r = d.requests.find((x) => x.id === requestId) ?? fail("Request not found");
  if (r.status !== "Awaiting Student Confirmation" || !r.proposal) fail("No proposal awaiting confirmation.");
  if (accept) {
    const id = uid("MTG");
    d.meetings.push({ id, requestId: r.id, ventureId: r.ventureId, mentorId: r.proposal!.mentorId, start: r.proposal!.start, durationMin: r.durationMin, mode: "Online", location: "Online", link: "", status: "Scheduled", history: [{ at: nowIso(), by: "Student (simulated)", text: "Created after student accepted admin proposal" }] });
    r.mentorId = r.proposal!.mentorId;
    r.status = "Confirmed";
    r.meetingId = id;
    r.history.push({ at: nowIso(), by: "Student (simulated)", text: `Accepted proposal — meeting ${id} created` });
  } else {
    r.status = "Pending";
    r.history.push({ at: nowIso(), by: "Student (simulated)", text: "Declined proposal" });
    delete r.proposal;
  }
  notify(d, "Student response to alternative proposal", `${r.id}: student ${accept ? "accepted" : "declined"} the proposal`, `/meeting-requests`);
  audit(d, actor, "Simulated student response", "meeting_proposal", r.id, "Awaiting Student Confirmation", r.status);
}

export function requestClarification(d: MesaData, actor: Admin, requestId: string, note: string) {
  if (!note.trim()) fail("Describe what needs clarifying.");
  const r = d.requests.find((x) => x.id === requestId) ?? fail("Request not found");
  const prev = r.status;
  r.status = "Clarification Requested";
  r.history.push({ at: nowIso(), by: actor.name, text: `Clarification requested: ${note}` });
  audit(d, actor, "Request clarification", "meeting_request", r.id, prev, r.status, note);
}

export function rejectRequest(d: MesaData, actor: Admin, requestId: string, reason: string) {
  needReason("Rejected", reason);
  const r = d.requests.find((x) => x.id === requestId) ?? fail("Request not found");
  if (r.status === "Confirmed") fail("Confirmed requests cannot be rejected.");
  const prev = r.status;
  r.status = "Rejected";
  r.history.push({ at: nowIso(), by: actor.name, text: `Rejected — ${reason}` });
  audit(d, actor, "Reject request", "meeting_request", r.id, prev, "Rejected", reason);
}

// ---------- Meetings ----------
export function simulateMentorComplete(d: MesaData, actor: Admin, meetingId: string) {
  const m = d.meetings.find((x) => x.id === meetingId) ?? fail("Meeting not found");
  if (m.status !== "Scheduled") fail("Only scheduled meetings can be completed.");
  m.status = "Completed";
  m.mentorCompletedAt = nowIso();
  m.history.push({ at: nowIso(), by: "Mentor (simulated)", text: "Marked completed in Mentor Workspace" });
  notify(d, "Mentor meeting completion", `${m.id} marked completed by mentor`, "/calendar");
  audit(d, actor, "Simulated mentor completion", "meeting", m.id, "Scheduled", "Completed");
}

export function verifyCompletion(d: MesaData, actor: Admin, meetingId: string) {
  const m = d.meetings.find((x) => x.id === meetingId) ?? fail("Meeting not found");
  if (!m.mentorCompletedAt) fail("The mentor has not marked this meeting completed.");
  if (m.adminVerifiedAt) fail("Completion already verified.");
  m.adminVerifiedAt = nowIso();
  m.verifiedBy = actor.name;
  m.history.push({ at: nowIso(), by: actor.name, text: "Admin verified completion (approved duration unchanged)" });
  audit(d, actor, "Verify meeting completion", "meeting", m.id, "Unverified", "Verified");
}

// ---------- Reports ----------
export function reviewReport(d: MesaData, actor: Admin, reportId: string, decision: ReviewStatus, feedback = "") {
  needReason(decision, feedback);
  const r = d.reports.find((x) => x.id === reportId) ?? fail("Report not found");
  const prev = r.status;
  r.status = decision;
  r.history.push({ at: nowIso(), by: actor.name, text: `${decision}${feedback ? ` — ${feedback}` : ""}` });
  // Student tasks stay visible; a non-approval only flags them.
  if (decision !== "Approved") for (const gid of r.taskGoalIds) {
    const g = d.goals.find((x) => x.id === gid);
    if (g) g.flagged = `Source report ${decision.toLowerCase()}: ${feedback}`;
  }
  audit(d, actor, "Review meeting report", "meeting_report", r.id, prev, decision, feedback);
}

// ---------- Goals / Evidence ----------
export function createGoal(d: MesaData, actor: Admin, g: { ventureId: string; title: string; category: string; description: string; due: string; requiredEvidence: string }) {
  if (!g.title.trim() || !g.ventureId || !g.due) fail("Venture, title and due date are required.");
  const id = uid("GOL");
  d.goals.push({ id, ...g, assignedBy: "Programme Staff", createdAt: nowIso(), mentorVerification: "Not Applicable", submissions: [] });
  audit(d, actor, "Create goal", "goal", id, "", g.title);
}

/** Direct admin evidence approval — mentor verification is optional, never a prerequisite. */
export function reviewEvidence(d: MesaData, actor: Admin, goalId: string, decision: ReviewStatus, feedback = "") {
  needReason(decision, feedback);
  const g = d.goals.find((x) => x.id === goalId) ?? fail("Goal not found");
  const s = g.submissions[g.submissions.length - 1];
  if (!s || !s.submittedAt || s.status !== "Pending Review") throw new Error("No submission awaiting review.");
  const prev = s.status;
  s.status = decision;
  s.feedback = feedback;
  s.reviewedBy = actor.name;
  s.reviewedAt = nowIso();
  // NOTE: deliberately does not touch MSL readiness criteria.
  audit(d, actor, "Review evidence", "evidence_submission", `${g.id}#${s.number}`, prev, decision, feedback);
}

// ---------- Workshops ----------
export function createWorkshop(d: MesaData, actor: Admin, w: Omit<Workshop, "id" | "registrations" | "status">, publish: boolean) {
  if (!w.title.trim() || !w.date || !w.facilitator.trim()) fail("Title, facilitator and date are required.");
  if (w.capacity < 1) fail("Capacity must be at least 1.");
  const id = uid("WKS");
  d.workshops.push({ ...w, id, status: publish ? "Published" : "Draft", registrations: [] });
  audit(d, actor, "Create workshop", "workshop", id, "", publish ? "Published" : "Draft");
}

export function setWorkshopStatus(d: MesaData, actor: Admin, workshopId: string, status: "Published" | "Draft" | "Cancelled", reason = "") {
  const w = d.workshops.find((x) => x.id === workshopId) ?? fail("Workshop not found");
  if (w.status === "Completed") fail("Completed workshops cannot change status.");
  if (status === "Cancelled" && !reason.trim()) fail("A reason is required to cancel a workshop.");
  const prev = w.status;
  w.status = status;
  audit(d, actor, "Workshop status", "workshop", w.id, prev, status, reason);
}

export function markAttendance(d: MesaData, actor: Admin, workshopId: string, studentId: string, attended: boolean) {
  const w = d.workshops.find((x) => x.id === workshopId) ?? fail("Workshop not found");
  const r = w.registrations.find((x) => x.studentId === studentId && x.status === "Registered") ?? fail("Registration not found");
  r.attended = attended;
  audit(d, actor, "Mark attendance", "workshop_registration", w.id, studentId, attended ? "Attended" : "No-show");
}

export function cancelRegistration(d: MesaData, actor: Admin, workshopId: string, studentId: string) {
  const w = d.workshops.find((x) => x.id === workshopId) ?? fail("Workshop not found");
  const r = w.registrations.find((x) => x.studentId === studentId && x.status !== "Cancelled") ?? fail("Registration not found");
  const wasRegistered = r.status === "Registered";
  r.status = "Cancelled";
  let promoted: string | undefined;
  if (wasRegistered) {
    const registered = w.registrations.filter((x) => x.status === "Registered").length;
    if (registered < w.capacity) {
      const next = w.registrations
        .filter((x) => x.status === "Waitlisted")
        .sort((a, b) => a.at.localeCompare(b.at))[0];
      if (next) {
        next.status = "Registered";
        promoted = next.studentId;
        notify(d, "Workshop capacity/waitlist event", `Waitlisted student promoted in ${w.title}`, "/workshops");
      }
    }
  }
  audit(d, actor, "Cancel workshop registration", "workshop_registration", w.id, wasRegistered ? "Registered" : "Waitlisted", "Cancelled", promoted ? `Promoted ${promoted}` : "");
  return promoted;
}

/** Simulates a student self-registering in the Student Workspace. Admin never registers students directly. */
export function registerStudent(d: MesaData, actor: Admin, workshopId: string, studentId: string) {
  const w = d.workshops.find((x) => x.id === workshopId) ?? fail("Workshop not found");
  if (w.registrations.some((x) => x.studentId === studentId && x.status !== "Cancelled")) fail("Student is already registered or waitlisted.");
  const registered = w.registrations.filter((x) => x.status === "Registered").length;
  const status = registered < w.capacity ? "Registered" : "Waitlisted";
  w.registrations.push({ studentId, status, at: nowIso() });
  audit(d, actor, "Register (simulated)", "workshop_registration", w.id, "", status);
  return status;
}

// ---------- MSL ----------
export function saveMslCriterion(d: MesaData, actor: Admin, c: { id?: string | undefined; label: string; description: string; requiredEvidence: string }) {
  if (!c.label.trim()) fail("A criterion title is required.");
  if (c.id) {
    const x = d.mslCriteria.find((y) => y.id === c.id) ?? fail("Criterion not found");
    const prev = x.label;
    x.label = c.label;
    x.description = c.description;
    x.requiredEvidence = c.requiredEvidence;
    audit(d, actor, "Edit MSL criterion", "msl_criterion", x.id, prev, c.label);
  } else {
    const id = uid("CRT");
    d.mslCriteria.push({ id, label: c.label, description: c.description, requiredEvidence: c.requiredEvidence, active: true, order: d.mslCriteria.length + 1 });
    audit(d, actor, "Add MSL criterion", "msl_criterion", id, "", c.label);
  }
}

/** Deactivation preserves historical decisions — the criterion stays on old reviews. */
export function setCriterionActive(d: MesaData, actor: Admin, criterionId: string, active: boolean) {
  const c = d.mslCriteria.find((x) => x.id === criterionId) ?? fail("Criterion not found");
  c.active = active;
  audit(d, actor, active ? "Reactivate MSL criterion" : "Deactivate MSL criterion", "msl_criterion", c.id, String(!active), String(active));
}

export function moveCriterion(d: MesaData, actor: Admin, criterionId: string, dir: -1 | 1) {
  const list = [...d.mslCriteria].sort((a, b) => a.order - b.order);
  const i = list.findIndex((c) => c.id === criterionId);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= list.length) fail("Cannot move further.");
  const a = list[i];
  const b = list[j];
  if (!a || !b) return;
  const t = a.order;
  a.order = b.order;
  b.order = t;
  audit(d, actor, "Reorder MSL criteria", "msl_criterion", a.id, String(t), String(a.order));
}

export function setCriterionStatus(d: MesaData, actor: Admin, ventureId: string, criterionId: string, status: MslCriterionStatus, note = "") {
  const r = d.mslReviews.find((x) => x.ventureId === ventureId) ?? fail("Review not found");
  const c = d.mslCriteria.find((x) => x.id === criterionId) ?? fail("Criterion not found");
  if (!c.active) fail("This criterion is deactivated.");
  const cur = r.criteria[criterionId] ?? { status: "Not Started" as MslCriterionStatus, note: "", goalIds: [] };
  const prev = cur.status;
  cur.status = status;
  cur.note = note;
  r.criteria[criterionId] = cur;
  audit(d, actor, "MSL criterion verification", "msl_criterion_verification", `${ventureId}/${criterionId}`, prev, status, note);
}

export function recordProgression(d: MesaData, actor: Admin, ventureId: string, decision: MslDecision, reason: string) {
  if (!actor.roles.includes("programme_lead")) fail("Only the designated programme lead can record the final MSL progression decision.");
  if (!reason.trim()) fail("A reason is required.");
  const r = d.mslReviews.find((x) => x.ventureId === ventureId) ?? fail("Review not found");
  const prev = r.status;
  r.status = decision;
  r.decisions.push({ by: actor.name, at: nowIso(), decision, reason, evidence: Object.values(r.criteria).flatMap((c) => c.goalIds) });
  audit(d, actor, "MSL progression decision", "msl_progression_decision", ventureId, prev, decision, reason);
}

// ---------- Invoices (finance is external — no in-app finance stage) ----------
export function invoiceEligible(d: MesaData, meetingId: string) {
  const m = d.meetings.find((x) => x.id === meetingId);
  if (!m || m.status !== "Completed") return "Meeting has not been marked completed.";
  if (!d.reports.some((r) => r.meetingId === meetingId)) return "Meeting report has not been submitted.";
  if (d.invoices.some((i) => i.meetingId === meetingId && i.status !== "Rejected")) return "An active invoice already exists for this meeting.";
  return null;
}

export function reviewInvoice(d: MesaData, actor: Admin, invoiceId: string, decision: "Under Review" | "Approved" | "Changes Requested" | "Rejected", reason = "") {
  const inv = d.invoices.find((x) => x.id === invoiceId) ?? fail("Invoice not found");
  if (!["Submitted", "Under Review"].includes(inv.status)) fail(`Invoice is ${inv.status}.`);
  if (["Rejected", "Changes Requested"].includes(decision) && !reason.trim()) fail("A reason is required.");
  if (decision === "Approved") {
    const m = d.meetings.find((x) => x.id === inv.meetingId);
    if (!m?.adminVerifiedAt) fail("Admin must verify meeting completion before approving the invoice.");
    inv.approvedBy = actor.name;
  }
  const prev = inv.status;
  inv.status = decision;
  inv.history.push({ at: nowIso(), by: actor.name, text: `${decision}${reason ? ` — ${reason}` : ""}` });
  audit(d, actor, "Programme invoice review", "invoice_review", inv.id, prev, decision, reason);
}

/**
 * Marks an approved invoice as emailed to the external Finance team.
 * Opening a mailto: draft never marks this — the admin confirms explicitly.
 */
export function markSentToFinance(d: MesaData, actor: Admin, invoiceId: string, note = "") {
  const inv = d.invoices.find((x) => x.id === invoiceId) ?? fail("Invoice not found");
  if (inv.status !== "Approved") fail("Only approved invoices can be sent to Finance.");
  inv.status = "Sent to Finance";
  inv.sentToFinance = { by: actor.name, at: nowIso(), note };
  inv.history.push({ at: nowIso(), by: actor.name, text: `Marked Sent to Finance${note ? ` — ${note}` : ""}` });
  audit(d, actor, "Send invoice to Finance", "invoice_finance_handoff", inv.id, "Approved", "Sent to Finance", note);
}

export function recordPayment(d: MesaData, actor: Admin, invoiceId: string, p: { date: string; reference: string; receipt: string }) {
  const inv: Invoice = d.invoices.find((x) => x.id === invoiceId) ?? fail("Invoice not found");
  if (inv.status !== "Sent to Finance") fail("Payment can only be recorded after the invoice was sent to Finance.");
  if (!p.date || !p.reference.trim()) fail("Payment date and transaction reference are required.");
  inv.payment = { ...p, recordedBy: actor.name };
  inv.status = "Paid";
  inv.history.push({ at: nowIso(), by: actor.name, text: `Payment recorded — ref ${p.reference}` });
  audit(d, actor, "Record payment", "invoice_payment", inv.id, "Sent to Finance", "Paid", p.reference);
}

// ---------- Gallery ----------
export function publicSnapshot(d: MesaData, item: GalleryItem) {
  return {
    title: item.title,
    tagline: item.tagline,
    body: item.body,
    links: item.links,
    team: item.members
      .filter((m) => m.consent === "Granted")
      .map((m) => {
        const s = d.students.find((x) => x.id === m.studentId);
        return { name: s?.name ?? "", photo: m.hasPhoto, initials: (s?.name ?? "").split(" ").map((p) => p[0]).join("") };
      }),
  };
}

export function galleryAction(d: MesaData, actor: Admin, id: string, action: "Approved" | "Changes Requested" | "Rejected" | "Published" | "Unpublished" | "Feature" | "Unfeature", reason = "") {
  needReason(action, reason);
  const g = d.gallery.find((x) => x.id === id) ?? fail("Item not found");
  const prev = g.status;
  if (action === "Feature" || action === "Unfeature") {
    if (action === "Feature" && g.status !== "Published") fail("Only published content can be featured.");
    g.featured = action === "Feature";
  } else {
    if (action === "Published" && g.status !== "Approved" && g.status !== "Unpublished") fail("Content must be approved before publishing.");
    if (action === "Approved" && g.status !== "Pending") fail("Only pending submissions can be approved.");
    g.status = action;
    if (action === "Unpublished") g.featured = false;
  }
  g.history.push({ at: nowIso(), by: actor.name, text: `${action}${reason ? ` — ${reason}` : ""}` });
  audit(d, actor, "Gallery " + action, "gallery_publication", g.id, prev, action === "Feature" || action === "Unfeature" ? action : g.status, reason);
}

export function withdrawConsent(d: MesaData, actor: Admin, id: string, studentId: string) {
  const g = d.gallery.find((x) => x.id === id) ?? fail("Item not found");
  const m = g.members.find((x) => x.studentId === studentId) ?? fail("Member not found");
  m.consent = "Withdrawn";
  g.history.push({ at: nowIso(), by: actor.name, text: `Consent withdrawn for ${studentId}; removed from public snapshot` });
  notify(d, "Consent issue", `Consent withdrawn on ${g.title}`, "/gallery");
  audit(d, actor, "Consent withdrawal", "consent_record", `${g.id}/${studentId}`, "Granted", "Withdrawn");
}

// ---------- Announcements ----------
export function createAnnouncement(d: MesaData, actor: Admin, a: { title: string; message: string; audience: string; publishDate: string; expiry: string }, mode: "Draft" | "Scheduled" | "Published") {
  if (!a.title.trim() || !a.message.trim() || !a.audience) fail("Title, message and audience are required.");
  if (mode === "Scheduled" && !a.publishDate) fail("A publish date is required to schedule.");
  const id = uid("ANN");
  d.announcements.unshift({ id, ...a, publishDate: a.publishDate || (mode === "Published" ? nowIso().slice(0, 10) : ""), audienceDetail: "", status: mode, history: [{ at: nowIso(), by: actor.name, text: mode }] });
  audit(d, actor, "Create announcement", "announcement", id, "", mode);
}

export function setAnnouncementStatus(d: MesaData, actor: Admin, id: string, status: "Published" | "Archived" | "Draft") {
  const x = d.announcements.find((y) => y.id === id) ?? fail("Announcement not found");
  const prev = x.status;
  x.status = status;
  if (status === "Published" && !x.publishDate) x.publishDate = nowIso().slice(0, 10);
  x.history.push({ at: nowIso(), by: actor.name, text: `${prev} → ${status}` });
  audit(d, actor, "Announcement status", "announcement", id, prev, status);
}

export function editAnnouncement(d: MesaData, actor: Admin, id: string, a: { title: string; message: string; audience: string; publishDate: string; expiry: string }) {
  const x = d.announcements.find((y) => y.id === id) ?? fail("Announcement not found");
  if (x.status !== "Draft" && x.status !== "Scheduled") fail("Only drafts and scheduled announcements can be edited.");
  if (!a.title.trim() || !a.message.trim()) fail("Title and message are required.");
  x.title = a.title;
  x.message = a.message;
  x.audience = a.audience;
  x.publishDate = a.publishDate;
  x.expiry = a.expiry;
  x.history.push({ at: nowIso(), by: actor.name, text: "Edited" });
  audit(d, actor, "Edit announcement", "announcement", id, "", "edited");
}

// ---------- Admin requests (to startups / mentors) ----------
export function createAdminRequest(d: MesaData, actor: Admin, r: { title: string; message: string; recipientType: "startup" | "mentor"; recipientId: string; deadline: string; linkedType: string; linkedId: string }) {
  if (!r.title.trim() || !r.message.trim() || !r.recipientId) fail("Title, message and recipient are required.");
  const id = uid("ARQ");
  d.adminRequests.unshift({ ...r, id, status: "Sent", createdAt: nowIso(), history: [{ at: nowIso(), by: actor.name, text: "Request sent (simulated delivery)" }] });
  audit(d, actor, "Send request", "admin_request", id, "", "Sent");
}

/** Simulates the recipient's response in their own workspace. */
export function setAdminRequestStatus(d: MesaData, actor: Admin, id: string, status: AdminRequestStatus) {
  const r = d.adminRequests.find((x) => x.id === id) ?? fail("Request not found");
  const prev = r.status;
  r.status = status;
  const by = status === "Cancelled" ? actor.name : `${r.recipientType === "startup" ? "Student" : "Mentor"} (simulated)`;
  r.history.push({ at: nowIso(), by, text: `${prev} → ${status}` });
  audit(d, actor, "Request status", "admin_request", id, prev, status);
}

export { leaderOf };
