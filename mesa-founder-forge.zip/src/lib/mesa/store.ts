import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { toast } from "sonner";
import { createSeed } from "./seed";
import type { Admin, MesaData } from "./types";

interface MesaState {
  data: MesaData;
  currentAdminId: string | null;
  meetingDrawerId: string | null;
  /** Global programme/cohort filter from the header. "all" shows everything. */
  cohortFilter: string;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  openMeeting: (id: string | null) => void;
  setCohortFilter: (c: string) => void;
  reset: () => void;
  /** Run a workflow transition on a draft copy. Returns true on success. */
  run: (fn: (draft: MesaData, actor: Admin) => unknown, success?: string) => boolean;
  setData: (fn: (draft: MesaData) => void) => void;
}

export const useMesa = create<MesaState>()(
  persist(
    (set, get) => ({
      data: createSeed(),
      currentAdminId: null,
      meetingDrawerId: null,
      cohortFilter: "all",
      login: (email, password) => {
        const admin = get().data.admins.find((a) => a.id === "ADM-1" && a.status === "Active");
        if (!admin || admin.email.toLowerCase() !== email.trim().toLowerCase() || password !== "MesaDemo2026") return false;
        set({ currentAdminId: admin.id });
        return true;
      },
      logout: () => set({ currentAdminId: null }),
      openMeeting: (id) => set({ meetingDrawerId: id }),
      setCohortFilter: (c) => set({ cohortFilter: c }),
      reset: () => set({ data: createSeed() }),
      run: (fn, success) => {
        const { data, currentAdminId } = get();
        const actor = data.admins.find((a) => a.id === "ADM-1" && a.id === currentAdminId && a.status === "Active");
        if (!actor) {
          toast.error("Sign in first.");
          return false;
        }
        const draft = structuredClone(data);
        try {
          fn(draft, actor);
        } catch (e) {
          toast.error(e instanceof Error ? e.message : "Action failed");
          return false;
        }
        set({ data: draft });
        if (success) toast.success(success);
        return true;
      },
      setData: (fn) => {
        const draft = structuredClone(get().data);
        fn(draft);
        set({ data: draft });
      },
    }),
    {
      name: "mesa-admin-prototype-v2",
      version: 1,
      migrate: (persisted) => {
        const state = persisted as Pick<MesaState, "data" | "currentAdminId" | "cohortFilter">;
        state.data.admins = state.data.admins.filter((a) => a.id === "ADM-1");
        if (state.currentAdminId !== "ADM-1") state.currentAdminId = null;
        for (const v of state.data.ventures.filter((v) => v.applicationStatus === "Approved")) {
          if (!state.data.mslReviews.some((r) => r.ventureId === v.id)) state.data.mslReviews.push({ ventureId: v.id, criteria: Object.fromEntries(state.data.mslCriteria.map((c) => [c.id, { status: "Not Started", note: "", goalIds: [] }])), status: "In Preparation", decisions: [] });
        }
        return state;
      },
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ data: s.data, currentAdminId: s.currentAdminId, cohortFilter: s.cohortFilter }),
      skipHydration: true,
    },
  ),
);

export const useData = () => useMesa((s) => s.data);
export const useActor = () =>
  useMesa((s) => s.data.admins.find((a) => a.id === "ADM-1" && a.id === s.currentAdminId) ?? null);
