import type { Goal, Invoice, MesaData, Meeting, MslReview } from "./types";

export const REPORT_DEADLINE_HOURS = 24;

export function invoiceAmount(inv: Pick<Invoice, "hourlyRate" | "durationMin">) {
  return Math.round(inv.hourlyRate * (inv.durationMin / 60));
}

export function inr(n: number) {
  return "₹" + n.toLocaleString("en-IN");
}

export function fmtDate(iso?: string) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
export function fmtDateTime(iso?: string) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

export function latestSubmission(g: Goal) {
  return g.submissions[g.submissions.length - 1];
}
export function goalEvidenceStatus(g: Goal) {
  return latestSubmission(g)?.status ?? "Not Submitted";
}

/** Human-readable invoice stage. Finance processing happens outside the app. */
export function invoiceStage(inv: Invoice) {
  if (inv.status === "Approved") return "Approved — Ready to Send to Finance";
  return inv.status;
}

export function meetingEnd(m: Meeting) {
  return new Date(new Date(m.start).getTime() + m.durationMin * 60_000).toISOString();
}

/** Completed meetings with no submitted report past the 24h deadline. */
export function overdueReportMeetings(d: MesaData, now = Date.now()) {
  return d.meetings.filter((m) => {
    if (m.status !== "Completed" || !m.mentorCompletedAt) return false;
    if (d.reports.some((r) => r.meetingId === m.id)) return false;
    return now - new Date(m.mentorCompletedAt).getTime() > REPORT_DEADLINE_HOURS * 3600_000;
  });
}

export function counts(d: MesaData) {
  return {
    pendingApplications: d.ventures.filter((v) => v.applicationStatus === "Pending").length,
    pendingMentors: d.mentors.filter((m) => m.status === "Pending Approval").length,
    pendingRequests: d.requests.filter((r) => r.status === "Pending").length,
    evidencePending: d.goals.filter((g) => goalEvidenceStatus(g) === "Pending Review").length,
    reportsPending: d.reports.filter((r) => r.status === "Pending Review").length,
    invoicesPending: d.invoices.filter((i) => i.status === "Submitted" || i.status === "Under Review").length,
    galleryPending: d.gallery.filter((g) => g.status === "Pending").length,
    activeVentures: d.ventures.filter((v) => v.status === "Active").length,
    upcomingMeetings: d.meetings.filter((m) => m.status === "Scheduled" && new Date(m.start).getTime() > Date.now()).length,
    unread: d.notifications.filter((n) => !n.read).length,
  };
}

export function leaderOf(d: MesaData, ventureId: string) {
  const m = d.memberships.find((x) => x.ventureId === ventureId && x.role === "Team Leader" && !x.end);
  return m ? d.students.find((s) => s.id === m.studentId) : undefined;
}

export function nameOf(d: MesaData, id?: string) {
  if (!id) return "—";
  return (
    d.ventures.find((x) => x.id === id)?.name ??
    d.mentors.find((x) => x.id === id)?.name ??
    d.students.find((x) => x.id === id)?.name ??
    id
  );
}

/** Per-venture MSL progress summary against active criteria. */
export function mslSummary(d: MesaData, r: MslReview) {
  const active = d.mslCriteria.filter((c) => c.active);
  const verified = active.filter((c) => r.criteria[c.id]?.status === "Verified").length;
  const awaiting = active.filter((c) => r.criteria[c.id]?.status === "Awaiting Verification").length;
  return { total: active.length, verified, awaiting };
}

/** File type label from a submitted file name or URL. */
export function fileKind(name: string) {
  if (/^https?:\/\//.test(name)) return "External link";
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (ext === "pdf") return "PDF";
  if (["jpg", "jpeg", "png", "webp", "gif"].includes(ext)) return "Image";
  if (["doc", "docx"].includes(ext)) return "Document";
  if (["xls", "xlsx", "csv"].includes(ext)) return "Spreadsheet";
  return "File";
}
