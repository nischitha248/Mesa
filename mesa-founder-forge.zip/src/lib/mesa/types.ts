// Conceptual entities mirror the future shared backend (see AGENTS.md).
// All records in the prototype are fictional demo data.

export type Programme = "ILS" | "MSL";
export type AdminRole = "admin" | "programme_lead";

export interface HistoryEntry {
  at: string;
  by: string;
  text: string;
}

export interface Admin {
  id: string;
  name: string;
  email: string;
  status: "Active" | "Pending" | "Rejected" | "Deactivated";
  roles: AdminRole[];
  requestedAt: string;
  history: HistoryEntry[];
}

export type ApplicationStatus = "Pending" | "Approved" | "Changes Requested" | "Rejected";

export interface InfoEdit {
  at: string;
  by: string;
  field: string;
  prev: string;
  next: string;
}

export interface Venture {
  id: string;
  name: string;
  description: string;
  programme: Programme;
  cohort: string;
  sector: string;
  stage: string;
  website: string;
  problem: string;
  solution: string;
  customers: string;
  businessModel: string;
  applicationStatus: ApplicationStatus;
  status: "Applicant" | "Active" | "Stalled" | "Archived" | "Not Admitted";
  proposedMemberIds: string[];
  applicationDetails: string;
  lastActivity: string;
  archiveReason?: string;
  history: HistoryEntry[];
  infoHistory: InfoEdit[];
}

export interface Student {
  id: string;
  name: string;
  email: string;
  cohort: string;
  programme: Programme;
  accountStatus: "Active" | "Invited" | "Suspended";
}

export interface Membership {
  id: string;
  ventureId: string;
  studentId: string;
  role: "Team Leader" | "Member";
  start: string;
  end?: string;
}

export type MentorStatus =
  | "Active"
  | "Pending Approval"
  | "Changes Requested"
  | "Rejected"
  | "Paused"
  | "Deactivated";

export interface Mentor {
  id: string;
  name: string;
  email: string;
  organization: string;
  title: string;
  bio: string;
  experience: string;
  expertise: string[];
  linkedin: string;
  hourlyRate: number;
  status: MentorStatus;
  availability: "Available" | "Limited" | "Unavailable";
  /** Mentor-published availability windows (ISO start). Never fabricated by admin. */
  publishedSlots: string[];
  history: HistoryEntry[];
}

export interface Assignment {
  id: string;
  ventureId: string;
  mentorId: string;
  role: "Principal Mentor" | "Associate Mentor";
  focus: string;
  start: string;
  end?: string;
  status: "Active" | "Ended";
  note: string;
}

export type RequestStatus =
  | "Pending"
  | "Awaiting Student Confirmation"
  | "Clarification Requested"
  | "Confirmed"
  | "Rejected";

export interface MeetingRequest {
  id: string;
  ventureId: string;
  mentorId: string;
  topic: string;
  agenda: string;
  durationMin: number;
  slots: { start: string; preferred: boolean }[];
  submittedAt: string;
  status: RequestStatus;
  proposal?: { kind: "time" | "mentor"; start: string; mentorId: string; note: string };
  meetingId?: string;
  history: HistoryEntry[];
}

export interface Meeting {
  id: string;
  requestId: string;
  ventureId: string;
  mentorId: string;
  start: string;
  durationMin: number;
  mode: "In person" | "Online";
  location: string;
  link: string;
  status: "Scheduled" | "Completed" | "Cancelled";
  mentorCompletedAt?: string;
  adminVerifiedAt?: string;
  verifiedBy?: string;
  history: HistoryEntry[];
}

export type ReviewStatus = "Pending Review" | "Approved" | "Changes Requested" | "Rejected";

export interface ReportVersion {
  version: number;
  submittedAt: string;
  summary: string;
  notes: string;
  recommendations: string;
}

export interface MeetingReport {
  id: string;
  meetingId: string;
  mentorId: string;
  ventureId: string;
  versions: ReportVersion[];
  taskGoalIds: string[];
  status: ReviewStatus;
  history: HistoryEntry[];
}

export interface EvidenceSubmission {
  number: number;
  submittedAt: string;
  submittedBy: string;
  files: string[];
  notes: string;
  status: ReviewStatus;
  feedback?: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface Goal {
  id: string;
  ventureId: string;
  title: string;
  category: string;
  description: string;
  assignedBy: "Programme Staff" | "Mentor (via report)";
  sourceReportId?: string;
  createdAt: string;
  due: string;
  requiredEvidence: string;
  mentorVerification: "Not Applicable" | "Pending" | "Verified";
  submissions: EvidenceSubmission[];
  flagged?: string;
}

export interface Registration {
  studentId: string;
  status: "Registered" | "Waitlisted" | "Cancelled";
  at: string;
  attended?: boolean;
}

export interface Workshop {
  id: string;
  title: string;
  topic: string;
  description: string;
  facilitator: string;
  date: string;
  startTime: string;
  durationMin: number;
  mode: string;
  capacity: number;
  deadline: string;
  eligibility: string;
  status: "Draft" | "Published" | "Completed" | "Cancelled";
  registrations: Registration[];
}

export interface MslCriterion {
  id: string;
  label: string;
  description: string;
  requiredEvidence: string;
  active: boolean;
  order: number;
}

export type MslCriterionStatus =
  | "Not Started"
  | "Awaiting Verification"
  | "Verified"
  | "Needs More Evidence"
  | "Not Met";

export type MslDecision = "Approved for MSL" | "Not Yet Ready" | "Deferred";

export interface MslReview {
  ventureId: string;
  criteria: Record<string, { status: MslCriterionStatus; note: string; goalIds: string[] }>;
  recommendation?: { by: string; at: string; text: string };
  status: "In Preparation" | "Ready for Decision" | MslDecision;
  decisions: { by: string; at: string; decision: MslDecision; reason: string; evidence: string[] }[];
}

export type InvoiceStatus =
  | "Draft"
  | "Submitted"
  | "Under Review"
  | "Changes Requested"
  | "Approved"
  | "Sent to Finance"
  | "Rejected"
  | "Paid";

export interface Invoice {
  /** Original submitted document, when available; demo rows have no real upload. */
  submittedPdfUrl?: string;
  id: string;
  meetingId: string;
  mentorId: string;
  ventureId: string;
  hourlyRate: number;
  durationMin: number;
  status: InvoiceStatus;
  approvedBy?: string;
  /** External finance handoff: admin emailed the approved PDF outside the app. */
  sentToFinance?: { by: string; at: string; note: string };
  payment?: { date: string; reference: string; receipt: string; recordedBy: string };
  history: HistoryEntry[];
}

export type GalleryType = "Venture Profile" | "Update" | "Founder Story" | "Media" | "Event";
export type GalleryStatus =
  | "Pending"
  | "Approved"
  | "Changes Requested"
  | "Rejected"
  | "Published"
  | "Unpublished";

export interface GalleryMember {
  studentId: string;
  consent: "Granted" | "Pending" | "Withdrawn" | "Not Requested";
  consentRef?: string;
  hasPhoto: boolean;
}

export interface GalleryItem {
  id: string;
  ventureId?: string;
  type: GalleryType;
  title: string;
  tagline: string;
  body: string;
  problem?: string;
  solution?: string;
  links: string[];
  members: GalleryMember[];
  status: GalleryStatus;
  featured: boolean;
  submittedAt: string;
  history: HistoryEntry[];
}

export type AnnouncementStatus = "Draft" | "Scheduled" | "Published" | "Archived";

export interface Announcement {
  id: string;
  title: string;
  message: string;
  audience: string;
  audienceDetail: string;
  publishDate: string;
  expiry: string;
  status: AnnouncementStatus;
  history: HistoryEntry[];
}

export type AdminRequestStatus = "Sent" | "Acknowledged" | "Completed" | "Overdue" | "Cancelled";

/** Structured request from Admin to a startup's student account or a mentor. */
export interface AdminRequest {
  id: string;
  title: string;
  message: string;
  recipientType: "startup" | "mentor";
  recipientId: string;
  deadline: string;
  linkedType: string;
  linkedId: string;
  status: AdminRequestStatus;
  createdAt: string;
  history: HistoryEntry[];
}

export interface Notification {
  id: string;
  type: string;
  text: string;
  link: string;
  at: string;
  read: boolean;
}

export interface AuditEvent {
  id: string;
  actor: string;
  role: string;
  action: string;
  entity: string;
  entityId: string;
  prev: string;
  next: string;
  at: string;
  reason: string;
}

export interface MesaData {
  admins: Admin[];
  ventures: Venture[];
  students: Student[];
  memberships: Membership[];
  mentors: Mentor[];
  assignments: Assignment[];
  requests: MeetingRequest[];
  meetings: Meeting[];
  reports: MeetingReport[];
  goals: Goal[];
  workshops: Workshop[];
  mslCriteria: MslCriterion[];
  mslReviews: MslReview[];
  invoices: Invoice[];
  gallery: GalleryItem[];
  announcements: Announcement[];
  adminRequests: AdminRequest[];
  notifications: Notification[];
  audit: AuditEvent[];
}
