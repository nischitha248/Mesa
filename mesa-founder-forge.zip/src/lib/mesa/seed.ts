// @ts-nocheck -- demo seed; strict indexing checks relaxed
import type {
  Admin,
  Assignment,
  GalleryItem,
  Goal,
  Meeting,
  MeetingReport,
  MeetingRequest,
  MesaData,
  Mentor,
  Membership,
  MslCriterion,
  MslReview,
  Student,
  Venture,
  Workshop,
  Invoice,
} from "./types";

// ILLUSTRATIVE DEMO DATA — fictional people and ventures, not live Mesa programme records.

const H = 3600_000;
const D = 24 * H;

function at(base: number, offsetMs: number, hour?: number) {
  const d = new Date(base + offsetMs);
  if (hour !== undefined) d.setHours(hour, 0, 0, 0);
  return d.toISOString();
}

const ventureDefs: [string, string, "ILS" | "MSL", string, string][] = [
  ["Kheti Loop", "Soil-health subscriptions for smallholder farms.", "MSL", "Cohort 2026", "AgriTech"],
  ["Paisa Pal", "Micro-savings nudges for first-time earners.", "MSL", "Cohort 2026", "FinTech"],
  ["Dabba Route", "Zero-waste tiffin logistics for offices.", "ILS", "Cohort 2026", "Food & Logistics"],
  ["ClinicQ", "Queue management for neighbourhood clinics.", "MSL", "Cohort 2025", "HealthTech"],
  ["Loom & Leaf", "Handloom marketplace with artisan traceability.", "ILS", "Cohort 2026", "Retail"],
  ["Shiksha Snap", "Bite-sized exam revision for vernacular learners.", "ILS", "Cohort 2025", "EdTech"],
  ["Volt Rickshaw", "Battery-swap network for e-rickshaws.", "MSL", "Cohort 2025", "Mobility"],
  ["Aqua Ledger", "Water-usage metering for housing societies.", "ILS", "Cohort 2026", "CleanTech"],
  ["Kirana Cloud", "Inventory app for corner grocery stores.", "MSL", "Cohort 2026", "Retail Tech"],
  ["Mitti Craft", "Terracotta décor direct from potters.", "ILS", "Cohort 2026", "D2C"],
  ["CareCircle", "Coordinated eldercare for distant families.", "ILS", "Cohort 2026", "HealthTech"],
  ["RentRight", "Verified rental listings for students.", "MSL", "Cohort 2026", "PropTech"],
];

const stages = ["Idea", "Discovery", "MVP", "Pilot", "Early Revenue"];

const firstNames = [
  "Aarav", "Diya", "Ishaan", "Meera", "Kabir", "Ananya", "Vihaan", "Saanvi", "Arjun", "Riya",
  "Reyansh", "Tara", "Advait", "Nisha", "Krish", "Pooja", "Aditya", "Zara", "Om", "Kiara",
  "Yash", "Neha", "Siddharth", "Ira", "Dhruv", "Myra", "Rudra", "Avni", "Parth", "Sana",
  "Veer", "Aditi", "Laksh", "Mahi", "Nikhil",
];
const lastNames = ["Sharma", "Iyer", "Nair", "Kapoor", "Reddy", "Bose", "Menon", "Gupta", "Das", "Joshi", "Patel"];

const mentorDefs: [string, string, string, string[], number, Mentor["status"]][] = [
  ["Priya Natarajan", "Fieldstone Ventures (fictional)", "Partner", ["Fundraising", "FinTech"], 4000, "Active"],
  ["Vikram Sethi", "Northbay Foods (fictional)", "COO", ["Operations", "Supply Chain"], 3500, "Active"],
  ["Leena D'Souza", "Arc Health Labs (fictional)", "Product Director", ["HealthTech", "Product"], 4500, "Active"],
  ["Rahul Khanna", "Brightpath Learning (fictional)", "Founder", ["EdTech", "Go-to-market"], 3000, "Active"],
  ["Farah Qureshi", "Monsoon Design Co. (fictional)", "Design Lead", ["Brand", "UX"], 3200, "Active"],
  ["Sanjay Pillai", "GreenGrid Energy (fictional)", "VP Engineering", ["CleanTech", "Hardware"], 5000, "Active"],
  ["Anjali Mehra", "Ledgerline Advisory (fictional)", "Chartered Accountant", ["Finance", "Compliance"], 2800, "Paused"],
  ["Tomás Fernandes", "Harbour Retail (fictional)", "Head of Growth", ["Retail", "Marketing"], 3800, "Active"],
  ["Gauri Bhat", "Saffron Legal (fictional)", "Counsel", ["Legal", "IP"], 4200, "Pending Approval"],
  ["Nitin Rao", "Openfield Capital (fictional)", "Associate", ["Fundraising", "AgriTech"], 3000, "Pending Approval"],
];

export function createSeed(now = Date.now()): MesaData {
  const admins: Admin[] = [
    { id: "ADM-1", name: "Aanya Rao", email: "aanya.rao@demo.mesa", status: "Active", roles: ["admin", "programme_lead"], requestedAt: at(now, -200 * D), history: [] },
  ];

  const students: Student[] = firstNames.map((f, i) => {
    const v = ventureDefs[i % 12];
    return {
      id: `STU-${String(i + 1).padStart(3, "0")}`,
      name: `${f} ${lastNames[i % lastNames.length]}`,
      email: `${f.toLowerCase()}.${lastNames[i % lastNames.length].toLowerCase()}@demo.students.mesa`,
      cohort: v[3],
      programme: v[2],
      accountStatus: i === 33 ? "Invited" : "Active",
    };
  });

  const ventures: Venture[] = ventureDefs.map((v, i) => {
    const pending = i === 10 || i === 11;
    const changes = i === 9;
    return {
      id: `VEN-${String(i + 1).padStart(3, "0")}`,
      name: v[0],
      description: v[1],
      programme: v[2],
      cohort: v[3],
      sector: v[4],
      stage: stages[i % stages.length],
      website: `https://example.com/${v[0].toLowerCase().replace(/[^a-z]+/g, "-")}`,
      problem: `Illustrative problem statement for ${v[0]}: customers lack an affordable, reliable option.`,
      solution: `Illustrative solution: ${v[1]}`,
      customers: "Early adopters in Bengaluru and Pune (illustrative).",
      businessModel: "Subscription with a pilot-to-paid conversion motion (illustrative).",
      applicationStatus: pending ? "Pending" : changes ? "Changes Requested" : "Approved",
      status: pending || changes ? "Applicant" : i === 6 ? "Stalled" : "Active",
      proposedMemberIds: [],
      applicationDetails: `Customer discovery with 40+ interviews. Requesting admission to ${v[2]} ${v[3]}.`,
      lastActivity: at(now, -(i % 5) * D - (i === 6 ? 25 * D : 0)),
      history: [{ at: at(now, -60 * D), by: "Student Workspace", text: "Application submitted" }],
      infoHistory: [],
    };
  });

  // memberships: students distributed ~3 per venture, first is leader
  const memberships: Membership[] = [];
  students.forEach((s, i) => {
    const vIdx = i % 12;
    const isLeader = i < 12;
    memberships.push({
      id: `MEM-${i + 1}`,
      ventureId: ventures[vIdx].id,
      studentId: s.id,
      role: isLeader ? "Team Leader" : "Member",
      start: at(now, -55 * D),
    });
  });
  ventures.forEach((v) => {
    v.proposedMemberIds = memberships.filter((m) => m.ventureId === v.id).map((m) => m.studentId);
  });

  const mentors: Mentor[] = mentorDefs.map((m, i) => ({
    id: `MEN-${String(i + 1).padStart(2, "0")}`,
    name: m[0],
    email: `${m[0].split(" ")[0].toLowerCase()}@demo.mentors.mesa`,
    organization: m[1],
    title: m[2],
    bio: `${m[2]} at ${m[1]}; mentors early-stage founders on ${m[3].join(" and ").toLowerCase()} (illustrative bio).`,
    experience: `${8 + (i % 10)}+ years across ${m[3].join(", ")} (illustrative).`,
    expertise: m[3],
    linkedin: `https://www.linkedin.com/in/demo-${m[0].split(" ")[0].toLowerCase()}`,
    hourlyRate: m[4],
    status: m[5],
    availability: m[5] === "Active" ? (i % 3 === 0 ? "Limited" : "Available") : "Unavailable",
    publishedSlots:
      m[5] === "Active"
        ? [1, 2, 3, 5, 8].map((d) => at(now, (d + (i % 3)) * D, 10 + (i % 6)))
        : [],
    history: [{ at: at(now, -90 * D), by: "Mentor Workspace", text: "Mentor registration submitted" }],
  }));

  const assignments: Assignment[] = [];
  let aid = 1;
  ventures.slice(0, 9).forEach((v, i) => {
    const active = mentors.filter((m) => m.status === "Active");
    const p = active[i % active.length];
    const a = active[(i + 3) % active.length];
    assignments.push({ id: `ASG-${aid++}`, ventureId: v.id, mentorId: p.id, role: "Principal Mentor", focus: p.expertise[0], start: at(now, -50 * D), status: "Active", note: "" });
    assignments.push({ id: `ASG-${aid++}`, ventureId: v.id, mentorId: a.id, role: "Associate Mentor", focus: a.expertise[0], start: at(now, -45 * D), status: "Active", note: "" });
  });

  const topics = ["Pricing strategy", "Pitch deck review", "Unit economics", "Pilot design", "Hiring first engineer", "Brand positioning", "Regulatory check", "Fundraising plan"];

  // 15 confirmed meetings (past and future) + 5 open requests = 20 requests
  const meetings: Meeting[] = [];
  const requests: MeetingRequest[] = [];
  const activeVentures = ventures.slice(0, 9);
  for (let i = 0; i < 20; i++) {
    const v = activeVentures[i % 9];
    const asg = assignments.filter((x) => x.ventureId === v.id)[i % 2];
    const reqId = `REQ-${String(i + 1).padStart(3, "0")}`;
    const confirmed = i < 15;
    const offsetDays = confirmed ? (i < 9 ? -(i + 1) * 2 : i - 8) : i - 13;
    const slots = [0, 1, 2].slice(0, i % 4 === 0 ? 2 : 3).map((k) => ({
      start: at(now, (offsetDays + k) * D, 11 + k),
      preferred: k === 0,
    }));
    const statusForOpen: MeetingRequest["status"][] = ["Pending", "Pending", "Awaiting Student Confirmation", "Clarification Requested", "Pending"];
    const req: MeetingRequest = {
      id: reqId,
      ventureId: v.id,
      mentorId: asg.mentorId,
      topic: topics[i % topics.length],
      agenda: `Review progress on ${topics[i % topics.length].toLowerCase()} and agree next steps.`,
      durationMin: i % 3 === 0 ? 90 : 60,
      slots,
      submittedAt: at(now, (offsetDays - 5) * D),
      status: confirmed ? "Confirmed" : statusForOpen[i - 15],
      history: [{ at: at(now, (offsetDays - 5) * D), by: "Team leader (Student Workspace)", text: "Request submitted" }],
    };
    if (req.status === "Awaiting Student Confirmation") {
      req.proposal = { kind: "time", start: at(now, 6 * D, 15), mentorId: req.mentorId, note: "Mentor's published slot later in the week." };
      req.history.push({ at: at(now, -1 * D), by: "Dev Mehta", text: "Alternative time proposed — awaiting student confirmation" });
    }
    if (req.status === "Clarification Requested") {
      req.history.push({ at: at(now, -1 * D), by: "Dev Mehta", text: "Clarification requested: please narrow the agenda." });
    }
    if (confirmed) {
      const mid = `MTG-${String(i + 1).padStart(3, "0")}`;
      req.meetingId = mid;
      req.history.push({ at: req.submittedAt, by: "Aanya Rao", text: "Confirmed student-proposed slot 1" });
      const past = offsetDays < 0;
      const completedByMentor = past && i !== 8;
      meetings.push({
        id: mid,
        requestId: reqId,
        ventureId: v.id,
        mentorId: req.mentorId,
        start: slots[0].start,
        durationMin: req.durationMin,
        mode: i % 2 ? "Online" : "In person",
        location: i % 2 ? "Online" : "Mesa campus, Room 2B",
        link: "",
        status: completedByMentor ? "Completed" : "Scheduled",
        mentorCompletedAt: completedByMentor ? at(now, (offsetDays) * D + 2 * H) : undefined,
        adminVerifiedAt: completedByMentor && i < 6 ? at(now, (offsetDays + 1) * D) : undefined,
        verifiedBy: completedByMentor && i < 6 ? "Aanya Rao" : undefined,
        history: [{ at: req.submittedAt, by: "Aanya Rao", text: "Meeting created from confirmed request" }],
      });
    }
    requests.push(req);
  }

  // Goals: staff goals + mentor goals from reports
  const goals: Goal[] = [];
  const goalTitles = ["Validate pricing with 20 customers", "Ship pilot MVP", "Draft financial model", "Secure LOI from pilot partner", "Complete user interviews", "Finalize brand identity", "Register company entity", "Prepare investor one-pager"];
  const categories = ["Customer", "Product", "Finance", "Partnerships", "Research", "Brand", "Compliance", "Fundraising"];

  // 8 completed meetings → reports (12 reports: some meetings with resubmitted versions + others)
  const completed = meetings.filter((m) => m.status === "Completed");
  const reports: MeetingReport[] = [];
  const reportStatuses: MeetingReport["status"][] = ["Pending Review", "Approved", "Changes Requested", "Pending Review", "Approved", "Rejected", "Pending Review"];
  completed.slice(0, 7).forEach((m, i) => {
    const rid = `RPT-${String(i + 1).padStart(3, "0")}`;
    const g: Goal = {
      id: `GOL-M${i + 1}`,
      ventureId: m.ventureId,
      title: `Follow-up: ${topics[i % topics.length]}`,
      category: categories[i % categories.length],
      description: `Follow-up task created from mentor report ${rid}.`,
      assignedBy: "Mentor (via report)",
      sourceReportId: rid,
      createdAt: at(new Date(m.start).getTime(), 20 * H),
      due: at(now, (5 + i) * D),
      requiredEvidence: "Short write-up with supporting data.",
      mentorVerification: "Pending",
      submissions: [],
    };
    goals.push(g);
    const versions = [
      { version: 1, submittedAt: at(new Date(m.start).getTime(), 20 * H), summary: `Discussed ${topics[i % topics.length].toLowerCase()}.`, notes: "Team presented progress; key risks identified.", recommendations: "Run two more experiments before next session." },
    ];
    if (i === 2) versions.push({ version: 2, submittedAt: at(new Date(m.start).getTime(), 40 * H), summary: "Revised summary with metrics.", notes: "Added experiment details.", recommendations: "Same as v1 plus pricing test." });
    reports.push({
      id: rid,
      meetingId: m.id,
      mentorId: m.mentorId,
      ventureId: m.ventureId,
      versions,
      taskGoalIds: [g.id],
      status: reportStatuses[i],
      history: [{ at: versions[0].submittedAt, by: "Mentor Workspace", text: "Report v1 submitted; tasks visible to students immediately" }],
    });
  });
  // 5 more reports for older history (approved)
  for (let i = 0; i < 5; i++) {
    const m = meetings[i];
    reports.push({
      id: `RPT-${String(8 + i).padStart(3, "0")}`,
      meetingId: m.id,
      mentorId: m.mentorId,
      ventureId: m.ventureId,
      versions: [{ version: 1, submittedAt: at(now, -40 * D + i * D), summary: "Earlier kickoff session (follow-up note).", notes: "Kickoff alignment.", recommendations: "Set quarterly goals." }],
      taskGoalIds: [],
      status: "Approved",
      history: [],
    });
  }

  const subStatuses: (Goal["submissions"][number]["status"] | null)[] = ["Pending Review", "Approved", "Changes Requested", "Pending Review", null, "Rejected", "Pending Review", "Approved", null];
  for (let i = 0; goals.length < 25; i++) {
    const v = activeVentures[i % 9];
    const st = subStatuses[i % subStatuses.length];
    const leader = memberships.find((m) => m.ventureId === v.id && m.role === "Team Leader")!;
    const g: Goal = {
      id: `GOL-${String(i + 1).padStart(3, "0")}`,
      ventureId: v.id,
      title: goalTitles[i % goalTitles.length],
      category: categories[i % categories.length],
      description: `Programme goal assigned by staff: ${goalTitles[i % goalTitles.length].toLowerCase()}.`,
      assignedBy: "Programme Staff",
      createdAt: at(now, -20 * D),
      due: at(now, (i % 7 - 2) * D),
      requiredEvidence: "Upload evidence demonstrating completion (document, data or link).",
      mentorVerification: i % 3 === 0 ? "Verified" : i % 3 === 1 ? "Pending" : "Not Applicable",
      submissions: [],
    };
    if (st) {
      if (st === "Pending Review" && i % 2 === 0) {
        g.submissions.push({ number: 1, submittedAt: at(now, -6 * D), submittedBy: leader.studentId, files: ["evidence-v1.pdf", "https://example.com/supporting-data"], notes: "First attempt.", status: "Rejected", feedback: "Missing data source.", reviewedBy: "Dev Mehta", reviewedAt: at(now, -5 * D) });
      }
      const files = i % 4 === 0 ? [`evidence-v${g.submissions.length + 1}.pdf`, "pilot-photo.jpg"] : [`evidence-v${g.submissions.length + 1}.pdf`];
      g.submissions.push({ number: g.submissions.length + 1, submittedAt: at(now, -2 * D), submittedBy: leader.studentId, files, notes: "Please review.", status: st, ...(st !== "Pending Review" ? { reviewedBy: "Dev Mehta", reviewedAt: at(now, -1 * D), feedback: st === "Approved" ? "" : "Needs more detail." } : {}) });
    }
    goals.push(g);
  }

  const wsDefs: [string, string, number, number, Workshop["status"]][] = [
    ["Customer Discovery Bootcamp", "Research", 3, 4, "Published"],
    ["Pitching to Investors", "Fundraising", 8, 20, "Published"],
    ["Financial Modelling 101", "Finance", 12, 15, "Draft"],
    ["Design Sprint Basics", "Product", -10, 12, "Completed"],
    ["Legal Foundations for Founders", "Legal", -3, 10, "Cancelled"],
    ["Growth Marketing Lab", "Marketing", 15, 25, "Published"],
  ];
  const workshops: Workshop[] = wsDefs.map((w, i) => {
    const regs = students.slice(i * 3, i * 3 + Math.min(w[3] + 2, 8)).map((s, k) => ({
      studentId: s.id,
      status: (k < w[3] ? "Registered" : "Waitlisted") as "Registered" | "Waitlisted",
      at: at(now, -(10 - k) * H),
      attended: w[4] === "Completed" ? k % 3 !== 0 : undefined,
    }));
    return {
      id: `WKS-${i + 1}`,
      title: w[0],
      topic: w[1],
      description: `${w[0]} — hands-on session (illustrative).`,
      facilitator: mentorDefs[i][0],
      date: at(now, w[2] * D).slice(0, 10),
      startTime: "15:00",
      durationMin: 120,
      mode: i % 2 ? "Online" : "Mesa campus, Studio 1",
      capacity: w[3],
      deadline: at(now, (w[2] - 1) * D).slice(0, 10),
      eligibility: i % 2 ? "All programmes" : "MSL only",
      status: w[4],
      registrations: regs,
    };
  });

  // The five default criteria chosen for this application (see spec §10).
  const mslCriteria: MslCriterion[] = [
    { id: "C1", label: "Validated customer problem", description: "30+ interviews with documented insights.", requiredEvidence: "Interview log and insight summary.", active: true, order: 1 },
    { id: "C2", label: "Working MVP or pilot", description: "A live pilot with real users.", requiredEvidence: "Pilot link or demo with usage evidence.", active: true, order: 2 },
    { id: "C3", label: "Committed founding team", description: "At least two founders committed to MSL.", requiredEvidence: "Founder commitment statements.", active: true, order: 3 },
    { id: "C4", label: "Early traction metrics", description: "Usage or revenue data from pilot.", requiredEvidence: "Metrics dashboard export or revenue records.", active: true, order: 4 },
    { id: "C5", label: "Mentor recommendation", description: "An engaged mentor endorses progression.", requiredEvidence: "Written mentor recommendation.", active: true, order: 5 },
  ];
  const mslReviews: MslReview[] = ventures
    .filter((v) => v.applicationStatus === "Approved")
    .map((v, i) => ({
      ventureId: v.id,
      criteria: Object.fromEntries(
        mslCriteria.map((c, k) => [c.id, { status: (k < i ? "Verified" : k === i ? "Awaiting Verification" : "Not Started") as "Verified" | "Awaiting Verification" | "Not Started", note: "", goalIds: goals.filter((g) => g.ventureId === v.id).slice(0, 1).map((g) => g.id) }]),
      ),
      status: i >= 3 ? "Ready for Decision" : "In Preparation",
      decisions: [],
    }));

  // invoices: 8 across completed meetings — finance is external, no in-app finance stage
  const invStatuses: Invoice["status"][] = ["Submitted", "Under Review", "Approved", "Sent to Finance", "Paid", "Rejected", "Submitted", "Draft"];
  const invoices: Invoice[] = completed.slice(0, 8).map((m, i) => {
    const mentor = mentors.find((x) => x.id === m.mentorId)!;
    const inv: Invoice = {
      id: `INV-${String(i + 1).padStart(3, "0")}`,
      meetingId: m.id,
      mentorId: m.mentorId,
      ventureId: m.ventureId,
      hourlyRate: mentor.hourlyRate,
      durationMin: m.durationMin,
      status: invStatuses[i],
      history: [{ at: at(now, -3 * D), by: "Mentor Workspace", text: "Invoice submitted" }],
    };
    if (["Approved", "Sent to Finance", "Paid"].includes(inv.status)) {
      inv.approvedBy = "Dev Mehta";
      inv.history.push({ at: at(now, -2 * D), by: "Dev Mehta", text: "Programme admin approved" });
    }
    if (["Sent to Finance", "Paid"].includes(inv.status)) {
      inv.sentToFinance = { by: "Dev Mehta", at: at(now, -1 * D), note: "PDF emailed to finance@demo.mesa" };
      inv.history.push({ at: at(now, -1 * D), by: "Dev Mehta", text: "Marked Sent to Finance (external email)" });
    }
    if (inv.status === "Paid") {
      inv.payment = { date: at(now, -12 * H).slice(0, 10), reference: "DEMO-TXN-0042", receipt: "receipt-demo.pdf", recordedBy: "Dev Mehta" };
      inv.history.push({ at: at(now, -12 * H), by: "Dev Mehta", text: "Payment recorded" });
    }
    return inv;
  });

  const memberOf = (vid: string) => memberships.filter((m) => m.ventureId === vid);
  const gTypes: GalleryItem["type"][] = ["Venture Profile", "Venture Profile", "Update", "Founder Story", "Media", "Venture Profile", "Founder Story", "Event", "Update", "Venture Profile"];
  const gStatus: GalleryItem["status"][] = ["Pending", "Published", "Pending", "Pending", "Pending", "Changes Requested", "Published", "Approved", "Published", "Pending"];
  const gallery: GalleryItem[] = gTypes.map((t, i) => {
    const v = t === "Event" ? undefined : activeVentures[i % 9];
    const consents: GalleryItem["members"][number]["consent"][] = ["Granted", "Pending", "Granted", "Withdrawn", "Not Requested"];
    return {
      id: `GAL-${String(i + 1).padStart(3, "0")}`,
      ventureId: v?.id,
      type: t,
      title: t === "Event" ? "Demo Day highlights (illustrative)" : `${v!.name} — ${t}`,
      tagline: v ? v.description : "Programme highlight",
      body: "Public-facing summary prepared by the team leader (illustrative content).",
      problem: t === "Venture Profile" ? "Problem statement as submitted." : undefined,
      solution: t === "Venture Profile" ? "Solution statement as submitted." : undefined,
      links: v ? [`https://example.com/${v.name.toLowerCase().replace(/\s/g, "-")}`] : [],
      members: v
        ? memberOf(v.id).map((m, k) => ({ studentId: m.studentId, consent: consents[(i + k) % consents.length], consentRef: `CNS-${i}${k}`, hasPhoto: k === 0 }))
        : [],
      status: gStatus[i],
      featured: i === 1,
      submittedAt: at(now, -(i + 1) * D),
      history: [{ at: at(now, -(i + 1) * D), by: "Team leader (Student Workspace)", text: "Submitted for review" }],
    };
  });

  const data: MesaData = {
    admins,
    ventures,
    students,
    memberships,
    mentors,
    assignments,
    requests,
    meetings,
    reports,
    goals,
    workshops,
    mslCriteria,
    mslReviews,
    invoices,
    gallery,
    announcements: [
      { id: "ANN-1", title: "Demo Day registrations open", message: "Register your venture for Demo Day by Friday (demo).", audience: "All students", audienceDetail: "", publishDate: at(now, -3 * D).slice(0, 10), expiry: at(now, 10 * D).slice(0, 10), status: "Published", history: [{ at: at(now, -3 * D), by: "Aanya Rao", text: "Published (simulated in-app delivery)" }] },
      { id: "ANN-2", title: "Mentor report reminder", message: "Reports are due within 24 hours of each completed meeting.", audience: "All mentors", audienceDetail: "", publishDate: at(now, 1 * D).slice(0, 10), expiry: "", status: "Scheduled", history: [{ at: at(now, -1 * D), by: "Aanya Rao", text: "Scheduled" }] },
      { id: "ANN-3", title: "Mid-cohort check-in", message: "Draft note for the mid-cohort check-in calls.", audience: "Students and mentors", audienceDetail: "", publishDate: "", expiry: "", status: "Draft", history: [] },
    ],
    adminRequests: [
      { id: "ARQ-1", title: "Upload pilot metrics", message: "Please upload your latest pilot usage metrics as evidence for your current goal.", recipientType: "startup", recipientId: "VEN-001", deadline: at(now, 4 * D).slice(0, 10), linkedType: "goal", linkedId: "GOL-001", status: "Sent", createdAt: at(now, -1 * D), history: [{ at: at(now, -1 * D), by: "Aanya Rao", text: "Request sent (simulated delivery)" }] },
      { id: "ARQ-2", title: "Confirm December availability", message: "Please publish your availability windows for December.", recipientType: "mentor", recipientId: "MEN-02", deadline: at(now, -1 * D).slice(0, 10), linkedType: "", linkedId: "", status: "Overdue", createdAt: at(now, -6 * D), history: [{ at: at(now, -6 * D), by: "Dev Mehta", text: "Request sent (simulated delivery)" }] },
      { id: "ARQ-3", title: "Resubmit report with metrics", message: "Report RPT-003 needs the experiment metrics added.", recipientType: "mentor", recipientId: "MEN-03", deadline: at(now, 2 * D).slice(0, 10), linkedType: "report", linkedId: "RPT-003", status: "Acknowledged", createdAt: at(now, -2 * D), history: [{ at: at(now, -2 * D), by: "Dev Mehta", text: "Request sent (simulated delivery)" }, { at: at(now, -1 * D), by: "Mentor (simulated)", text: "Acknowledged" }] },
    ],
    notifications: [
      { id: "NTF-1", type: "New startup application", text: "CareCircle submitted a startup application", link: "/startups/VEN-011", at: at(now, -5 * H), read: false },
      { id: "NTF-2", type: "New mentor registration", text: "Gauri Bhat registered as a mentor", link: "/mentors/MEN-09", at: at(now, -8 * H), read: false },
      { id: "NTF-3", type: "Meeting request received", text: "New meeting request REQ-016", link: "/meeting-requests", at: at(now, -10 * H), read: false },
      { id: "NTF-4", type: "Mentor report submitted", text: "Report RPT-001 submitted", link: "/meeting-reports", at: at(now, -20 * H), read: true },
      { id: "NTF-5", type: "Invoice submitted", text: "INV-001 submitted for review", link: "/invoices", at: at(now, -1 * D), read: false },
      { id: "NTF-6", type: "Admin account request", text: "Rohan Batra requested admin access", link: "/settings", at: at(now, -2 * D), read: false },
      { id: "NTF-7", type: "Consent issue", text: "A team member withdrew Gallery consent", link: "/gallery", at: at(now, -2 * D), read: false },
      { id: "NTF-8", type: "Evidence submitted", text: "New evidence awaiting review", link: "/goals", at: at(now, -2 * D), read: true },
    ],
    audit: [],
  };
  return data;
}
