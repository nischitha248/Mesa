import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Bell, BookOpen, ChevronDown, FileBarChart, GalleryHorizontal, GraduationCap, LayoutDashboard, LogOut,
  Megaphone, MessagesSquare, Receipt, Rocket, Settings, Target, Users,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent, SidebarHeader, SidebarMenu,
  SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar,
} from "@/components/ui/sidebar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useActor, useData, useMesa } from "@/lib/mesa/store";
import { counts } from "@/lib/mesa/selectors";
import { MeetingDrawer } from "./meeting-drawer";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export const NAV = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Startups & Students", url: "/startups", icon: Rocket },
  { title: "Mentors & Meetings", url: "/mentors", icon: Users },
  { title: "Goals & Evidence", url: "/goals", icon: Target },
  { title: "Workshops", url: "/workshops", icon: BookOpen },
  { title: "MSL Readiness", url: "/msl", icon: GraduationCap },
  { title: "Invoices", url: "/invoices", icon: Receipt },
  { title: "Venture Gallery", url: "/gallery", icon: GalleryHorizontal },
] as const;

export const COMM_NAV = [
  { title: "Announcements", url: "/announcements", icon: Megaphone },
  { title: "Requests", url: "/requests", icon: MessagesSquare },
  { title: "Notifications", url: "/notifications", icon: Bell },
] as const;

function Wordmark({ compact }: { compact?: boolean }) {
  // Text wordmark placeholder until the official Mesa dark-background logo file is supplied.
  return (
    <div className="flex items-center gap-2 px-1 py-1">
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-cream font-display text-lg font-bold text-maroon">M</div>
      {!compact && (
        <div className="leading-tight">
          <div className="font-display text-lg text-cream">Mesa Startup Hub</div>
          <div className="text-[11px] uppercase tracking-[0.18em] text-peach">Admin Workspace</div>
        </div>
      )}
    </div>
  );
}

function AppSidebar() {
  const { state, isMobile, setOpenMobile } = useSidebar();
  const collapsed = state === "collapsed" && !isMobile;
  const path = useRouterState({ select: (r) => r.location.pathname });
  const data = useData();
  const c = counts(data);
  const badge: Record<string, number> = {
    "/startups": c.pendingApplications,
    "/mentors": c.pendingRequests + c.pendingMentors,
    "/goals": c.evidencePending,
    "/invoices": c.invoicesPending,
    "/gallery": c.galleryPending,
    "/notifications": c.unread,
  };
  const active = (url: string) => (url === "/" ? path === "/" : path.startsWith(url));
  const commActive = COMM_NAV.some((n) => path.startsWith(n.url));
  const [commOpen, setCommOpen] = useState(commActive);
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <Wordmark compact={collapsed} />
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {NAV.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={active(item.url)} tooltip={item.title} className="rounded-full data-[active=true]:bg-crimson data-[active=true]:text-ivory">
                    <Link to={item.url} onClick={() => setOpenMobile(false)}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                      {!collapsed && !!badge[item.url] && (
                        <span className="ml-auto rounded-full bg-crimson px-2 text-xs text-ivory">{badge[item.url]}</span>
                      )}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              <SidebarMenuItem>
                <SidebarMenuButton
                  tooltip="Communication"
                  className="rounded-full"
                  onClick={() => setCommOpen((o) => !o)}
                  aria-expanded={commOpen}
                >
                  <Megaphone className="h-4 w-4" />
                  <span>Communication</span>
                  {!collapsed && <ChevronDown className={cn("ml-auto h-4 w-4 transition-transform", commOpen && "rotate-180")} />}
                </SidebarMenuButton>
              </SidebarMenuItem>
              {commOpen &&
                COMM_NAV.map((item) => (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={active(item.url)} tooltip={item.title} className="rounded-full pl-8 data-[active=true]:bg-crimson data-[active=true]:text-ivory">
                      <Link to={item.url} onClick={() => setOpenMobile(false)}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {!collapsed && !!badge[item.url] && (
                          <span className="ml-auto rounded-full bg-crimson px-2 text-xs text-ivory">{badge[item.url]}</span>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        {!collapsed && <p className="px-2 text-[11px] text-peach">Prototype · simulated data and sign-in</p>}
      </SidebarFooter>
    </Sidebar>
  );
}

const SECTION_TITLES: [string, string][] = [
  ["/startups", "Startups & Students"],
  ["/students", "Startups & Students"],
  ["/mentors", "Mentors & Meetings"],
  ["/meeting-requests", "Mentors & Meetings"],
  ["/calendar", "Mentors & Meetings"],
  ["/meeting-reports", "Mentors & Meetings"],
  ["/goals", "Goals & Evidence"],
  ["/workshops", "Workshops"],
  ["/msl", "MSL Readiness"],
  ["/invoices", "Invoices"],
  ["/gallery", "Venture Gallery"],
  ["/announcements", "Announcements"],
  ["/requests", "Requests"],
  ["/notifications", "Notifications"],
  ["/reports", "Reports"],
  ["/settings", "Settings & Audit"],
];

function Header() {
  const path = useRouterState({ select: (r) => r.location.pathname });
  const actor = useActor();
  const logout = useMesa((s) => s.logout);
  const cohortFilter = useMesa((s) => s.cohortFilter);
  const setCohortFilter = useMesa((s) => s.setCohortFilter);
  const d = useData();
  const unread = counts(d).unread;
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const seg = path.split("/").filter(Boolean);
  const section = SECTION_TITLES.find(([url]) => url !== "/" && path.startsWith(url));
  const cohorts = [...new Set(d.ventures.map((v) => v.cohort))].sort();
  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-border bg-maroon/95 px-4 backdrop-blur">
      <SidebarTrigger aria-label="Toggle navigation" />
      <nav aria-label="Breadcrumb" className="hidden text-sm text-muted-foreground lg:block">
        <Link to="/" className="hover:text-cream">Admin</Link>
        {section && (<> <span className="mx-1">/</span><span className="text-cream">{section[1]}</span></>)}
        {seg.length > 1 && (<> <span className="mx-1">/</span><span className="text-cream">{seg[seg.length - 1]}</span></>)}
      </nav>
      <form
        className="ml-auto hidden md:block"
        onSubmit={(e) => { e.preventDefault(); navigate({ to: "/startups", search: { q } }); }}
      >
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search ventures…" aria-label="Search ventures" className="h-9 w-52 rounded-full" />
      </form>
      <Select value={cohortFilter} onValueChange={setCohortFilter}>
        <SelectTrigger aria-label="Programme and cohort filter" className="hidden h-9 w-40 rounded-full sm:flex">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All cohorts</SelectItem>
          {cohorts.map((c) => (
            <SelectItem key={c} value={c}>{c}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Link to="/notifications" aria-label={`Notifications, ${unread} unread`} className="relative rounded-full p-2 hover:bg-accent">
        <Bell className="h-5 w-5 text-cream" />
        {unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-crimson px-1 text-[10px] font-bold text-ivory">{unread}</span>}
      </Link>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2 rounded-full p-1 pr-3 hover:bg-accent" aria-label="Profile menu">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-peach text-sm font-bold text-maroon">{actor?.name.split(" ").map((p) => p[0]).join("")}</span>
            <span className="hidden text-sm lg:inline">{actor?.name}</span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuLabel>
            <div>{actor?.name}</div>
            <div className="text-xs font-normal text-muted-foreground">{actor?.roles.map(roleName).join(" · ")}</div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild><Link to="/reports"><FileBarChart className="mr-2 h-4 w-4" />Reports</Link></DropdownMenuItem>
          <DropdownMenuItem asChild><Link to="/settings"><Settings className="mr-2 h-4 w-4" />Settings & audit log</Link></DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={logout}><LogOut className="mr-2 h-4 w-4" />Sign out</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}

export function roleName(r: string) {
  return r === "programme_lead" ? "Designated Programme Lead" : "Administrator";
}

function LoginScreen() {
  const login = useMesa((s) => s.login);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  return (
    <main className="grid min-h-screen place-items-center bg-maroon px-4 py-10">
      <div className="w-full max-w-md">
        <Wordmark />
        <h1 className="mt-8 font-display text-4xl">Admin sign in</h1>
        <p className="mt-2 text-sm text-muted-foreground">Fictional prototype sign-in — not production security.</p>
        <form className="mesa-light mt-6 space-y-4 rounded-lg border border-peach bg-card p-6" onSubmit={(e) => {
          e.preventDefault();
          if (!login(email, password)) toast.error("Email or password is incorrect.");
        }}>
          <label className="block text-sm">Email<Input aria-label="Email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1" /></label>
          <label className="block text-sm">Password<Input aria-label="Password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1" /></label>
          <Button type="submit" className="w-full">Sign In</Button>
          <p className="text-xs text-muted-foreground">Demo account: aanya.rao@demo.mesa · Password: MesaDemo2026</p>
        </form>
      </div>
    </main>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const actor = useActor();
  useEffect(() => {
    Promise.resolve(useMesa.persist.rehydrate()).then(() => setHydrated(true));
  }, []);
  if (!hydrated) {
    return <div className="grid min-h-screen place-items-center text-muted-foreground">Loading workspace…</div>;
  }
  if (!actor || actor.status !== "Active") return <LoginScreen />;
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Header />
          <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 md:px-8">{children}</main>
        </div>
      </div>
      <MeetingDrawer />
    </SidebarProvider>
  );
}
