import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useData, useMesa } from "@/lib/mesa/store";
import { fmtDateTime, nameOf } from "@/lib/mesa/selectors";
import { simulateMentorComplete, verifyCompletion } from "@/lib/mesa/logic";
import { Field, HistoryList, StatusBadge } from "./ui";

export function MeetingDrawer() {
  const id = useMesa((s) => s.meetingDrawerId);
  const open = useMesa((s) => s.openMeeting);
  const run = useMesa((s) => s.run);
  const d = useData();
  const m = d.meetings.find((x) => x.id === id);
  const report = m && d.reports.find((r) => r.meetingId === m.id);
  const invoice = m && d.invoices.find((i) => i.meetingId === m.id && i.status !== "Rejected");
  return (
    <Sheet open={!!m} onOpenChange={(o) => !o && open(null)}>
      <SheetContent className="w-full mesa-light overflow-y-auto bg-card text-card-foreground sm:max-w-lg">
        {m && (
          <>
            <SheetHeader>
              <SheetTitle className="font-display text-2xl text-cream">Meeting {m.id}</SheetTitle>
              <SheetDescription>{nameOf(d, m.ventureId)} with {nameOf(d, m.mentorId)}</SheetDescription>
            </SheetHeader>
            <div className="mt-6 grid grid-cols-2 gap-4">
              <Field label="Approved start">{fmtDateTime(m.start)}</Field>
              <Field label="Approved duration">{m.durationMin} min</Field>
              <Field label="Mode">{m.mode}</Field>
              <Field label="Location">{m.location}</Field>
              <Field label="Meeting Link">{m.link ? <a className="underline" href={m.link} target="_blank" rel="noreferrer">{m.link}</a> : "Not provided"}</Field>
              <Field label="Status"><StatusBadge status={m.status} /></Field>
              <Field label="Mentor completion">{fmtDateTime(m.mentorCompletedAt)}</Field>
              <Field label="Admin verification">{m.adminVerifiedAt ? `${fmtDateTime(m.adminVerifiedAt)} · ${m.verifiedBy}` : "Not verified"}</Field>
              <Field label="Report">{report ? <StatusBadge status={report.status} /> : "Not submitted"}</Field>
              <Field label="Invoice">{invoice ? `${invoice.id} · ${invoice.status}` : "None"}</Field>
            </div>
            <div className="mt-6 flex flex-wrap gap-2">
              {m.status === "Scheduled" && (
                <Button variant="outline" size="sm" onClick={() => run((dd, a) => simulateMentorComplete(dd, a, m.id), "Simulated: mentor marked completed")}>
                  Simulate mentor marks completed
                </Button>
              )}
              {m.mentorCompletedAt && !m.adminVerifiedAt && (
                <Button size="sm" onClick={() => run((dd, a) => verifyCompletion(dd, a, m.id), "Completion verified")}>
                  Verify completion
                </Button>
              )}
            </div>
            <div className="mt-6 rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">
              <div className="mb-1 font-semibold text-cream">Intended cross-workspace visibility</div>
              Student Workspace: visible to {nameOf(d, m.ventureId)} team · Mentor Workspace: visible to {nameOf(d, m.mentorId)}.
              <br />Simulated only — the separate workspaces are not updated until a shared backend is connected.
            </div>
            <h3 className="mb-3 mt-6 font-semibold">History</h3>
            <HistoryList items={m.history} />
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
