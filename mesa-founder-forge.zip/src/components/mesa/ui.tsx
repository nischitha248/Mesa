import { useMemo, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpDown, Info, Inbox, Search } from "lucide-react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">{title}</h1>
        {subtitle && <p className="mt-2 max-w-2xl text-muted-foreground">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function DemoNote({ children }: { children?: ReactNode }) {
  return (
    <div className="mb-6 flex items-start gap-2 rounded-xl border border-dashed border-border bg-surface px-4 py-3 text-sm text-muted-foreground">
      <Info className="mt-0.5 h-4 w-4 shrink-0" />
      <span>{children ?? "Illustrative demo data — not live programme records."}</span>
    </div>
  );
}

const tones: Record<string, string> = {
  good: "bg-cream text-maroon",
  warn: "bg-peach text-maroon",
  bad: "bg-crimson text-ivory",
  neutral: "border border-border text-ivory",
};
function toneFor(status: string) {
  const s = status.toLowerCase();
  if (/(approved|active|confirmed|published|paid|verified|met|registered|granted|progressed|completed|available)/.test(s)) return "good";
  if (/(reject|declin|deactiv|cancel|overdue|withdrawn|returned|not admitted|stalled)/.test(s)) return "bad";
  if (/(pending|review|awaiting|submitted|changes|clarif|waitlist|paused|limited|ready|in prep|draft|requested|applicant)/.test(s)) return "warn";
  return "neutral";
}
export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span className={cn("inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold", tones[toneFor(status)], className)}>
      {status}
    </span>
  );
}

export function Panel({ title, actions, children, className }: { title?: string; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("mesa-light rounded-lg border border-border bg-card p-5", className)}>
      {(title || actions) && (
        <div className="mb-4 flex items-center justify-between gap-2">
          {title && <h2 className="text-lg font-semibold text-cream">{title}</h2>}
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm text-ivory">{children}</div>
    </div>
  );
}

export function EmptyState({ text = "Nothing here yet." }: { text?: string }) {
  return (
    <div className="flex flex-col items-center gap-2 py-10 text-center text-muted-foreground">
      <Inbox className="h-8 w-8" />
      <p className="text-sm">{text}</p>
    </div>
  );
}

export function SearchBox({ value, onChange, placeholder = "Search…" }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="relative min-w-56 flex-1">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input aria-label={placeholder} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="rounded-full pl-9" />
    </div>
  );
}

export function FilterSelect({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger aria-label={label} className="w-auto min-w-36 rounded-full">
        <SelectValue placeholder={label} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">All {label.toLowerCase()}</SelectItem>
        {options.map((o) => (
          <SelectItem key={o} value={o}>
            {o}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export function Toolbar({ children }: { children: ReactNode }) {
  return <div className="mb-4 flex flex-wrap items-center gap-2">{children}</div>;
}

export interface Column<T> {
  key: string;
  label: string;
  render: (row: T) => ReactNode;
  sort?: (row: T) => string | number;
}

export function DataTable<T>({ rows, columns, onRowClick, rowKey, empty }: { rows: T[]; columns: Column<T>[]; onRowClick?: (r: T) => void; rowKey: (r: T) => string; empty?: string }) {
  const [sort, setSort] = useState<{ key: string; dir: 1 | -1 } | null>(null);
  const sorted = useMemo(() => {
    if (!sort) return rows;
    const col = columns.find((c) => c.key === sort.key);
    if (!col?.sort) return rows;
    return [...rows].sort((a, b) => {
      const sortValue = col.sort;
      if (!sortValue) return 0;
      const x = sortValue(a), y = sortValue(b);
      return (x > y ? 1 : x < y ? -1 : 0) * sort.dir;
    });
  }, [rows, sort, columns]);
  if (!rows.length) return <EmptyState text={empty ?? "No records match these filters."} />;
  return (
    <div className="mesa-light overflow-x-auto rounded-lg border border-border bg-card">
      <table className="w-full text-sm">
        <thead className="bg-surface-strong text-left text-xs uppercase tracking-wider text-muted-foreground">
          <tr>
            {columns.map((c) => (
              <th key={c.key} className="whitespace-nowrap px-4 py-3 font-semibold">
                {c.sort ? (
                  <button className="inline-flex items-center gap-1 hover:text-cream" onClick={() => setSort((s) => ({ key: c.key, dir: s?.key === c.key && s.dir === 1 ? -1 : 1 }))}>
                    {c.label} <ArrowUpDown className="h-3 w-3" />
                  </button>
                ) : (
                  c.label
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sorted.map((r) => (
            <tr
              key={rowKey(r)}
              onClick={onRowClick ? () => onRowClick(r) : undefined}
              className={cn("border-t border-border", onRowClick && "cursor-pointer hover:bg-accent/60")}
            >
              {columns.map((c) => (
                <td key={c.key} className="px-4 py-3 align-middle">
                  {c.render(r)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Button opening a confirmation dialog, optionally requiring a reason. */
export function ActionButton({
  label,
  title,
  description,
  requireReason,
  reasonLabel = "Reason",
  optionalNote,
  confirmLabel,
  onConfirm,
  variant,
  size = "sm",
  disabled,
}: {
  label: ReactNode;
  title: string;
  description?: string | undefined;
  requireReason?: boolean;
  reasonLabel?: string;
  optionalNote?: boolean;
  confirmLabel?: string;
  onConfirm: (reason: string) => boolean | void;
  variant?: ButtonProps["variant"];
  size?: ButtonProps["size"];
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const showField = requireReason || optionalNote;
  return (
    <>
      <Button variant={variant} size={size} disabled={disabled} onClick={(e) => { e.stopPropagation(); setOpen(true); }}>
        {label}
      </Button>
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setReason(""); }}>
        <DialogContent onClick={(e) => e.stopPropagation()}>
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
            {description && <DialogDescription>{description}</DialogDescription>}
          </DialogHeader>
          {showField && (
            <div className="space-y-2">
              <Label htmlFor="reason">{reasonLabel}{requireReason ? " (required)" : " (optional)"}</Label>
              <Textarea id="reason" value={reason} onChange={(e) => setReason(e.target.value)} className="bg-ivory text-maroon" />
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button
              variant={variant === "secondary" || variant === "destructive" ? "secondary" : "default"}
              disabled={requireReason && !reason.trim()}
              onClick={() => {
                const ok = onConfirm(reason);
                if (ok !== false) { setOpen(false); setReason(""); }
              }}
            >
              {confirmLabel ?? "Confirm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function StatCard({ label, value, to, search, tone = "plain" }: { label: string; value: ReactNode; to?: string; search?: Record<string, string>; tone?: "plain" | "accent" }) {
  const body = (
    <div className={cn("mesa-light h-full rounded-lg border p-5 transition-colors", tone === "accent" ? "border-peach bg-cream" : "border-border bg-ivory")}>
      <div className="font-display text-4xl text-cream">{value}</div>
      <div className="mt-2 text-sm text-ivory/90">{label}</div>
    </div>
  );
  if (!to) return body;
  return (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    <Link to={to as any} search={search as any} className="block rounded-2xl">
      {body}
    </Link>
  );
}

export function HistoryList({ items }: { items: { at: string; by: string; text: string }[] }) {
  if (!items.length) return <p className="text-sm text-muted-foreground">No history yet.</p>;
  return (
    <ol className="space-y-3 border-l border-border pl-4">
      {[...items].reverse().map((h, i) => (
        <li key={i} className="text-sm">
          <div className="text-ivory">{h.text}</div>
          <div className="text-xs text-muted-foreground">{h.by} · {new Date(h.at).toLocaleString("en-IN")}</div>
        </li>
      ))}
    </ol>
  );
}

export function useFilter(initial: string = "all") {
  return useState(initial);
}

export const matches = (filter: string, value: string) => filter === "all" || filter === value;
export const textMatch = (q: string, ...fields: (string | undefined)[]) =>
  !q.trim() || fields.some((f) => f?.toLowerCase().includes(q.toLowerCase()));

/** Tab bar linking the sub-pages of a consolidated section. */
export function SectionTabs({ tabs, current }: { tabs: { label: string; to: string }[]; current: string }) {
  return (
    <div className="mb-6 flex flex-wrap gap-1 rounded-full border border-border bg-surface p-1">
      {tabs.map((t) => (
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        <Link
          key={t.to}
          to={t.to as any}
          className={cn(
            "rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
            current === t.to ? "bg-cream text-maroon" : "text-ivory/80 hover:bg-accent hover:text-cream",
          )}
        >
          {t.label}
        </Link>
      ))}
    </div>
  );
}

/** Shared review actions: Approve / Request changes / Reject with reason handling. */
export function ReviewActions({
  onDecision,
  approveLabel = "Approve",
  approveTitle = "Approve?",
  approveDescription,
  size = "sm",
  disabled = false,
}: {
  disabled?: boolean;
  onDecision: (decision: "Approved" | "Changes Requested" | "Rejected", reason: string) => boolean | void;
  approveLabel?: string;
  approveTitle?: string;
  approveDescription?: string;
  size?: ButtonProps["size"];
}) {
  return (
    <div className="flex flex-wrap gap-2">
      <ActionButton label={approveLabel} title={approveTitle} description={approveDescription} optionalNote disabled={disabled} size={size} onConfirm={(r) => onDecision("Approved", r)} />
      <ActionButton label="Request changes" variant="outline" title="Request changes" requireReason disabled={disabled} size={size} onConfirm={(r) => onDecision("Changes Requested", r)} />
      <ActionButton label="Reject" variant="destructive" title="Reject" requireReason disabled={disabled} size={size} onConfirm={(r) => onDecision("Rejected", r)} />
    </div>
  );
}
