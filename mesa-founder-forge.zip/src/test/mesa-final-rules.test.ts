import { beforeEach, describe, expect, it } from "vitest";
import { createSeed } from "@/lib/mesa/seed";
import { useMesa } from "@/lib/mesa/store";
import { galleryAction, markSentToFinance, publicSnapshot, recordPayment, reviewEvidence, setCriterionStatus } from "@/lib/mesa/logic";
import { invoiceAmount } from "@/lib/mesa/selectors";

describe("Mesa final Admin rules", () => {
  beforeEach(() => useMesa.setState({ data: createSeed(), currentAdminId: null }));
  it("allows only the single authorized fictional Admin account", () => {
    expect(useMesa.getState().data.admins.map((a) => a.id)).toEqual(["ADM-1"]);
    expect(useMesa.getState().login("dev.mehta@demo.mesa", "MesaDemo2026")).toBe(false);
    expect(useMesa.getState().login("aanya.rao@demo.mesa", "wrong-password")).toBe(false);
    expect(useMesa.getState().login("aanya.rao@demo.mesa", "MesaDemo2026")).toBe(true);
    expect(useMesa.getState().currentAdminId).toBe("ADM-1");
  });
  it("starts with the five specified editable readiness criteria", () => {
    expect(createSeed().mslCriteria.map((c) => c.label)).toEqual(["Validated customer problem", "Working MVP or pilot", "Committed founding team", "Early traction metrics", "Mentor recommendation"]);
  });
  it("does not automatically progress a startup when verifying readiness", () => {
    const d = createSeed(); const admin = d.admins[0]; const r = d.mslReviews[0];
    if (!admin || !r) throw new Error("Missing fixture");
    const previous = r.status;
    for (const c of d.mslCriteria) setCriterionStatus(d, admin, r.ventureId, c.id, "Verified");
    expect(r.status).toBe(previous); expect(r.decisions).toEqual([]);
  });
  it("requires submitted evidence and reasons for changes or rejection", () => {
    const d = createSeed(); const admin = d.admins[0];
    const pending = d.goals.find((g) => g.submissions.at(-1)?.status === "Pending Review");
    const empty = d.goals.find((g) => !g.submissions.length);
    if (!admin || !pending || !empty) throw new Error("Missing fixture");
    expect(() => reviewEvidence(d, admin, empty.id, "Approved")).toThrow();
    expect(() => reviewEvidence(d, admin, pending.id, "Changes Requested", "")).toThrow();
    expect(() => reviewEvidence(d, admin, pending.id, "Rejected", "")).toThrow();
  });
  it("calculates invoice amounts from scheduled duration and approved hourly rate", () => {
    expect(invoiceAmount({ durationMin: 90, hourlyRate: 4000 })).toBe(6000);
  });
  it("records payment only after explicit external Finance handoff and confirmation", () => {
    const d = createSeed(); const admin = d.admins[0]; const inv = d.invoices.find((i) => i.status === "Approved");
    if (!admin || !inv) throw new Error("Missing fixture");
    expect(() => recordPayment(d, admin, inv.id, { date: "2026-11-02", reference: "CONFIRMED-001", receipt: "" })).toThrow();
    markSentToFinance(d, admin, inv.id);
    expect(() => recordPayment(d, admin, inv.id, { date: "", reference: "", receipt: "" })).toThrow();
    recordPayment(d, admin, inv.id, { date: "2026-11-02", reference: "CONFIRMED-001", receipt: "" });
    expect(inv.status).toBe("Paid"); expect(inv.payment?.reference).toBe("CONFIRMED-001");
  });
  it("publishes only approved content and excludes members without individual consent", () => {
    const d = createSeed(); const admin = d.admins[0]; const g = d.gallery.find((g) => g.status === "Pending");
    if (!admin || !g) throw new Error("Missing fixture");
    expect(() => galleryAction(d, admin, g.id, "Published")).toThrow();
    const snapshot = publicSnapshot(d, g);
    expect(snapshot.team.map((m) => m.name)).toEqual(g.members.filter((m) => m.consent === "Granted").map((m) => d.students.find((s) => s.id === m.studentId)?.name ?? ""));
    expect(Object.keys(snapshot).sort()).toEqual(["body", "links", "tagline", "team", "title"]);
  });
});