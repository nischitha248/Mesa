<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Detail pages that must not render inside their list parent use the trailing-underscore un-nest pattern (`startups_.$ventureId.tsx`, `mentors_.$mentorId.tsx`) so the URL stays `/startups/VEN-001` while the parent leaf keeps its own page.
- All Mesa prototype state lives in the zustand store `src/lib/mesa/store.ts` (persisted); workflow transitions go through `run()` in `src/lib/mesa/logic.ts` so history/audit entries are recorded in one place.
- Reuse existing leaf-page detail exports for dashboard and startup popups; keep one review implementation per record type so validation stays consistent.
- Light operational surfaces use the shared `mesa-light` token scope; keep dark navigation and page backgrounds outside that scope for accessible contrast.
